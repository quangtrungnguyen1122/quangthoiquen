import { BrowserRouter } from "react-router-dom"
import { Routes, Route } from "react-router-dom"
import { HabitProvider } from "@/contexts/HabitContext"
import Index from "@/pages/Index"
import Leaderboard from "@/pages/Leaderboard"
import Identity from "@/pages/Identity"
import IdentityDetail from "@/pages/IdentityDetail"
import NewIdentity from "@/pages/NewIdentity"
import PricesPage from "@/pages/PricesPage"
import Habits from "@/pages/Habits"
import HabitHistory from "@/pages/HabitHistory"
import Auth from "@/pages/Auth"
import User from "@/pages/User"
import { Toaster } from "sonner"
import ProtectedRoute from "@/components/auth/ProtectedRoute"

function App() {
  return (
    <div className="app">
      <BrowserRouter>
        <HabitProvider>
          <Routes>
            <Route path="/auth" element={<Auth />} />

            {/* Protected routes */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <Index />
                </ProtectedRoute>
              }
            />
            <Route
              path="/leaderboard"
              element={
                <ProtectedRoute>
                  <Leaderboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/prices"
              element={
                <ProtectedRoute>
                  <PricesPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/habits"
              element={
                <ProtectedRoute>
                  <Habits />
                </ProtectedRoute>
              }
            />
            <Route
              path="/habit-history"
              element={
                <ProtectedRoute>
                  <HabitHistory />
                </ProtectedRoute>
              }
            />
            <Route
              path="/identity"
              element={
                <ProtectedRoute>
                  <Identity />
                </ProtectedRoute>
              }
            />
            <Route
              path="/identity/new"
              element={
                <ProtectedRoute>
                  <NewIdentity />
                </ProtectedRoute>
              }
            />
            <Route
              path="/identity/:id"
              element={
                <ProtectedRoute>
                  <IdentityDetail />
                </ProtectedRoute>
              }
            />
            <Route
              path="/user"
              element={
                <ProtectedRoute>
                  <User />
                </ProtectedRoute>
              }
            />
          </Routes>
        </HabitProvider>
        <Toaster />
      </BrowserRouter>
    </div>
  )
}

export default App

