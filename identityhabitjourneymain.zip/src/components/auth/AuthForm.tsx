"use client"

import type React from "react"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Eye, EyeOff, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/integrations/supabase/client"

interface AuthFormProps {
  isLogin: boolean
  onToggleMode: () => void
}

const AuthForm: React.FC<AuthFormProps> = ({ isLogin, onToggleMode }) => {
  const navigate = useNavigate()
  const { toast } = useToast()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [username, setUsername] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  // Update the error handling and notifications in the handleSubmit function
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      if (isLogin) {
        // Sign in
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        })

        if (error) throw error
        toast({
          title: "Đăng nhập thành công!",
          description: "Chào mừng bạn quay trở lại.",
        })
        navigate("/")
      } else {
        // Sign up
        const { data: authData, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              username,
            },
          },
        })

        if (signUpError) throw signUpError

        if (authData.user) {
          // Create user profile
          const { error: profileError } = await supabase.from("profiles").insert({
            id: authData.user.id,
            username,
            joined_date: new Date().toISOString(),
            total_points: 0,
            last_30_days_points: 0,
            last_7_days_points: 0,
            position: 0,
          })

          if (profileError) throw profileError

          toast({
            title: "Tạo tài khoản thành công!",
            description: "Bạn đã được đăng nhập tự động.",
          })
          navigate("/")
        } else {
          toast({
            title: "Tạo tài khoản thành công!",
            description: "Vui lòng kiểm tra email để xác nhận tài khoản của bạn.",
          })
          onToggleMode() // Switch to login mode after successful registration
          // Clear form fields
          setUsername("")
          setPassword("")
        }
      }
    } catch (error: any) {
      let errorMessage = "Đã xảy ra lỗi, vui lòng thử lại"

      // Provide more specific error messages based on the error code
      if (error.message.includes("Invalid login credentials")) {
        errorMessage = "Email hoặc mật khẩu không chính xác"
      } else if (error.message.includes("Email not confirmed")) {
        errorMessage = "Email chưa được xác nhận. Vui lòng kiểm tra hộp thư của bạn"
      } else if (error.message.includes("User already registered")) {
        errorMessage = "Email này đã được đăng ký. Vui lòng đăng nhập hoặc sử dụng email khác"
      } else if (error.message.includes("Password should be")) {
        errorMessage = "Mật khẩu phải có ít nhất 6 ký tự"
      }

      toast({
        variant: "destructive",
        title: "Lỗi đăng nhập",
        description: errorMessage,
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Update the form labels and placeholders to Vietnamese
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {!isLogin && (
        <div className="space-y-2">
          <label htmlFor="username" className="text-sm font-medium">
            Tên người dùng
          </label>
          <Input
            id="username"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Nhập tên người dùng"
            required={!isLogin}
            disabled={isLoading}
          />
        </div>
      )}

      <div className="space-y-2">
        <label htmlFor="email" className="text-sm font-medium">
          Email
        </label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Nhập email của bạn"
          required
          disabled={isLoading}
        />
      </div>

      <div className="space-y-2">
        <label htmlFor="password" className="text-sm font-medium">
          Mật khẩu
        </label>
        <div className="relative">
          <Input
            id="password"
            type={showPassword ? "text" : "password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Nhập mật khẩu của bạn"
            required
            disabled={isLoading}
            className="pr-10"
          />
          <button
            type="button"
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {isLogin ? "Đang đăng nhập..." : "Đang tạo tài khoản..."}
          </>
        ) : isLogin ? (
          "Đăng nhập"
        ) : (
          "Tạo tài khoản"
        )}
      </Button>

      <div className="mt-6 text-center">
        <button
          type="button"
          onClick={onToggleMode}
          className="text-sm text-primary hover:underline"
          disabled={isLoading}
        >
          {isLogin ? "Chưa có tài khoản? Đăng ký ngay" : "Đã có tài khoản? Đăng nhập"}
        </button>
      </div>
    </form>
  )
}

export default AuthForm

