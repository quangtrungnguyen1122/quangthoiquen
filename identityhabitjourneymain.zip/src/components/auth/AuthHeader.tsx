"use client"

import type React from "react"
import { motion } from "framer-motion"

interface AuthHeaderProps {
  isLogin: boolean
}

const AuthHeader: React.FC<AuthHeaderProps> = ({ isLogin }) => {
  return (
    <div className="text-center mb-6">
      <motion.h1 initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="text-2xl font-bold">
        {isLogin ? "Đăng nhập" : "Tạo tài khoản mới"}
      </motion.h1>
      <p className="text-muted-foreground mt-2">
        {isLogin
          ? "Đăng nhập để truy cập vào bảng điều khiển của bạn"
          : "Tạo tài khoản mới để bắt đầu xây dựng thói quen"}
      </p>
    </div>
  )
}

export default AuthHeader

