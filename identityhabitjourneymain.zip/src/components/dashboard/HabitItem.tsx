"use client"
import { Link } from "react-router-dom"
import { Check, Target } from "lucide-react"
import { cn } from "@/lib/utils"

interface HabitItemProps {
  id: string
  name: string
  description: string
  difficulty: string
  points: number
  completed: boolean
  onComplete: (id: string) => void
}

const HabitItem = ({ id, name, description, difficulty, points, completed, onComplete }: HabitItemProps) => {
  return (
    <div className="flex items-start gap-3 p-4 border border-border rounded-lg bg-card">
      <button
        onClick={() => !completed && onComplete(id)}
        disabled={completed}
        className={cn(
          "mt-0.5 w-6 h-6 rounded-full flex items-center justify-center",
          completed ? "bg-primary/20" : "bg-muted cursor-pointer hover:bg-primary/10",
        )}
      >
        {completed ? <Check className="w-3 h-3 text-primary" /> : <Target className="w-3 h-3 text-muted-foreground" />}
      </button>

      <div className="flex-1">
        <Link to={`/habit/${id}`} className="font-medium hover:text-primary transition-colors">
          {name}
        </Link>
        <div className="text-xs text-muted-foreground mt-1">{description}</div>
        <div className="flex items-center gap-2 mt-2">
          <div className="text-xs px-2 py-0.5 rounded-full bg-secondary">{difficulty}</div>
          <div className="text-xs text-muted-foreground">{points} points</div>
        </div>
      </div>
    </div>
  )
}

export default HabitItem

