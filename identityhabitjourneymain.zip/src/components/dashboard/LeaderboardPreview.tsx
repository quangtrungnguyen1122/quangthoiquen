"use client"
import { motion } from "framer-motion"
import { Link } from "react-router-dom"
import { Trophy, ArrowUpRight } from "lucide-react"
import { cn } from "@/lib/utils"
import GlassCard from "../ui-custom/GlassCard"
import StreakCounter from "./StreakCounter"

interface LeaderboardUser {
  id: string
  username: string
  points: number
  streak: number
  position: number
  avatar?: string
}

interface LeaderboardPreviewProps {
  users: LeaderboardUser[]
  className?: string
}

const LeaderboardPreview = ({ users, className }: LeaderboardPreviewProps) => {
  return (
    <GlassCard className={cn("", className)}>
      <div className="flex items-center justify-between mb-5">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-500" />
          <span>Leaderboard</span>
        </h3>
        <Link
          to="/leaderboard"
          className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200 flex items-center gap-1"
        >
          <span>View all</span>
          <ArrowUpRight className="w-4 h-4" />
        </Link>
      </div>

      <div className="space-y-3">
        {users.map((user, index) => (
          <motion.div
            key={user.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            className={cn(
              "flex items-center p-3 rounded-lg",
              index === 0
                ? "bg-amber-50 dark:bg-amber-950/20"
                : index === 1
                  ? "bg-slate-50 dark:bg-slate-950/20"
                  : index === 2
                    ? "bg-orange-50 dark:bg-orange-950/20"
                    : "bg-muted/50",
            )}
          >
            <div className="w-7 h-7 flex items-center justify-center font-semibold text-sm mr-3">
              {index === 0 ? (
                <span className="text-amber-500">🥇</span>
              ) : index === 1 ? (
                <span className="text-slate-400">🥈</span>
              ) : index === 2 ? (
                <span className="text-amber-600">🥉</span>
              ) : (
                <span className="text-muted-foreground">{user.position}</span>
              )}
            </div>

            <div className="flex-shrink-0 mr-3">
              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                {user.avatar ? (
                  <img src={user.avatar} alt={user.username} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-xs font-medium">{user.username.substring(0, 2).toUpperCase()}</span>
                )}
              </div>
            </div>

            <div className="flex-1 mr-4">
              <div className="font-medium">{user.username}</div>
            </div>

            <div className="flex items-center gap-3">
              <StreakCounter count={user.streak} size="sm" showLabel={false} />

              <div className="text-sm font-semibold bg-muted/70 px-2 py-1 rounded">{user.points} pts</div>
            </div>
          </motion.div>
        ))}
      </div>
    </GlassCard>
  )
}

export default LeaderboardPreview

