"use client"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface ProgressRingProps {
  progress: number // 0-100
  size?: number
  strokeWidth?: number
  className?: string
  showPercentage?: boolean
  color?: string
  delay?: number
}

const ProgressRing = ({
  progress,
  size = 80,
  strokeWidth = 6,
  className,
  showPercentage = true,
  color = "stroke-primary",
  delay = 0,
}: ProgressRingProps) => {
  const normalizedProgress = Math.min(100, Math.max(0, progress))
  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const strokeDashoffset = circumference - (normalizedProgress / 100) * circumference

  return (
    <div className={cn("relative inline-flex items-center justify-center", className)}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="progress-ring">
        {/* Background circle */}
        <circle className="stroke-muted fill-none" cx={size / 2} cy={size / 2} r={radius} strokeWidth={strokeWidth} />

        {/* Progress circle */}
        <motion.circle
          className={cn("fill-none", color)}
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{
            duration: 1.5,
            ease: [0.34, 1.56, 0.64, 1],
            delay: delay * 0.1,
          }}
          strokeLinecap="round"
        />
      </svg>

      {showPercentage && (
        <motion.div
          className="absolute inset-0 flex items-center justify-center font-medium text-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: delay * 0.1 + 0.5 }}
        >
          {Math.round(normalizedProgress)}%
        </motion.div>
      )}
    </div>
  )
}

export default ProgressRing

