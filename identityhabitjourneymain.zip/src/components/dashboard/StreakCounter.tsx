"use client"
import { motion } from "framer-motion"
import { Flame } from "lucide-react"
import { cn } from "@/lib/utils"

interface StreakCounterProps {
  count: number
  className?: string
  size?: "sm" | "md" | "lg"
  showLabel?: boolean
}

const StreakCounter = ({ count, className, size = "md", showLabel = true }: StreakCounterProps) => {
  const sizeClassMap = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  }

  const iconSizeMap = {
    sm: "w-3 h-3",
    md: "w-4 h-4",
    lg: "w-5 h-5",
  }

  return (
    <div className={cn("flex items-center gap-1.5", sizeClassMap[size], className)}>
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{
          type: "spring",
          stiffness: 260,
          damping: 20,
        }}
        className={cn(
          "flex items-center justify-center rounded-full",
          "bg-gradient-to-tr from-orange-500 to-amber-400",
          size === "sm" ? "w-5 h-5" : size === "md" ? "w-6 h-6" : "w-8 h-8",
        )}
      >
        <Flame className={cn("text-white", iconSizeMap[size])} />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: -5 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className="font-medium flex items-center gap-1"
      >
        <span>{count}</span>
        {showLabel && <span className="text-muted-foreground">days</span>}
      </motion.div>
    </div>
  )
}

export default StreakCounter

