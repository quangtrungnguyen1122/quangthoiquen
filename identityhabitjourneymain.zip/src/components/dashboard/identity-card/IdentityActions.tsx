"use client"

import { useState } from "react"
import { Pencil, Trash2, Loader2 } from "lucide-react"
import { useHabit } from "@/contexts/HabitContext"
import { Button } from "@/components/ui/button"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

interface IdentityActionsProps {
  id: string
  name: string
  description: string
  image?: string
}

const IdentityActions = ({ id, name, description, image }: IdentityActionsProps) => {
  const { deleteIdentity, updateIdentity } = useHabit()

  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)
  const [editName, setEditName] = useState(name)
  const [editDescription, setEditDescription] = useState(description)
  const [editImage, setEditImage] = useState(image || "")

  const handleDelete = async () => {
    setIsDeleting(true)
    const success = await deleteIdentity(id)
    setIsDeleting(false)
    if (success) {
      setIsDeleteDialogOpen(false)
    }
  }

  const handleUpdate = async () => {
    setIsUpdating(true)
    await updateIdentity(id, {
      name: editName,
      description: editDescription,
      avatar: editImage || undefined,
    })
    setIsUpdating(false)
    setIsEditDialogOpen(false)
  }

  const openEditDialog = () => {
    setEditName(name)
    setEditDescription(description)
    setEditImage(image || "")
    setIsEditDialogOpen(true)
  }

  return (
    <>
      <div className="flex items-center gap-2 mt-2">
        <Button variant="ghost" size="sm" className="flex-1 h-8 text-xs" onClick={openEditDialog}>
          <Pencil className="w-3 h-3 mr-1" />
          Edit
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex-1 h-8 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={() => setIsDeleteDialogOpen(true)}
        >
          <Trash2 className="w-3 h-3 mr-1" />
          Delete
        </Button>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the identity and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700">
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Identity</DialogTitle>
            <DialogDescription>Make changes to the identity details below.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="Enter identity name"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                placeholder="Enter identity description"
                rows={3}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="avatar">Avatar URL (optional)</Label>
              <Input
                id="avatar"
                value={editImage}
                onChange={(e) => setEditImage(e.target.value)}
                placeholder="Enter avatar URL"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)} disabled={isUpdating}>
              Cancel
            </Button>
            <Button type="button" onClick={handleUpdate} disabled={isUpdating || !editName || !editDescription}>
              {isUpdating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

export default IdentityActions

