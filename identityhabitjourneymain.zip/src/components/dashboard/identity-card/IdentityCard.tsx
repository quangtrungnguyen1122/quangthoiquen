import { Link } from "react-router-dom"
import { ArrowUpRight } from "lucide-react"
import { cn } from "@/lib/utils"
import { useHabit } from "@/contexts/HabitContext"
import GlassCard from "../../ui-custom/GlassCard"
import IdentityHeader from "./IdentityHeader"
import IdentityProgress from "./IdentityProgress"
import IdentityPrices from "./IdentityPrices"
import IdentityActions from "./IdentityActions"
import type { IdentityProps } from "./types"

const IdentityCard = ({
  id,
  name,
  description,
  progress,
  streak,
  highestStreak,
  image,
  delay = 0,
  editable = true,
}: IdentityProps) => {
  const { getPricesByIdentityId } = useHabit()
  const prices = getPricesByIdentityId(id)

  return (
    <GlassCard className="min-h-[240px] flex flex-col" hoverEffect delay={delay}>
      <IdentityHeader name={name} description={description} image={image} />

      <div className="flex-1 flex flex-col space-y-4">
        <IdentityProgress progress={progress} streak={streak} highestStreak={highestStreak} delay={delay} />

        <IdentityPrices prices={prices} />
      </div>

      <div className="mt-5 pt-3 border-t border-border">
        <Link
          to={`/identity/${id}`}
          className={cn(
            "text-sm font-medium flex items-center w-full justify-between",
            "transition-colors duration-200 text-muted-foreground hover:text-foreground group",
          )}
        >
          <span>View details</span>
          <ArrowUpRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </Link>

        {editable && <IdentityActions id={id} name={name} description={description} image={image} />}
      </div>
    </GlassCard>
  )
}

export default IdentityCard

