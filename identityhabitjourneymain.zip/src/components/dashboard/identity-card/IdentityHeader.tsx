import { Target } from "lucide-react"

interface IdentityHeaderProps {
  name: string
  description: string
  image?: string
}

const IdentityHeader = ({ name, description, image }: IdentityHeaderProps) => {
  return (
    <div className="flex items-start justify-between mb-4">
      <div className="flex-1">
        <h3 className="text-lg font-semibold tracking-tight text-left">{name}</h3>
        <p className="text-muted-foreground text-sm line-clamp-2 mt-1 text-left">{description}</p>
      </div>
      <div className="flex-shrink-0 ml-4">
        <div className="w-12 h-12 rounded-full border-2 border-border bg-muted/50 flex items-center justify-center">
          {image ? (
            <img src={image} alt={name} className="w-full h-full rounded-full object-cover" />
          ) : (
            <Target className="w-6 h-6 text-muted-foreground" />
          )}
        </div>
      </div>
    </div>
  )
}

export default IdentityHeader

