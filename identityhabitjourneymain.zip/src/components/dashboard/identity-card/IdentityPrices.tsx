import { Award } from "lucide-react"
import type { Price } from "@/contexts/types"

interface IdentityPricesProps {
  prices: Price[]
}

const IdentityPrices = ({ prices }: IdentityPricesProps) => {
  if (prices.length === 0) return null

  return (
    <div className="mt-2">
      <div className="text-xs text-muted-foreground mb-2 text-left">Prices ({prices.length})</div>
      <div className="flex flex-wrap gap-2">
        {prices.slice(0, 3).map((price) => (
          <div key={price.id} className="px-2 py-1 bg-primary/10 rounded-md text-xs flex items-center gap-1">
            <Award className="w-3 h-3 text-primary" />
            <span>{price.name}</span>
          </div>
        ))}
        {prices.length > 3 && <div className="px-2 py-1 bg-muted rounded-md text-xs">+{prices.length - 3} more</div>}
      </div>
    </div>
  )
}

export default IdentityPrices

