import ProgressRing from "../../dashboard/ProgressRing"
import StreakCounter from "../../dashboard/StreakCounter"

interface IdentityProgressProps {
  progress: number
  streak: number
  highestStreak: number
  delay: number
}

const IdentityProgress = ({ progress, streak, highestStreak, delay }: IdentityProgressProps) => {
  return (
    <div className="flex gap-6 items-center justify-between">
      <div className="flex items-center gap-3">
        <ProgressRing progress={progress} size={60} strokeWidth={4} delay={delay + 1} />
        <div className="space-y-1">
          <div className="text-xs text-muted-foreground">Progress</div>
          <div className="font-medium">{progress}%</div>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="text-xs text-muted-foreground">Current Streak</div>
        <StreakCounter count={streak} size="md" showLabel={false} />
      </div>
    </div>
  )
}

export default IdentityProgress

