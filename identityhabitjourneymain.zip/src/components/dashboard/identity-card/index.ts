export { default as IdentityCard } from "./IdentityCard"

