export interface IdentityProps {
  id: string
  name: string
  description: string
  progress: number
  streak: number
  highestStreak: number
  image?: string
  delay?: number
  editable?: boolean
}

