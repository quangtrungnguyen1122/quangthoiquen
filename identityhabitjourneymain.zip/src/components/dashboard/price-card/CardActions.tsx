"use client"

import { useState } from "react"
import { Pencil, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { EditPriceDialog } from "./EditPriceDialog"
import { DeletePriceDialog } from "./DeletePriceDialog"

interface CardActionsProps {
  id: string
}

export const CardActions = ({ id }: CardActionsProps) => {
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)

  const openEditDialog = () => {
    setIsEditDialogOpen(true)
  }

  return (
    <>
      <div className="flex items-center gap-2 mt-2">
        <Button variant="ghost" size="sm" className="flex-1 h-8 text-xs" onClick={openEditDialog}>
          <Pencil className="w-3 h-3 mr-1" />
          Edit
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="flex-1 h-8 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
          onClick={() => setIsDeleteDialogOpen(true)}
        >
          <Trash2 className="w-3 h-3 mr-1" />
          Delete
        </Button>
      </div>

      <EditPriceDialog id={id} open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen} />

      <DeletePriceDialog id={id} open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen} />
    </>
  )
}

