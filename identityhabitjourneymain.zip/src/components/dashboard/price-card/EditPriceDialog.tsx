"use client"

import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"
import { useHabit } from "@/contexts/HabitContext"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

interface EditPriceDialogProps {
  id: string
  open: boolean
  onOpenChange: (open: boolean) => void
}

export const EditPriceDialog = ({ id, open, onOpenChange }: EditPriceDialogProps) => {
  const { prices, updatePrice } = useHabit()
  const [isUpdating, setIsUpdating] = useState(false)
  const [editName, setEditName] = useState("")
  const [editDescription, setEditDescription] = useState("")
  const [editIcon, setEditIcon] = useState("")

  useEffect(() => {
    if (open) {
      const price = prices.find((p) => p.id === id)
      if (price) {
        setEditName(price.name)
        setEditDescription(price.description)
        setEditIcon(price.icon || "")
      }
    }
  }, [open, id, prices])

  const handleUpdate = async () => {
    setIsUpdating(true)
    await updatePrice(id, {
      name: editName,
      description: editDescription,
      icon: editIcon || undefined,
    })
    setIsUpdating(false)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Price</DialogTitle>
          <DialogDescription>Make changes to the price details below.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              placeholder="Enter price name"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={editDescription}
              onChange={(e) => setEditDescription(e.target.value)}
              placeholder="Enter price description"
              rows={3}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="icon">Icon URL (optional)</Label>
            <Input
              id="icon"
              value={editIcon}
              onChange={(e) => setEditIcon(e.target.value)}
              placeholder="Enter icon URL"
            />
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isUpdating}>
            Cancel
          </Button>
          <Button type="button" onClick={handleUpdate} disabled={isUpdating || !editName || !editDescription}>
            {isUpdating ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Changes"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

