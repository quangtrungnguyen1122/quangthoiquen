import { Link } from "react-router-dom"
import { ArrowUpRight, Award } from "lucide-react"
import { cn } from "@/lib/utils"
import GlassCard from "@/components/ui-custom/GlassCard"
import ProgressRing from "@/components/dashboard/ProgressRing"
import { CardActions } from "./CardActions"

export interface PriceProps {
  id: string
  name: string
  description: string
  completion: number
  icon?: string
  delay?: number
  editable?: boolean
}

const PriceCard = ({ id, name, description, completion, icon, delay = 0, editable = true }: PriceProps) => {
  return (
    <GlassCard className="min-h-[240px] flex flex-col" hoverEffect delay={delay}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="text-lg font-semibold tracking-tight">{name}</h3>
          <p className="text-muted-foreground text-sm line-clamp-2 mt-1">{description}</p>
        </div>
        <div className="flex-shrink-0 ml-4">
          <div className="w-12 h-12 rounded-full border-2 border-border bg-muted/50 flex items-center justify-center">
            {icon ? (
              <img src={icon} alt={name} className="w-full h-full rounded-full object-cover" />
            ) : (
              <Award className="w-6 h-6 text-muted-foreground" />
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-center">
        <div className="flex gap-3 items-center">
          <ProgressRing progress={completion} size={60} strokeWidth={4} delay={delay + 1} />
          <div className="space-y-1">
            <div className="text-xs text-muted-foreground">Completion</div>
            <div className="font-medium">{completion}%</div>
          </div>
        </div>
      </div>

      <div className="mt-5 pt-3 border-t border-border flex flex-col gap-2">
        <Link
          to={`/price/${id}`}
          className={cn(
            "text-sm font-medium flex items-center w-full justify-between",
            "transition-colors duration-200 text-muted-foreground hover:text-foreground group",
          )}
        >
          <span>View details</span>
          <ArrowUpRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </Link>

        {editable && <CardActions id={id} />}
      </div>
    </GlassCard>
  )
}

export default PriceCard

