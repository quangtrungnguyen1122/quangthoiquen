"use client"

import type React from "react"
import { memo } from "react"
import { CheckCircle, Circle } from "lucide-react"
import type { Habit } from "@/contexts/types"
import { isToday, isPast } from "date-fns"

interface CompletionStatusProps {
  habit: Habit
  date: Date
  completed: boolean
  onToggle: (habit: Habit, date: Date, currentlyCompleted: boolean) => void
}

// Use memo to prevent unnecessary re-renders
export const CompletionStatus: React.FC<CompletionStatusProps> = memo(({ habit, date, completed, onToggle }) => {
  const isInPastOrToday = isToday(date) || isPast(date)
  const isClickable = isInPastOrToday && !habit.completed

  if (completed) {
    return (
      <div
        className={`flex justify-center ${isClickable ? "cursor-pointer" : ""}`}
        onClick={() => isInPastOrToday && onToggle(habit, date, true)}
      >
        <CheckCircle className="h-6 w-6 text-green-500" />
      </div>
    )
  } else {
    return (
      <div
        className={`flex justify-center ${isClickable ? "cursor-pointer" : ""}`}
        onClick={() => isInPastOrToday && onToggle(habit, date, false)}
      >
        <Circle className="h-6 w-6 text-gray-300" />
      </div>
    )
  }
})

CompletionStatus.displayName = "CompletionStatus"

