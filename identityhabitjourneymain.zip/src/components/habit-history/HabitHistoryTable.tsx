import React, { memo } from "react"
import { format } from "date-fns"
import { Table, TableHeader, TableRow, TableHead, TableBody } from "@/components/ui/table"
import { HabitRow } from "./HabitRow"
import type { Habit } from "@/contexts/types"
import type { HabitCompletionsByHabit } from "./types"
import { Loader2 } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"

interface HabitHistoryTableProps {
  habits: Habit[]
  daysInMonth: Date[]
  completionsByHabit: HabitCompletionsByHabit[]
  onToggleCompletion: (habit: Habit, date: Date, currentlyCompleted: boolean) => void
  isLoading?: boolean
}

// Use memo to prevent unnecessary re-renders
export const HabitHistoryTable: React.FC<HabitHistoryTableProps> = memo(
  ({ habits, daysInMonth, completionsByHabit, onToggleCompletion, isLoading = false }) => {
    // Show a stable loading state
    if (isLoading) {
      return (
        <div className="flex justify-center items-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary mr-2" />
          <span className="text-muted-foreground">Loading habit history...</span>
        </div>
      )
    }

    if (habits.length === 0) {
      return <div className="py-8 text-center text-muted-foreground">No habit data found for this month.</div>
    }

    // Show skeleton while completions are being processed
    if (completionsByHabit.length === 0) {
      return <TableLoadingSkeleton daysInMonth={daysInMonth} />
    }

    return (
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="sticky left-0 bg-white dark:bg-background z-10">Habit</TableHead>
              <TableHead className="sticky left-28 bg-white dark:bg-background z-10">Difficulty</TableHead>
              {daysInMonth.map((day) => (
                <TableHead key={day.toString()} className="text-center min-w-[60px]">
                  <div className="flex flex-col items-center">
                    <span>{format(day, "d")}</span>
                    <span className="text-xs text-muted-foreground">{format(day, "EEE")}</span>
                  </div>
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {completionsByHabit.map(({ habit, completions }) => (
              <HabitRow
                key={habit.id}
                habit={habit}
                completions={completions}
                onToggleCompletion={onToggleCompletion}
              />
            ))}
          </TableBody>
        </Table>
      </div>
    )
  },
)

HabitHistoryTable.displayName = "HabitHistoryTable"

// Memoize the skeleton component to prevent unnecessary re-renders
const TableLoadingSkeleton = memo(({ daysInMonth }: { daysInMonth: Date[] }) => {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="sticky left-0 bg-white dark:bg-background z-10">Habit</TableHead>
            <TableHead className="sticky left-28 bg-white dark:bg-background z-10">Difficulty</TableHead>
            {daysInMonth.map((day) => (
              <TableHead key={day.toString()} className="text-center min-w-[60px]">
                <div className="flex flex-col items-center">
                  <span>{format(day, "d")}</span>
                  <span className="text-xs text-muted-foreground">{format(day, "EEE")}</span>
                </div>
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {[1, 2, 3].map((_, index) => (
            <TableRow key={index}>
              <TableCell className="sticky left-0 bg-white dark:bg-background z-10">
                <Skeleton className="h-5 w-24" />
              </TableCell>
              <TableCell className="sticky left-28 bg-white dark:bg-background z-10">
                <Skeleton className="h-5 w-16" />
              </TableCell>
              {daysInMonth.map((day, i) => (
                <TableCell key={i} className="text-center p-2">
                  <Skeleton className="h-5 w-5 rounded-full mx-auto" />
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
})

TableLoadingSkeleton.displayName = "TableLoadingSkeleton"

const TableCell = React.forwardRef<HTMLTableCellElement, React.TdHTMLAttributes<HTMLTableCellElement>>(
  ({ className, ...props }, ref) => (
    <td ref={ref} className="p-4 align-middle [&:has([role=checkbox])]:pr-0" {...props} />
  ),
)
TableCell.displayName = "TableCell"

