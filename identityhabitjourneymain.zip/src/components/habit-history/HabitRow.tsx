"use client"

import type React from "react"
import { memo } from "react"
import { TableRow, TableCell } from "@/components/ui/table"
import { CompletionStatus } from "./CompletionStatus"
import type { Habit } from "@/contexts/types"
import type { HabitCompletion } from "./types"

interface HabitRowProps {
  habit: Habit
  completions: HabitCompletion[]
  onToggleCompletion: (habit: Habit, date: Date, currentlyCompleted: boolean) => void
}

// Use memo to prevent unnecessary re-renders
export const HabitRow: React.FC<HabitRowProps> = memo(({ habit, completions, onToggleCompletion }) => {
  return (
    <TableRow>
      <TableCell className="font-medium sticky left-0 bg-white dark:bg-background z-10 min-w-[100px]">
        {habit.name}
      </TableCell>
      <TableCell className="sticky left-28 bg-white dark:bg-background z-10">
        <span
          className={`inline-block px-2 py-1 rounded text-xs ${
            habit.difficulty === "easy"
              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
              : habit.difficulty === "medium"
                ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100"
                : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100"
          }`}
        >
          {habit.difficulty}
        </span>
      </TableCell>
      {completions.map((completion) => (
        <TableCell key={completion.date.toString()} className="text-center p-2">
          <CompletionStatus
            habit={habit}
            date={completion.date}
            completed={completion.completed}
            onToggle={onToggleCompletion}
          />
        </TableCell>
      ))}
    </TableRow>
  )
})

HabitRow.displayName = "HabitRow"

