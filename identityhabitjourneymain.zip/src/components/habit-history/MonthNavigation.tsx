"use client"

import type React from "react"
import { format } from "date-fns"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface MonthNavigationProps {
  currentMonth: Date
  isCurrentMonth: boolean
  onPreviousMonth: () => void
  onNextMonth: () => void
}

export const MonthNavigation: React.FC<MonthNavigationProps> = ({
  currentMonth,
  isCurrentMonth,
  onPreviousMonth,
  onNextMonth,
}) => {
  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" size="icon" onClick={onPreviousMonth}>
        <ChevronLeft className="h-4 w-4" />
      </Button>
      <div className="w-32 text-center font-medium">{format(currentMonth, "MMMM yyyy")}</div>
      <Button variant="outline" size="icon" onClick={onNextMonth} disabled={isCurrentMonth}>
        <ChevronRight className="h-4 w-4" />
      </Button>
    </div>
  )
}

