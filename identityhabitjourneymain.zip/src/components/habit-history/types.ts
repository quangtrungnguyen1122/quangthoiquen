import type { Habit } from "@/contexts/types"

export interface HabitCompletion {
  habit: Habit
  date: Date
  completed: boolean
  id?: string // Optional ID field for database records
}

export interface HabitCompletionsByHabit {
  habit: Habit
  completions: HabitCompletion[]
}

export interface HabitCompletionRecord {
  id: string
  habit_id: string
  user_id: string
  completed_date: string
  completed: boolean
  created_at: string
  identity_id?: string // Added identity_id field
}

