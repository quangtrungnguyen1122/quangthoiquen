"use client"

import type React from "react"
import type { Habit } from "@/contexts/types"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Loader2 } from "lucide-react"

interface DeleteHabitDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  habitToDelete: Habit | null
  onConfirm: () => Promise<void>
  isDeleting: boolean
  isHabitInUse: (habit: Habit) => boolean
}

const DeleteHabitDialog: React.FC<DeleteHabitDialogProps> = ({
  open,
  onOpenChange,
  habitToDelete,
  onConfirm,
  isDeleting,
  isHabitInUse,
}) => {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
          <AlertDialogDescription>
            This will permanently delete the habit
            {habitToDelete ? ` "${habitToDelete.name}"` : ""}
            {habitToDelete && isHabitInUse(habitToDelete) ? " and remove it from all associated prices." : "."}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className="bg-destructive text-destructive-foreground"
            disabled={isDeleting}
          >
            {isDeleting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Deleting...
              </>
            ) : (
              "Delete"
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default DeleteHabitDialog

