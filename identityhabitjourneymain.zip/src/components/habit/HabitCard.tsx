"use client"

import type React from "react"
import type { Habit, Price, Identity } from "@/contexts/types"
import { Check, Edit, Trash2 } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { HabitIdentitiesBadge } from "@/components/habit"

interface HabitCardProps {
  habit: Habit
  linkedPrices: Price[]
  linkedIdentities: Identity[]
  onEdit: (habit: Habit) => void
  onDelete: (habit: Habit) => void
}

const HabitCard: React.FC<HabitCardProps> = ({ habit, linkedPrices, linkedIdentities, onEdit, onDelete }) => {
  const isUsed = linkedPrices.length > 0 || linkedIdentities.length > 0

  const difficultyColor = {
    easy: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    hard: "bg-red-100 text-red-800",
  }[habit.difficulty]

  return (
    <Card className={`overflow-hidden transition-all ${isUsed ? "border-primary/20" : ""}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{habit.name}</CardTitle>
            <CardDescription className="text-sm line-clamp-1">{habit.description}</CardDescription>
          </div>
          {isUsed && (
            <Badge variant="outline" className="border-primary text-primary">
              <Check className="h-3 w-3 mr-1" /> In Use
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="secondary" className={difficultyColor}>
            {habit.difficulty}
          </Badge>
          <Badge variant="secondary">{habit.points} points</Badge>
          <Badge variant="secondary">{habit.completionFrequency}</Badge>
        </div>

        {linkedPrices.length > 0 && (
          <div className="mt-3">
            <p className="text-xs text-muted-foreground mb-1">Used in prices:</p>
            <div className="flex flex-wrap gap-1">
              {linkedPrices.slice(0, 3).map((price) => (
                <Badge key={price.id} variant="outline" className="text-xs">
                  {price.name}
                </Badge>
              ))}
              {linkedPrices.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{linkedPrices.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        <HabitIdentitiesBadge identities={linkedIdentities} />
      </CardContent>
      <CardFooter className="pt-2">
        <div className="flex">
          <Button variant="ghost" size="sm" className="mr-2" onClick={() => onEdit(habit)}>
            <Edit className="h-4 w-4 mr-1" />
            Edit
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive/90 hover:bg-destructive/10"
            onClick={() => onDelete(habit)}
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Delete
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

export default HabitCard

