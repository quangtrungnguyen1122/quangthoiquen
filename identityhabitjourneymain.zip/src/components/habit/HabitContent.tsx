import HabitHeader from "./HabitHeader"
import RelatedPrices from "./RelatedPrices"
import type { Habit, Price } from "@/contexts/types"
import type { HabitDetailDialogState } from "@/hooks/habit/useHabitDetailPage"

interface HabitContentProps {
  habit: Habit
  relatedPrices: Price[]
  dialogState: HabitDetailDialogState
  onUnlinkPrice: (priceId: string, habitId: string) => Promise<void>
}

const HabitContent = ({ habit, relatedPrices, dialogState, onUnlinkPrice }: HabitContentProps) => {
  return (
    <>
      <HabitHeader
        name={habit.name}
        description={habit.description}
        completed={habit.completed}
        difficulty={habit.difficulty}
        points={habit.points}
      />

      <RelatedPrices
        prices={relatedPrices}
        habitId={habit.id}
        onUnlinkPrice={onUnlinkPrice}
        isUnlinking={dialogState.isUnlinking}
      />
    </>
  )
}

export default HabitContent

