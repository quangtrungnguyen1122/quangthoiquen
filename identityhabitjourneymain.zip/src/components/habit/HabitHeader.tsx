import { Target } from "lucide-react"
import { cn } from "@/lib/utils"

interface HabitHeaderProps {
  name: string
  description: string
  completed: boolean
  difficulty: string
  points: number
}

const HabitHeader = ({ name, description, completed, difficulty, points }: HabitHeaderProps) => {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-4 mb-2">
        <div
          className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center",
            completed ? "bg-primary/20" : "bg-muted",
          )}
        >
          <Target className={cn("w-6 h-6", completed ? "text-primary" : "text-muted-foreground")} />
        </div>
        <div className="text-left">
          <h1 className="text-2xl font-bold">{name}</h1>
          <div className="text-muted-foreground">
            {difficulty} · {points} points {completed && "· Completed"}
          </div>
        </div>
      </div>
      <p className="text-muted-foreground mt-2 mb-6 text-left pl-16">{description}</p>
    </div>
  )
}

export default HabitHeader

