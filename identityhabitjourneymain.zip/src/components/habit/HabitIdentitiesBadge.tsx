import type React from "react"
import { Badge } from "@/components/ui/badge"
import type { Identity } from "@/contexts/types"

interface HabitIdentitiesBadgeProps {
  identities: Identity[]
}

const HabitIdentitiesBadge: React.FC<HabitIdentitiesBadgeProps> = ({ identities }) => {
  if (!identities || identities.length === 0) return null

  return (
    <div className="mt-3">
      <p className="text-xs text-muted-foreground mb-1">Used in identities:</p>
      <div className="flex flex-wrap gap-1">
        {identities.slice(0, 3).map((identity) => (
          <Badge key={identity.id} variant="outline" className="text-xs">
            {identity.name}
          </Badge>
        ))}
        {identities.length > 3 && (
          <Badge variant="outline" className="text-xs">
            +{identities.length - 3} more
          </Badge>
        )}
      </div>
    </div>
  )
}

export default HabitIdentitiesBadge

