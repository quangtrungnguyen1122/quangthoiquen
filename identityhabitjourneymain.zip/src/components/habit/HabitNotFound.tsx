"use client"
import { useNavigate } from "react-router-dom"
import { XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

const HabitNotFound = () => {
  const navigate = useNavigate()

  return (
    <div className="flex flex-col items-center justify-center h-[80vh] space-y-6">
      <XCircle className="w-16 h-16 text-destructive" />

      <div className="text-center">
        <h1 className="text-2xl font-bold mb-2">Habit Not Found</h1>
        <p className="text-muted-foreground mb-6">The habit you're looking for doesn't exist or has been deleted.</p>

        <div className="flex space-x-4 justify-center">
          <Button onClick={() => navigate("/")}>Back to Dashboard</Button>
        </div>
      </div>
    </div>
  )
}

export default HabitNotFound

