"use client"
import { Award, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import GlassCard from "@/components/ui-custom/GlassCard"
import type { Price } from "@/contexts/types"

interface RelatedPricesProps {
  prices: Price[]
  habitId: string
  onUnlinkPrice: (priceId: string, habitId: string) => Promise<void>
  isUnlinking: boolean
}

const RelatedPrices = ({ prices, habitId, onUnlinkPrice, isUnlinking }: RelatedPricesProps) => {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-2 mb-6">
        <Award className="w-5 h-5 text-primary" />
        <h2 className="text-xl font-semibold">Related Prices</h2>
      </div>

      {prices.length > 0 ? (
        <div className="space-y-4">
          {prices.map((price) => (
            <GlassCard key={price.id} className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <Award className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div>
                    <div className="font-medium">{price.name}</div>
                    <div className="text-sm text-muted-foreground">{price.description}</div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  onClick={() => onUnlinkPrice(price.id, habitId)}
                  disabled={isUnlinking}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </GlassCard>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 bg-card rounded-lg border border-border">
          <p className="text-muted-foreground">This habit is not linked to any prices yet.</p>
        </div>
      )}
    </div>
  )
}

export default RelatedPrices

