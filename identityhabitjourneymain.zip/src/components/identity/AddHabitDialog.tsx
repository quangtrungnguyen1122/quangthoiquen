"use client"

import { useState } from "react"
import { Loader2, Plus } from "lucide-react"
import type { Price, Habit } from "@/contexts/types"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"

interface AddHabitDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  selectedPriceId: string
  onSelectPrice: (priceId: string) => void
  selectedHabitId: string
  onSelectHabit: (habitId: string) => void
  availableHabits: Habit[]
  relatedPrices: Price[]
  needPriceSelection: boolean
  onAddHabit: () => void
  onCreateAndAddHabit: (name: string, description: string, difficulty: "easy" | "medium" | "hard") => Promise<void>
  isLinking: boolean
}

const AddHabitDialog = ({
  open,
  onOpenChange,
  selectedPriceId,
  onSelectPrice,
  selectedHabitId,
  onSelectHabit,
  availableHabits,
  relatedPrices,
  needPriceSelection,
  onAddHabit,
  onCreateAndAddHabit,
  isLinking,
}: AddHabitDialogProps) => {
  const [activeTab, setActiveTab] = useState<string>(availableHabits.length > 0 ? "existing" : "new")
  const [newHabitName, setNewHabitName] = useState("")
  const [newHabitDescription, setNewHabitDescription] = useState("")
  const [newHabitDifficulty, setNewHabitDifficulty] = useState<"easy" | "medium" | "hard">("medium")

  const handleSubmit = () => {
    if (activeTab === "existing") {
      onAddHabit()
    } else {
      onCreateAndAddHabit(newHabitName, newHabitDescription, newHabitDifficulty)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Link Habit to Price</DialogTitle>
          <DialogDescription>
            {selectedPriceId
              ? `Select or create a habit to link to ${relatedPrices.find((p) => p.id === selectedPriceId)?.name}.`
              : "First select a price, then select or create a habit to link to it."}
          </DialogDescription>
        </DialogHeader>

        {needPriceSelection && (
          <div className="mb-4">
            <Label htmlFor="price-select" className="block text-sm font-medium text-muted-foreground mb-2">
              Select a Price
            </Label>
            <Select value={selectedPriceId} onValueChange={onSelectPrice}>
              <SelectTrigger id="price-select">
                <SelectValue placeholder="Select a price" />
              </SelectTrigger>
              <SelectContent>
                {relatedPrices.map((price) => (
                  <SelectItem key={price.id} value={price.id}>
                    {price.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="existing" disabled={availableHabits.length === 0}>
              Select Existing
            </TabsTrigger>
            <TabsTrigger value="new">Create New</TabsTrigger>
          </TabsList>

          <TabsContent value="existing" className="py-4">
            <Select value={selectedHabitId} onValueChange={onSelectHabit} disabled={!selectedPriceId}>
              <SelectTrigger id="habit-select">
                <SelectValue placeholder="Select a habit" />
              </SelectTrigger>
              <SelectContent>
                {availableHabits.map((habit) => (
                  <SelectItem key={habit.id} value={habit.id}>
                    {habit.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </TabsContent>

          <TabsContent value="new" className="py-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="new-habit-name">Habit Name</Label>
              <Input
                id="new-habit-name"
                value={newHabitName}
                onChange={(e) => setNewHabitName(e.target.value)}
                placeholder="Enter habit name"
                disabled={!selectedPriceId}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-habit-description">Description</Label>
              <Textarea
                id="new-habit-description"
                value={newHabitDescription}
                onChange={(e) => setNewHabitDescription(e.target.value)}
                placeholder="Enter habit description"
                rows={3}
                disabled={!selectedPriceId}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-habit-difficulty">Difficulty</Label>
              <Select
                value={newHabitDifficulty}
                onValueChange={(value) => setNewHabitDifficulty(value as "easy" | "medium" | "hard")}
                disabled={!selectedPriceId}
              >
                <SelectTrigger id="new-habit-difficulty">
                  <SelectValue placeholder="Select difficulty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="easy">Easy (5 points)</SelectItem>
                  <SelectItem value="medium">Medium (10 points)</SelectItem>
                  <SelectItem value="hard">Hard (15 points)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLinking}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={
              isLinking ||
              !selectedPriceId ||
              (activeTab === "existing" && !selectedHabitId) ||
              (activeTab === "new" && (!newHabitName || !newHabitDescription))
            }
          >
            {isLinking ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Linking...
              </>
            ) : (
              <>
                <Plus className="mr-2 h-4 w-4" />
                {activeTab === "existing" ? "Link Habit" : "Create & Link Habit"}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export default AddHabitDialog

