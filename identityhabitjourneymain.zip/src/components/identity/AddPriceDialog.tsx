"use client"

import { useState } from "react"
import { Loader2, Plus } from "lucide-react"
import type { Price } from "@/contexts/types"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"

interface AddPriceDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  selectedPriceId: string
  onSelectPrice: (priceId: string) => void
  availablePrices: Price[]
  onAddPrice: () => void
  onCreateAndAddPrice: (name: string, description: string) => Promise<void>
  isLinking: boolean
}

const AddPriceDialog = ({
  open,
  onOpenChange,
  selectedPriceId,
  onSelectPrice,
  availablePrices,
  onAddPrice,
  onCreateAndAddPrice,
  isLinking,
}: AddPriceDialogProps) => {
  const [activeTab, setActiveTab] = useState<string>(availablePrices.length > 0 ? "existing" : "new")
  const [newPriceName, setNewPriceName] = useState("")
  const [newPriceDescription, setNewPriceDescription] = useState("")

  const handleSubmit = () => {
    if (activeTab === "existing") {
      onAddPrice()
    } else {
      onCreateAndAddPrice(newPriceName, newPriceDescription)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add Price to Identity</DialogTitle>
          <DialogDescription>Select an existing price or create a new one to add to this identity.</DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="existing" disabled={availablePrices.length === 0}>
              Select Existing
            </TabsTrigger>
            <TabsTrigger value="new">Create New</TabsTrigger>
          </TabsList>

          <TabsContent value="existing" className="py-4">
            <Select value={selectedPriceId} onValueChange={onSelectPrice}>
              <SelectTrigger>
                <SelectValue placeholder="Select a price" />
              </SelectTrigger>
              <SelectContent>
                {availablePrices.map((price) => (
                  <SelectItem key={price.id} value={price.id}>
                    {price.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </TabsContent>

          <TabsContent value="new" className="py-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="new-price-name">Price Name</Label>
              <Input
                id="new-price-name"
                value={newPriceName}
                onChange={(e) => setNewPriceName(e.target.value)}
                placeholder="Enter price name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-price-description">Description</Label>
              <Textarea
                id="new-price-description"
                value={newPriceDescription}
                onChange={(e) => setNewPriceDescription(e.target.value)}
                placeholder="Enter price description"
                rows={3}
              />
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLinking}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={
              isLinking ||
              (activeTab === "existing" && !selectedPriceId) ||
              (activeTab === "new" && (!newPriceName || !newPriceDescription))
            }
          >
            {isLinking ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Adding...
              </>
            ) : (
              <>
                <Plus className="mr-2 h-4 w-4" />
                {activeTab === "existing" ? "Add Price" : "Create & Add Price"}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export default AddPriceDialog

