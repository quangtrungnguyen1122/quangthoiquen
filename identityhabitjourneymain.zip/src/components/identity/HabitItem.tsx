"use client"
import { Check, Target, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import type { Habit } from "@/contexts/types"

interface HabitItemProps {
  habit: Habit
  onCompleteHabit: (habitId: string) => void
  onUnlinkHabit: (priceId: string, habitId: string) => Promise<void>
  onEditHabit?: (habit: Habit) => void
  priceId: string
  isUnlinking: boolean
}

const HabitItem = ({ habit, onCompleteHabit, onUnlinkHabit, priceId, isUnlinking }: HabitItemProps) => {
  return (
    <div className="bg-background border border-border rounded-md p-3 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <button
          onClick={() => !habit.completed && onCompleteHabit(habit.id)}
          disabled={habit.completed}
          className={cn(
            "w-8 h-8 rounded-full flex items-center justify-center",
            habit.completed ? "bg-primary/20" : "bg-muted cursor-pointer hover:bg-primary/10",
          )}
        >
          {habit.completed ? (
            <Check className="w-4 h-4 text-primary" />
          ) : (
            <Target className="w-4 h-4 text-muted-foreground" />
          )}
        </button>
        <div className="text-left">
          <div className="font-medium text-sm">{habit.name}</div>
          <div className="text-xs text-muted-foreground">
            {habit.difficulty} · {habit.points} points
          </div>
        </div>
      </div>
      <div className="flex items-center gap-1">
        {/* Removed the edit button */}
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-muted-foreground hover:text-destructive"
          onClick={() => onUnlinkHabit(priceId, habit.id)}
          disabled={isUnlinking}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

export default HabitItem

