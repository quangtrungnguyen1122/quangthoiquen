"use client"
import { Award, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import IdentityHeader from "@/components/identity/IdentityHeader"
import IdentityStats from "@/components/identity/IdentityStats"
import AddPriceDialog from "@/components/identity/AddPriceDialog"
import AddHabitDialog from "@/components/identity/AddHabitDialog"
import type { Identity, Price } from "@/contexts/types"
import type { IdentityDetailDialogState, IdentityDetailHandlers } from "@/hooks/identity/useIdentityDetailPage"
import PriceWithHabits from "./PriceWithHabits"

interface IdentityContentProps {
  identity: Identity
  relatedPrices: Price[]
  dialogState: IdentityDetailDialogState
  handlers: IdentityDetailHandlers
}

const IdentityContent = ({ identity, relatedPrices, dialogState, handlers }: IdentityContentProps) => {
  return (
    <>
      <IdentityHeader name={identity.name} description={identity.description} avatar={identity.avatar} />

      <IdentityStats progress={identity.progress} streak={identity.streak} highestStreak={identity.highestStreak} />

      <div className="mb-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-semibold">Prices</h2>
          </div>
          <Button
            size="sm"
            variant="outline"
            className="flex items-center gap-1"
            onClick={handlers.onOpenAddPriceDialog}
          >
            <Plus className="w-4 h-4" />
            <span>Add Price</span>
          </Button>
        </div>

        <div className="space-y-4">
          {relatedPrices.length > 0 ? (
            <div className="space-y-4">
              {relatedPrices.map((price) => (
                <PriceWithHabits
                  key={price.id}
                  price={price}
                  habits={handlers.getHabitsByPriceId(price.id)}
                  onAddHabit={handlers.onOpenAddHabitDialog}
                  onCompleteHabit={handlers.onCompleteHabit}
                  onUnlinkHabit={handlers.onUnlinkHabit}
                  onRemovePrice={(priceId) => handlers.onRemovePrice(priceId)}
                  // Removing the edit-related props:
                  // onEditPrice={handlers.onEditPrice}
                  // onEditHabit={handlers.onEditHabit}
                  isUnlinking={dialogState.isUnlinking}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No prices linked to this identity yet.</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Price Dialog */}
      <AddPriceDialog
        open={dialogState.isAddPriceDialogOpen}
        onOpenChange={handlers.setAddPriceDialogOpen}
        selectedPriceId={dialogState.selectedPriceId}
        onSelectPrice={handlers.onSelectPriceId}
        availablePrices={dialogState.availablePrices}
        onAddPrice={handlers.onAddPrice}
        onCreateAndAddPrice={handlers.onCreateAndAddPrice}
        isLinking={dialogState.isLinking}
      />

      {/* Add Habit Dialog */}
      <AddHabitDialog
        open={dialogState.isAddHabitDialogOpen}
        onOpenChange={handlers.setAddHabitDialogOpen}
        selectedPriceId={dialogState.selectedPriceId}
        onSelectPrice={handlers.onSelectPriceId}
        selectedHabitId={dialogState.selectedHabitId}
        onSelectHabit={handlers.onSelectHabitId}
        availableHabits={dialogState.availableHabits}
        relatedPrices={relatedPrices}
        needPriceSelection={!dialogState.selectedPriceId}
        onAddHabit={handlers.onAddHabit}
        onCreateAndAddHabit={handlers.onCreateAndAddHabit}
        isLinking={dialogState.isLinking}
      />
    </>
  )
}

export default IdentityContent

