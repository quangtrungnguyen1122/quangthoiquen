"use client"
import { Link } from "react-router-dom"
import { ArrowLeft, Target } from "lucide-react"
import { motion } from "framer-motion"

interface IdentityHeaderProps {
  name: string
  description: string
  avatar?: string
}

const IdentityHeader = ({ name, description, avatar }: IdentityHeaderProps) => {
  return (
    <div className="my-8">
      <Link
        to="/identity"
        className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors duration-200 mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Identities</span>
      </Link>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
        <div className="flex items-start gap-6">
          <div className="w-16 h-16 rounded-full border-2 border-border bg-muted/50 flex items-center justify-center flex-shrink-0">
            {avatar ? (
              <img src={avatar} alt={name} className="w-full h-full rounded-full object-cover" />
            ) : (
              <Target className="w-8 h-8 text-primary" />
            )}
          </div>

          <div className="text-left">
            <h1 className="text-3xl font-bold tracking-tight">{name}</h1>
            <p className="text-muted-foreground mt-2 max-w-3xl">{description}</p>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

export default IdentityHeader

