import { Link } from "react-router-dom"
import Navbar from "@/components/layout/Navbar"
import PageTransition from "@/components/layout/PageTransition"

const IdentityNotFound = () => {
  return (
    <>
      <Navbar />
      <PageTransition>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Identity not found</h1>
            <Link to="/" className="text-primary hover:underline">
              Back to Dashboard
            </Link>
          </div>
        </div>
      </PageTransition>
    </>
  )
}

export default IdentityNotFound

