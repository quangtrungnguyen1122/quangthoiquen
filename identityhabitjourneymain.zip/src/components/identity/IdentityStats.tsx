import { Trophy } from "lucide-react"
import GlassCard from "@/components/ui-custom/GlassCard"
import ProgressRing from "@/components/dashboard/ProgressRing"
import { getProgressColorClass } from "@/utils/habitUtils"

interface IdentityStatsProps {
  progress: number
  streak: number
  highestStreak: number
}

const IdentityStats = ({ progress, streak, highestStreak }: IdentityStatsProps) => {
  // Get the appropriate color class based on progress percentage
  const progressColorClass = getProgressColorClass(progress)

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
      <GlassCard className="flex items-center gap-5">
        <ProgressRing progress={progress} size={80} strokeWidth={6} color={progressColorClass} />
        <div>
          <div className="text-sm text-muted-foreground">Overall Progress</div>
          <div className="text-2xl font-semibold">{progress}%</div>
          <div className="text-xs text-muted-foreground">Based on completed habits</div>
        </div>
      </GlassCard>

      <GlassCard className="flex items-center gap-5">
        <div className="p-4 rounded-full bg-primary/10">
          <Trophy className="w-10 h-10 text-primary" />
        </div>
        <div>
          <div className="text-sm text-muted-foreground">Current Streak</div>
          <div className="text-2xl font-semibold flex items-center gap-1">
            <span>{streak}</span>
            <span className="text-sm text-muted-foreground">days</span>
          </div>
        </div>
      </GlassCard>

      <GlassCard className="flex items-center gap-5">
        <div className="p-4 rounded-full bg-primary/10">
          <Trophy className="w-10 h-10 text-primary" />
        </div>
        <div>
          <div className="text-sm text-muted-foreground">Highest Streak</div>
          <div className="text-2xl font-semibold flex items-center gap-1">
            <span>{highestStreak}</span>
            <span className="text-sm text-muted-foreground">days</span>
          </div>
        </div>
      </GlassCard>
    </div>
  )
}

export default IdentityStats

