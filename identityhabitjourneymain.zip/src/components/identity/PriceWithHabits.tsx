"use client"
import { Award, Plus, X } from "lucide-react"
import GlassCard from "@/components/ui-custom/GlassCard"
import { Button } from "@/components/ui/button"
import type { Price, Habit } from "@/contexts/types"
import HabitItem from "./HabitItem"

interface PriceWithHabitsProps {
  price: Price
  habits: Habit[]
  onAddHabit: (priceId: string) => void
  onCompleteHabit: (habitId: string) => void
  onUnlinkHabit: (priceId: string, habitId: string) => Promise<void>
  onRemovePrice?: (priceId: string) => Promise<void>
  onEditPrice?: (price: Price) => void
  onEditHabit?: (habit: Habit) => void
  isUnlinking: boolean
}

const PriceWithHabits = ({
  price,
  habits,
  onAddHabit,
  onCompleteHabit,
  onUnlinkHabit,
  onRemovePrice,
  isUnlinking,
}: PriceWithHabitsProps) => {
  return (
    <GlassCard key={price.id} className="px-4 pt-4 pb-2">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full flex items-center justify-center bg-muted">
            <Award className="w-5 h-5 text-muted-foreground" />
          </div>
          <div className="text-left">
            <div className="font-medium">{price.name}</div>
            <div className="text-xs text-muted-foreground">{price.description}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Removed the edit button */}
          {onRemovePrice && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-destructive"
              onClick={() => onRemovePrice(price.id)}
              disabled={isUnlinking}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Display habits linked to this price */}
      <div className="pl-10 space-y-2 mb-2">
        {habits.length > 0 ? (
          <div className="space-y-2">
            {habits.map((habit) => (
              <HabitItem
                key={habit.id}
                habit={habit}
                priceId={price.id}
                onCompleteHabit={onCompleteHabit}
                onUnlinkHabit={onUnlinkHabit}
                isUnlinking={isUnlinking}
              />
            ))}
          </div>
        ) : (
          <div className="text-sm text-muted-foreground py-2 text-left">No habits linked to this price yet.</div>
        )}
        <Button variant="ghost" size="sm" className="text-xs ml-1 mt-1" onClick={() => onAddHabit(price.id)}>
          <Plus className="w-3 h-3 mr-1" />
          Add Habit
        </Button>
      </div>
    </GlassCard>
  )
}

export default PriceWithHabits

