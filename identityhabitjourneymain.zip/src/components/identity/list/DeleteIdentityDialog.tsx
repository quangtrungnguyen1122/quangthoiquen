"use client"

import type React from "react"
import type { Identity } from "@/contexts/types"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface DeleteIdentityDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  identityToDelete: Identity | null
  onConfirm: () => Promise<void>
  isIdentityInUse: (identity: Identity) => boolean
}

export const DeleteIdentityDialog: React.FC<DeleteIdentityDialogProps> = ({
  open,
  onOpenChange,
  identityToDelete,
  onConfirm,
  isIdentityInUse,
}) => {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
          <AlertDialogDescription>
            This will permanently delete the identity
            {identityToDelete ? ` "${identityToDelete.name}"` : ""}
            {identityToDelete && isIdentityInUse(identityToDelete) ? " and remove it from all associated prices." : "."}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} className="bg-destructive text-destructive-foreground">
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

