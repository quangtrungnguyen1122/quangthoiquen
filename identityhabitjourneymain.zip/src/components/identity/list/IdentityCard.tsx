"use client"

import type React from "react"
import type { Identity } from "@/contexts/types"
import { Check, Edit, Target, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface IdentityCardProps {
  identity: Identity
  linkedPrices: any[]
  onEdit: (identity: Identity) => void
  onDelete: (identity: Identity) => void
  onViewDetails: (identityId: string) => void
}

export const IdentityCard: React.FC<IdentityCardProps> = ({
  identity,
  linkedPrices,
  onEdit,
  onDelete,
  onViewDetails,
}) => {
  const isUsed = linkedPrices.length > 0

  return (
    <Card className={`overflow-hidden transition-all ${isUsed ? "border-primary/20" : ""}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-primary/10 overflow-hidden">
              {identity.avatar ? (
                <img
                  src={identity.avatar}
                  alt={identity.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement
                    target.src = "/placeholder.svg"
                  }}
                />
              ) : (
                <Target className="h-5 w-5 text-primary" />
              )}
            </div>
            <div>
              <CardTitle className="text-lg">{identity.name}</CardTitle>
              <CardDescription className="text-sm line-clamp-1">{identity.description}</CardDescription>
            </div>
          </div>
          {isUsed && (
            <Badge variant="outline" className="border-primary text-primary">
              <Check className="h-3 w-3 mr-1" /> Active
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="secondary">Streak: {identity.streak}</Badge>
          <Badge variant="secondary">Progress: {identity.progress}%</Badge>
        </div>

        {isUsed && linkedPrices.length > 0 && (
          <div className="mt-3">
            <p className="text-xs text-muted-foreground mb-1">Linked prices:</p>
            <div className="flex flex-wrap gap-1">
              {linkedPrices.slice(0, 3).map((price) => (
                <Badge key={price.id} variant="outline" className="text-xs">
                  {price.name}
                </Badge>
              ))}
              {linkedPrices.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{linkedPrices.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="pt-2 flex justify-between">
        <div>
          <Button variant="ghost" size="sm" className="mr-2" onClick={() => onEdit(identity)}>
            <Edit className="h-4 w-4 mr-1" />
            Edit
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive/90 hover:bg-destructive/10"
            onClick={() => onDelete(identity)}
          >
            <Trash2 className="h-4 w-4 mr-1" />
            Delete
          </Button>
        </div>
        <Button variant="outline" size="sm" onClick={() => onViewDetails(identity.id)}>
          View Details
        </Button>
      </CardFooter>
    </Card>
  )
}

