"use client"

import type React from "react"
import type { Identity } from "@/contexts/types"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

const identityFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
  avatar: z.string().optional(),
})

type IdentityFormValues = z.infer<typeof identityFormSchema>

interface IdentityFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (values: IdentityFormValues) => Promise<void>
  editingIdentity: Identity | null
}

export const IdentityFormDialog: React.FC<IdentityFormDialogProps> = ({
  open,
  onOpenChange,
  onSubmit,
  editingIdentity,
}) => {
  const form = useForm<IdentityFormValues>({
    resolver: zodResolver(identityFormSchema),
    defaultValues: {
      name: editingIdentity?.name || "",
      description: editingIdentity?.description || "",
      avatar: editingIdentity?.avatar || "",
    },
  })

  const handleClose = () => {
    form.reset()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{editingIdentity ? "Edit Identity" : "Add New Identity"}</DialogTitle>
          <DialogDescription>
            {editingIdentity
              ? "Update the identity details below."
              : "Create a new identity by filling out the form below."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Identity name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe the identity" {...field} className="resize-none" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="avatar"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Avatar URL (optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter avatar URL" {...field} />
                  </FormControl>
                  <FormDescription>Provide a URL to an image for this identity</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            {form.watch("avatar") && (
              <div className="flex justify-center">
                <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-border">
                  <img
                    src={form.watch("avatar")}
                    alt="Avatar preview"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.src = "/placeholder.svg"
                    }}
                  />
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" type="button" onClick={handleClose}>
                Cancel
              </Button>
              <Button type="submit">{editingIdentity ? "Save Changes" : "Add Identity"}</Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

