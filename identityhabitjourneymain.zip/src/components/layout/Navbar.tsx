import type React from "react"
import { Link } from "react-router-dom"

const Navbar: React.FC = () => {
  const navLinks = [
    { href: "/", label: "Dashboard" },
    { href: "/identity", label: "Identities" },
    { href: "/prices", label: "Prices" },
    { href: "/habits", label: "Habits" },
    { href: "/habit-history", label: "History" }, // Add this line
    { href: "/leaderboard", label: "Leaderboard" },
    { href: "/user", label: "Profile" },
  ]

  return (
    <nav className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link to="/" className="text-xl font-bold text-gray-800">
                Habit Tracker
              </Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    to={link.href}
                    className="text-gray-600 hover:bg-gray-100 hover:text-gray-800 px-3 py-2 rounded-md text-sm font-medium"
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar

