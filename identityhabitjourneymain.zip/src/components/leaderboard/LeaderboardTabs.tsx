"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserRankList } from "./UserRankList"
import type { Identity } from "@/contexts/types"

interface LeaderboardTabsProps {
  activeTab: string
  setActiveTab: (value: string) => void
  rankedUsers: any[]
  identities: Identity[]
}

export const LeaderboardTabs = ({ activeTab, setActiveTab, rankedUsers, identities }: LeaderboardTabsProps) => {
  return (
    <Tabs defaultValue="7-days" value={activeTab} onValueChange={setActiveTab} className="mb-6">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="all-time">All Time</TabsTrigger>
        <TabsTrigger value="30-days">Last 30 Days</TabsTrigger>
        <TabsTrigger value="7-days">Last 7 Days</TabsTrigger>
      </TabsList>

      <TabsContent value="all-time">
        <UserRankList users={rankedUsers} timeframe="all-time" identities={identities} />
      </TabsContent>

      <TabsContent value="30-days">
        <UserRankList users={rankedUsers} timeframe="30-days" identities={identities} />
      </TabsContent>

      <TabsContent value="7-days">
        <UserRankList users={rankedUsers} timeframe="7-days" identities={identities} />
      </TabsContent>
    </Tabs>
  )
}

