import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Flame, Award } from "lucide-react"
import type { Identity } from "@/contexts/types"
import { getStreakForTimeframe, getScoreForTimeframe } from "./leaderboardUtils"

interface UserRankCardProps {
  user: any
  timeframe: "all-time" | "30-days" | "7-days"
  identities: Identity[]
}

export const UserRankCard = ({ user, timeframe, identities }: UserRankCardProps) => {
  if (!user) return null

  const streak = getStreakForTimeframe(user, timeframe, identities)
  console.log("User rank card - streak calculated:", streak, "for user:", user.id, "timeframe:", timeframe)

  return (
    <Card className="mb-8 bg-primary/5 border-primary/20">
      <CardContent className="p-6">
        <h2 className="text-lg font-medium mb-4">Your Position</h2>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Avatar className="h-16 w-16 border-2 border-primary">
              <AvatarImage src={user.avatar} alt={user.username} />
              <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="absolute -top-2 -right-2 bg-primary text-white rounded-full w-7 h-7 flex items-center justify-center text-sm font-bold">
              #{user.position}
            </div>
          </div>
          <div>
            <div className="font-medium">{user.username}</div>
            <div className="text-sm text-muted-foreground">Joined {new Date(user.joinedDate).toLocaleDateString()}</div>
            <div className="mt-1 flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-500" />
              <span className="font-medium">{streak}</span>
              <span className="text-xs text-muted-foreground">Current Streak</span>
            </div>
            <div className="mt-1 flex items-center gap-2">
              <Award className="w-4 h-4 text-primary" />
              <span className="font-medium">{getScoreForTimeframe(user, timeframe)}</span>
              <span className="text-xs text-muted-foreground">points</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

