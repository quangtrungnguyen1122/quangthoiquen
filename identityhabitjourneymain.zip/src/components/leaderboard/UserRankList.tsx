import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Flame } from "lucide-react"
import type { Identity } from "@/contexts/types"
import { getStreakForTimeframe, getScoreForTimeframe } from "./leaderboardUtils"

interface UserRankListProps {
  users: any[]
  timeframe: "all-time" | "30-days" | "7-days"
  identities: Identity[]
}

export const UserRankList = ({ users, timeframe, identities }: UserRankListProps) => {
  if (!users || users.length === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-muted-foreground">No users found.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {users.map((user) => {
        const streak = getStreakForTimeframe(user, timeframe, identities)

        return (
          <Card key={user.id} className={user.isCurrentUser ? "bg-primary/5 border-primary/20" : ""}>
            <CardContent className="p-4 md:p-6 flex items-center gap-4">
              <div className="flex-shrink-0 w-8 text-center font-bold text-lg text-muted-foreground">
                {user.position}
              </div>
              <Avatar className="h-12 w-12">
                <AvatarImage src={user.avatar} alt={user.username} />
                <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{user.username}</div>
                <div className="text-xs text-muted-foreground">
                  Joined {new Date(user.joinedDate).toLocaleDateString()}
                </div>
                <div className="flex items-center gap-1 mt-1">
                  <Flame className="w-3 h-3 text-amber-500" />
                  <span className="text-xs font-medium">{streak}</span>
                  <span className="text-xs text-muted-foreground">Current Streak</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-lg font-bold">{getScoreForTimeframe(user, timeframe)}</div>
                <div className="text-xs text-muted-foreground">points</div>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

