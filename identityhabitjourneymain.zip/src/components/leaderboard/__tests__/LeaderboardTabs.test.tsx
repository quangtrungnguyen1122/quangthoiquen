import { render, screen, fireEvent } from "@testing-library/react"
import { describe, it, expect, beforeEach, vi } from "vitest"
import { LeaderboardTabs } from "../LeaderboardTabs"

describe("LeaderboardTabs", () => {
  const mockSetActiveTab = vi.fn()
  const mockRankedUsers = [
    { id: "1", username: "user1", position: 1, joinedDate: "2023-01-01" },
    { id: "2", username: "user2", position: 2, joinedDate: "2023-01-02" },
  ]
  const mockIdentities = [
    {
      id: "1-identity1",
      name: "Identity 1",
      description: "",
      priceIds: [],
      streak: 5,
      highestStreak: 10,
      progress: 50,
    },
    { id: "2-identity1", name: "Identity 2", description: "", priceIds: [], streak: 3, highestStreak: 7, progress: 30 },
  ]

  beforeEach(() => {
    mockSetActiveTab.mockClear()
  })

  it("renders all time periods tabs", () => {
    render(
      <LeaderboardTabs
        activeTab="7-days"
        setActiveTab={mockSetActiveTab}
        rankedUsers={mockRankedUsers}
        identities={mockIdentities}
      />,
    )

    expect(screen.getByText("All Time")).toBeInTheDocument()
    expect(screen.getByText("Last 30 Days")).toBeInTheDocument()
    expect(screen.getByText("Last 7 Days")).toBeInTheDocument()
  })

  it("calls setActiveTab when a tab is clicked", () => {
    render(
      <LeaderboardTabs
        activeTab="7-days"
        setActiveTab={mockSetActiveTab}
        rankedUsers={mockRankedUsers}
        identities={mockIdentities}
      />,
    )

    fireEvent.click(screen.getByText("All Time"))
    expect(mockSetActiveTab).toHaveBeenCalledWith("all-time")

    fireEvent.click(screen.getByText("Last 30 Days"))
    expect(mockSetActiveTab).toHaveBeenCalledWith("30-days")
  })

  it("displays the correct content for the active tab", () => {
    render(
      <LeaderboardTabs
        activeTab="all-time"
        setActiveTab={mockSetActiveTab}
        rankedUsers={mockRankedUsers}
        identities={mockIdentities}
      />,
    )

    // This is a basic test that assumes UserRankList is rendering correctly
    // In a more comprehensive test suite, we might want to mock UserRankList
    // and verify it receives the correct props
    expect(screen.getByText("user1")).toBeInTheDocument()
    expect(screen.getByText("user2")).toBeInTheDocument()
  })
})

