import { render, screen, fireEvent } from "@testing-library/react"
import { describe, it, expect, beforeEach, vi } from "vitest"
import { SearchInput } from "../SearchInput"

describe("SearchInput", () => {
  const mockSetSearchQuery = vi.fn()

  beforeEach(() => {
    mockSetSearchQuery.mockClear()
  })

  it("renders with default placeholder", () => {
    render(<SearchInput searchQuery="" setSearchQuery={mockSetSearchQuery} />)

    expect(screen.getByPlaceholderText("Search players...")).toBeInTheDocument()
  })

  it("renders with custom placeholder", () => {
    render(<SearchInput searchQuery="" setSearchQuery={mockSetSearchQuery} placeholder="Custom placeholder" />)

    expect(screen.getByPlaceholderText("Custom placeholder")).toBeInTheDocument()
  })

  it("calls setSearchQuery when input changes", () => {
    render(<SearchInput searchQuery="" setSearchQuery={mockSetSearchQuery} />)

    const input = screen.getByPlaceholderText("Search players...")
    fireEvent.change(input, { target: { value: "test" } })

    expect(mockSetSearchQuery).toHaveBeenCalledWith("test")
  })

  it("shows clear button when there is search text", () => {
    render(<SearchInput searchQuery="test query" setSearchQuery={mockSetSearchQuery} />)

    const clearButton = screen.getByRole("button")
    expect(clearButton).toBeInTheDocument()

    fireEvent.click(clearButton)
    expect(mockSetSearchQuery).toHaveBeenCalledWith("")
  })

  it("does not show clear button when search is empty", () => {
    render(<SearchInput searchQuery="" setSearchQuery={mockSetSearchQuery} />)

    const clearButton = screen.queryByRole("button")
    expect(clearButton).not.toBeInTheDocument()
  })
})

