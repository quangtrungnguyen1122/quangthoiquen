import { render, screen } from "@testing-library/react"
import { describe, it, expect } from "vitest"
import { UserRankCard } from "../UserRankCard"

describe("UserRankCard", () => {
  const mockUser = {
    id: "1",
    username: "testuser",
    position: 3,
    joinedDate: "2023-01-15",
    avatar: "https://example.com/avatar.jpg",
    isCurrentUser: true,
  }

  const mockIdentities = [
    {
      id: "1-identity1",
      name: "Identity 1",
      description: "",
      priceIds: [],
      streak: 5,
      highestStreak: 10,
      progress: 50,
    },
  ]

  it("renders user position correctly", () => {
    render(<UserRankCard user={mockUser} timeframe="7-days" identities={mockIdentities} />)

    expect(screen.getByText("#3")).toBeInTheDocument()
  })

  it("renders user information correctly", () => {
    render(<UserRankCard user={mockUser} timeframe="7-days" identities={mockIdentities} />)

    expect(screen.getByText("testuser")).toBeInTheDocument()
    expect(screen.getByText(/Joined/)).toBeInTheDocument()
    expect(screen.getByText(/Current Streak/)).toBeInTheDocument()
    expect(screen.getByText(/points/)).toBeInTheDocument()
  })

  it("returns null when user is not provided", () => {
    const { container } = render(<UserRankCard user={null} timeframe="7-days" identities={mockIdentities} />)

    expect(container.firstChild).toBeNull()
  })
})

