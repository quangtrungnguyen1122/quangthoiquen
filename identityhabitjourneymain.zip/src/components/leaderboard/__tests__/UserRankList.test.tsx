import { render, screen } from "@testing-library/react"
import { describe, it, expect } from "vitest"
import { UserRankList } from "../UserRankList"

describe("UserRankList", () => {
  const mockUsers = [
    {
      id: "1",
      username: "user1",
      position: 1,
      joinedDate: "2023-01-01",
      isCurrentUser: true,
    },
    {
      id: "2",
      username: "user2",
      position: 2,
      joinedDate: "2023-01-02",
      isCurrentUser: false,
    },
  ]

  const mockIdentities = [
    {
      id: "1-identity1",
      name: "Identity 1",
      description: "",
      priceIds: [],
      streak: 5,
      highestStreak: 10,
      progress: 50,
    },
    { id: "2-identity1", name: "Identity 2", description: "", priceIds: [], streak: 3, highestStreak: 7, progress: 30 },
  ]

  it("renders a list of ranked users", () => {
    render(<UserRankList users={mockUsers} timeframe="7-days" identities={mockIdentities} />)

    expect(screen.getByText("user1")).toBeInTheDocument()
    expect(screen.getByText("user2")).toBeInTheDocument()
    expect(screen.getByText("1")).toBeInTheDocument() // Position for user1
    expect(screen.getByText("2")).toBeInTheDocument() // Position for user2
  })

  it("shows a message when no users are available", () => {
    render(<UserRankList users={[]} timeframe="7-days" identities={mockIdentities} />)

    expect(screen.getByText("No users found.")).toBeInTheDocument()
  })

  it("applies a different style to the current user", () => {
    render(<UserRankList users={mockUsers} timeframe="7-days" identities={mockIdentities} />)

    // We need to find the parent Card element that contains user1 text and check its class
    const user1Element = screen.getByText("user1").closest(".bg-primary/5")
    expect(user1Element).toBeInTheDocument()

    // User2 shouldn't have the highlight class
    const user2Text = screen.getByText("user2")
    const user2Element = user2Text.closest(".bg-primary/5")
    expect(user2Element).not.toBeInTheDocument()
  })
})

