import { describe, it, expect, beforeEach, vi } from "vitest"
import { getStreakForTimeframe, getScoreForTimeframe, getRankedUsers, getCurrentUserRank } from "../leaderboardUtils"
import { getHighestIdentityStreak, getHighestIdentityHistoricalStreak } from "@/services/streakService"

// Mock the streakService functions
vi.mock("@/services/streakService", () => ({
  getHighestIdentityStreak: vi.fn(),
  getHighestIdentityHistoricalStreak: vi.fn(),
}))

describe("leaderboardUtils", () => {
  const mockIdentities = [
    {
      id: "1-identity1",
      name: "Identity 1",
      description: "",
      priceIds: [],
      streak: 5,
      highestStreak: 10,
      progress: 50,
    },
    {
      id: "1-identity2",
      name: "Identity 2",
      description: "",
      priceIds: [],
      streak: 7,
      highestStreak: 15,
      progress: 75,
    },
  ]

  beforeEach(() => {
    vi.resetAllMocks()
    ;(getHighestIdentityStreak as any).mockReturnValue(7)
    ;(getHighestIdentityHistoricalStreak as any).mockReturnValue(15)
  })

  describe("getStreakForTimeframe", () => {
    it("returns the highest historical streak for all-time timeframe", () => {
      const user = { id: "1", username: "testuser" }
      const result = getStreakForTimeframe(user, "all-time", mockIdentities)

      expect(getHighestIdentityHistoricalStreak).toHaveBeenCalled()
      expect(result).toBe(15)
    })

    it("returns the highest current streak for other timeframes", () => {
      const user = { id: "1", username: "testuser" }
      const result = getStreakForTimeframe(user, "7-days", mockIdentities)

      expect(getHighestIdentityStreak).toHaveBeenCalled()
      expect(result).toBe(7)
    })

    it("returns 0 if user is not provided", () => {
      const result = getStreakForTimeframe(null, "7-days", mockIdentities)
      expect(result).toBe(0)
    })
  })

  describe("getScoreForTimeframe", () => {
    it("returns total points for all-time timeframe", () => {
      const user = { id: "1", username: "testuser", totalPoints: 1000 }
      const result = getScoreForTimeframe(user, "all-time")
      expect(result).toBe(1000)
    })

    it("returns last 30 days points for 30-days timeframe", () => {
      const user = { id: "1", username: "testuser", last30DaysPoints: 300 }
      const result = getScoreForTimeframe(user, "30-days")
      expect(result).toBe(300)
    })

    it("returns last 7 days points for 7-days timeframe", () => {
      const user = { id: "1", username: "testuser", last7DaysPoints: 100 }
      const result = getScoreForTimeframe(user, "7-days")
      expect(result).toBe(100)
    })

    it("returns 0 if user is not provided", () => {
      const result = getScoreForTimeframe(null, "7-days")
      expect(result).toBe(0)
    })
  })

  describe("getRankedUsers", () => {
    const mockUsers = [
      {
        id: "1",
        username: "user1",
        totalPoints: 1000,
        last30DaysPoints: 300,
        last7DaysPoints: 100,
      },
      {
        id: "2",
        username: "user2",
        totalPoints: 800,
        last30DaysPoints: 400,
        last7DaysPoints: 150,
      },
    ]

    it("returns empty array if no users are provided", () => {
      const result = getRankedUsers([], mockIdentities, "all-time")
      expect(result).toEqual([])
    })

    it("adds position and isCurrentUser properties to users", () => {
      const result = getRankedUsers(mockUsers, mockIdentities, "all-time", "1")

      expect(result[0].position).toBe(1)
      expect(result[1].position).toBe(2)
      expect(result[0].isCurrentUser).toBe(true)
      expect(result[1].isCurrentUser).toBe(false)
    })

    it("sorts users by streak and then points for all-time timeframe", () => {
      // Setup mocks to give user2 a higher streak
      ;(getHighestIdentityHistoricalStreak as any).mockImplementation((identities) => {
        if (identities[0]?.id.startsWith("1")) return 10
        if (identities[0]?.id.startsWith("2")) return 20
        return 0
      })

      const result = getRankedUsers(mockUsers, mockIdentities, "all-time")

      // User2 should be first despite lower points due to higher streak
      expect(result[0].id).toBe("2")
      expect(result[1].id).toBe("1")
    })

    it("sorts users by streak and then points for other timeframes", () => {
      // Setup mocks to give both users equal streaks, so they should sort by points
      ;(getHighestIdentityStreak as any).mockReturnValue(5)

      const result = getRankedUsers(mockUsers, mockIdentities, "7-days")

      // User2 should be first due to higher 7-day points (150 vs 100)
      expect(result[0].id).toBe("2")
      expect(result[1].id).toBe("1")
    })
  })

  describe("getCurrentUserRank", () => {
    const mockRankedUsers = [
      { id: "1", username: "user1", position: 1 },
      { id: "2", username: "user2", position: 2 },
      { id: "3", username: "user3", position: 3 },
    ]

    it("returns the current user from ranked users", () => {
      const result = getCurrentUserRank(mockRankedUsers, "2")
      expect(result).toEqual({ id: "2", username: "user2", position: 2 })
    })

    it("returns null if current user is not found", () => {
      const result = getCurrentUserRank(mockRankedUsers, "99")
      expect(result).toBeNull()
    })

    it("returns null if no ranked users are provided", () => {
      const result = getCurrentUserRank([], "1")
      expect(result).toBeNull()
    })

    it("returns null if no current user ID is provided", () => {
      const result = getCurrentUserRank(mockRankedUsers)
      expect(result).toBeNull()
    })
  })
})

