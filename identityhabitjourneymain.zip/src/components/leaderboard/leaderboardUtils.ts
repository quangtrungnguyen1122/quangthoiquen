import type { Identity } from "@/contexts/types"
import { getHighestIdentityStreak, getHighestIdentityHistoricalStreak } from "@/services/streakService"

// Get proper streak value based on active tab
export const getStreakForTimeframe = (user: any, timeframe: string, identities: Identity[]): number => {
  if (!user) return 0

  // Get all identities for this user by matching the identity.id that starts with user.id-
  // This was incorrect before - we need to check if the identity belongs to this user differently
  const userIdentities = identities.filter((identity) => {
    // Extract user ID from identity ID (format is usually userId-identityName)
    const parts = identity.id.split("-")
    return parts.length > 0 && parts[0] === user.id
  })

  console.log("User identities found:", userIdentities.length, "for user:", user.id)
  console.log(
    "Identity streaks:",
    userIdentities.map((identity) => ({
      id: identity.id,
      name: identity.name,
      streak: identity.streak,
      highestStreak: identity.highestStreak,
    })),
  )

  if (timeframe === "all-time") {
    // For all-time view, return the highest historical streak across all identities
    const highestStreak = getHighestIdentityHistoricalStreak(userIdentities)
    console.log("Highest historical streak calculated:", highestStreak)
    return highestStreak
  } else {
    // For current views (7-days and 30-days), return the highest current streak across all identities
    const currentStreak = getHighestIdentityStreak(userIdentities)
    console.log("Highest current streak calculated:", currentStreak)
    return currentStreak
  }
}

// Get proper score based on active tab
export const getScoreForTimeframe = (user: any, timeframe: string): number => {
  if (!user) return 0

  if (timeframe === "all-time") {
    return user.totalPoints || 0
  } else if (timeframe === "30-days") {
    return user.last30DaysPoints || 0
  } else {
    return user.last7DaysPoints || 0
  }
}

// Calculate ranks based on active tab and sort by streak first, then points
export const getRankedUsers = (
  leaderboardUsers: any[],
  identities: Identity[],
  activeTab: string,
  currentUserId?: string,
): any[] => {
  if (!leaderboardUsers || leaderboardUsers.length === 0) return []

  const sortedUsers = [...leaderboardUsers]

  // Sort primarily by streak, secondarily by points
  if (activeTab === "all-time") {
    sortedUsers.sort((a, b) => {
      // First compare by streak (highest historical streak first)
      const userAIdentities = identities.filter((identity) => identity.id.startsWith(a.id))
      const userBIdentities = identities.filter((identity) => identity.id.startsWith(b.id))

      const userAHighestStreak = getHighestIdentityHistoricalStreak(userAIdentities)
      const userBHighestStreak = getHighestIdentityHistoricalStreak(userBIdentities)

      const streakDiff = userBHighestStreak - userAHighestStreak
      if (streakDiff !== 0) return streakDiff

      // If streak is the same, compare by points
      return b.totalPoints - a.totalPoints
    })
  } else if (activeTab === "30-days" || activeTab === "7-days") {
    sortedUsers.sort((a, b) => {
      // For current views, use current streak
      const userAIdentities = identities.filter((identity) => identity.id.startsWith(a.id))
      const userBIdentities = identities.filter((identity) => identity.id.startsWith(b.id))

      const userACurrentStreak = getHighestIdentityStreak(userAIdentities)
      const userBCurrentStreak = getHighestIdentityStreak(userBIdentities)

      const streakDiff = userBCurrentStreak - userACurrentStreak
      if (streakDiff !== 0) return streakDiff

      // If streak is the same, compare by appropriate points
      if (activeTab === "30-days") {
        return b.last30DaysPoints - a.last30DaysPoints
      } else {
        return b.last7DaysPoints - a.last7DaysPoints
      }
    })
  }

  return sortedUsers.map((user, index) => ({
    ...user,
    position: index + 1,
    isCurrentUser: currentUserId && user.id === currentUserId,
  }))
}

// Get the current user's rank
export const getCurrentUserRank = (rankedUsers: any[], currentUserId?: string): any | null => {
  if (!currentUserId || !rankedUsers || !rankedUsers.length) return null

  return rankedUsers.find((user) => user.id === currentUserId) || null
}

