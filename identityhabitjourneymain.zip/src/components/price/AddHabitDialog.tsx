"use client"
import { Loader2, PlusCircle } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Habit } from "@/contexts/types"
import type { PriceDetailDialogState, PriceDetailHandlers } from "@/hooks/price/usePriceDetailPage"

interface AddHabitDialogProps {
  priceName: string
  availableHabits: Habit[]
  dialogState: PriceDetailDialogState
  handlers: PriceDetailHandlers
}

const AddHabitDialog = ({ priceName, availableHabits, dialogState, handlers }: AddHabitDialogProps) => {
  const {
    isAddHabitDialogOpen,
    isCreatingHabit,
    activeTab,
    newHabitName,
    newHabitDescription,
    newHabitDifficulty,
    newHabitIcon,
    selectedHabitId,
  } = dialogState

  const {
    setIsAddHabitDialogOpen,
    setActiveTab,
    setNewHabitName,
    setNewHabitDescription,
    setNewHabitDifficulty,
    setNewHabitIcon,
    setSelectedHabitId,
    handleSubmit,
  } = handlers

  return (
    <Dialog open={isAddHabitDialogOpen} onOpenChange={setIsAddHabitDialogOpen}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add Habit to {priceName}</DialogTitle>
          <DialogDescription>Create a new habit or link an existing one to this price.</DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="existing" disabled={availableHabits.length === 0}>
              Link Existing
            </TabsTrigger>
            <TabsTrigger value="new">Create New</TabsTrigger>
          </TabsList>

          <TabsContent value="existing" className="py-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="existing-habit">Select Habit</Label>
                <Select value={selectedHabitId} onValueChange={setSelectedHabitId}>
                  <SelectTrigger id="existing-habit">
                    <SelectValue placeholder="Select a habit" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableHabits.map((habit) => (
                      <SelectItem key={habit.id} value={habit.id}>
                        {habit.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="new" className="py-4 space-y-4">
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="habit-name">Habit Name</Label>
                <Input
                  id="habit-name"
                  value={newHabitName}
                  onChange={(e) => setNewHabitName(e.target.value)}
                  placeholder="Enter habit name"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="habit-description">Description</Label>
                <Textarea
                  id="habit-description"
                  value={newHabitDescription}
                  onChange={(e) => setNewHabitDescription(e.target.value)}
                  placeholder="Enter habit description"
                  rows={3}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="habit-difficulty">Difficulty</Label>
                <Select
                  value={newHabitDifficulty}
                  onValueChange={(val) => setNewHabitDifficulty(val as "easy" | "medium" | "hard")}
                >
                  <SelectTrigger id="habit-difficulty">
                    <SelectValue placeholder="Select difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="easy">Easy (5 points)</SelectItem>
                      <SelectItem value="medium">Medium (10 points)</SelectItem>
                      <SelectItem value="hard">Hard (15 points)</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="habit-icon">Icon URL (optional)</Label>
                <Input
                  id="habit-icon"
                  value={newHabitIcon}
                  onChange={(e) => setNewHabitIcon(e.target.value)}
                  placeholder="Enter icon URL"
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => setIsAddHabitDialogOpen(false)}
            disabled={isCreatingHabit}
          >
            Cancel
          </Button>
          <Button
            type="button"
            onClick={handleSubmit}
            disabled={
              isCreatingHabit ||
              (activeTab === "existing" && !selectedHabitId) ||
              (activeTab === "new" && (!newHabitName || !newHabitDescription))
            }
          >
            {isCreatingHabit ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {activeTab === "existing" ? "Linking..." : "Creating..."}
              </>
            ) : (
              <>
                <PlusCircle className="mr-2 h-4 w-4" />
                {activeTab === "existing" ? "Link Habit" : "Create Habit"}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export default AddHabitDialog

