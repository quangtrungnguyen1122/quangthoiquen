import PriceHeader from "./PriceHeader"
import RelatedHabits from "./RelatedHabits"
import RelatedIdentities from "./RelatedIdentities"
import AddHabitDialog from "./AddHabitDialog"
import type { Price } from "@/contexts/types"
import type { PriceDetailDialogState, PriceDetailHandlers } from "@/hooks/price/usePriceDetailPage"

interface PriceContentProps {
  price: Price
  relatedHabits: any[]
  relatedIdentities: any[]
  availableHabits: any[]
  dialogState: PriceDetailDialogState
  handlers: PriceDetailHandlers
}

const PriceContent = ({
  price,
  relatedHabits,
  relatedIdentities,
  availableHabits,
  dialogState,
  handlers,
}: PriceContentProps) => {
  return (
    <>
      <PriceHeader price={price} />

      <RelatedHabits
        relatedHabits={relatedHabits}
        onCompleteHabit={handlers.completeHabit}
        onAddHabit={handlers.openAddHabitDialog}
      />

      <RelatedIdentities relatedIdentities={relatedIdentities} />

      <AddHabitDialog
        priceName={price.name}
        availableHabits={availableHabits}
        dialogState={dialogState}
        handlers={handlers}
      />
    </>
  )
}

export default PriceContent

