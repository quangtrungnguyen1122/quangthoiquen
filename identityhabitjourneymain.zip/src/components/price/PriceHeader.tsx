"use client"
import { Link } from "react-router-dom"
import { Award, ArrowLeft } from "lucide-react"
import { motion } from "framer-motion"
import GlassCard from "@/components/ui-custom/GlassCard"
import ProgressRing from "@/components/dashboard/ProgressRing"
import type { Price } from "@/contexts/types"

interface PriceHeaderProps {
  price: Price
}

const PriceHeader = ({ price }: PriceHeaderProps) => {
  return (
    <div className="my-8">
      <Link
        to="/"
        className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors duration-200 mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Dashboard</span>
      </Link>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
        <div className="flex items-start gap-6">
          <div className="w-16 h-16 rounded-full border-2 border-border bg-muted/50 flex items-center justify-center flex-shrink-0">
            {price.icon ? (
              <img src={price.icon} alt={price.name} className="w-full h-full rounded-full object-cover" />
            ) : (
              <Award className="w-8 h-8 text-primary" />
            )}
          </div>

          <div>
            <h1 className="text-3xl font-bold tracking-tight">{price.name}</h1>
            <p className="text-muted-foreground mt-2 max-w-3xl">{price.description}</p>
          </div>
        </div>
      </motion.div>

      <div className="mt-6">
        <GlassCard className="flex items-center gap-5">
          <ProgressRing progress={price.completionPercentage || 0} size={80} strokeWidth={6} />
          <div>
            <div className="text-sm text-muted-foreground">Completion Progress</div>
            <div className="text-2xl font-semibold">{price.completionPercentage || 0}%</div>
          </div>
        </GlassCard>
      </div>
    </div>
  )
}

export default PriceHeader

