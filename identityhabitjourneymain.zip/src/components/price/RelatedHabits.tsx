"use client"
import { Plus, Target, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import GlassCard from "@/components/ui-custom/GlassCard"
import { cn } from "@/lib/utils"
import type { Habit } from "@/contexts/types"

interface RelatedHabitsProps {
  relatedHabits: Habit[]
  onCompleteHabit: (habitId: string) => void
  onAddHabit: () => void
}

const RelatedHabits = ({ relatedHabits, onCompleteHabit, onAddHabit }: RelatedHabitsProps) => {
  return (
    <div className="mb-10">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Target className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-semibold">Related Habits</h2>
        </div>

        <Button onClick={onAddHabit} variant="outline" size="sm" className="gap-1">
          <Plus className="w-4 h-4" />
          Add Habit
        </Button>
      </div>

      <div className="space-y-4">
        {relatedHabits.length > 0 ? (
          relatedHabits.map((habit) => (
            <GlassCard key={habit.id} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => !habit.completed && onCompleteHabit(habit.id)}
                  disabled={habit.completed}
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center",
                    habit.completed ? "bg-primary/20" : "bg-muted cursor-pointer hover:bg-primary/10",
                  )}
                >
                  {habit.completed ? (
                    <Check className="w-5 h-5 text-primary" />
                  ) : (
                    <Target className="w-5 h-5 text-muted-foreground" />
                  )}
                </button>
                <div>
                  <div className="font-medium">{habit.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {habit.difficulty} · {habit.points} points
                  </div>
                </div>
              </div>
            </GlassCard>
          ))
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No habits linked to this price yet.</p>
            <Button onClick={onAddHabit} variant="outline" size="sm" className="mt-4 gap-1">
              <Plus className="w-4 h-4" />
              Add First Habit
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

export default RelatedHabits

