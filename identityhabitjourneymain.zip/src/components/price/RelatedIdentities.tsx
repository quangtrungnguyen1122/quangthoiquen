import { Award, Target } from "lucide-react"
import { Link } from "react-router-dom"
import GlassCard from "@/components/ui-custom/GlassCard"
import type { Identity } from "@/contexts/types"

interface RelatedIdentitiesProps {
  relatedIdentities: Identity[]
}

const RelatedIdentities = ({ relatedIdentities }: RelatedIdentitiesProps) => {
  if (relatedIdentities.length === 0) {
    return null
  }

  return (
    <div className="mb-10">
      <div className="flex items-center gap-2 mb-6">
        <Award className="w-5 h-5 text-primary" />
        <h2 className="text-xl font-semibold">Related Identities</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {relatedIdentities.map((identity) => (
          <GlassCard key={identity.id} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center">
                {identity.avatar ? (
                  <img src={identity.avatar} alt={identity.name} className="w-full h-full rounded-full object-cover" />
                ) : (
                  <Target className="w-5 h-5 text-muted-foreground" />
                )}
              </div>
              <div>
                <div className="font-medium">{identity.name}</div>
                <div className="text-xs text-muted-foreground">Progress: {identity.progress}%</div>
              </div>
            </div>

            <Link to={`/identity/${identity.id}`} className="text-sm text-primary hover:underline">
              View
            </Link>
          </GlassCard>
        ))}
      </div>
    </div>
  )
}

export default RelatedIdentities

