"use client"

import type React from "react"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"

interface GlassCardProps {
  children: React.ReactNode
  className?: string
  hoverEffect?: boolean
  delay?: number
}

const GlassCard = ({ children, className, hoverEffect = false, delay = 0 }: GlassCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.4,
        ease: [0.22, 1, 0.36, 1],
        delay: delay * 0.1,
      }}
      whileHover={hoverEffect ? { y: -5, transition: { duration: 0.2 } } : undefined}
      className={cn("glass-card rounded-2xl p-6", "transition-all duration-300 ease-out", className)}
    >
      {children}
    </motion.div>
  )
}

export default GlassCard

