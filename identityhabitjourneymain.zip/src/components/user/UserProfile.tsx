"use client"
import { useNavigate } from "react-router-dom"
import { useHabitContext } from "@/contexts/HabitContext"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { LogOut, User } from "lucide-react"
import { supabase } from "@/integrations/supabase/client"
import { useToast } from "@/hooks/use-toast"

const UserProfile = () => {
  const { currentUser } = useHabitContext()
  const navigate = useNavigate()
  const { toast } = useToast()

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut()
      toast({
        title: "Đăng xuất thành công",
        description: "Bạn đã đăng xuất khỏi tài khoản.",
      })
      navigate("/auth")
    } catch (error) {
      console.error("Error logging out:", error)
      toast({
        variant: "destructive",
        title: "Đăng xuất thất bại",
        description: "Đã xảy ra lỗi khi đăng xuất. Vui lòng thử lại.",
      })
    }
  }

  if (!currentUser) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Vui lòng đăng nhập để xem thông tin cá nhân.</p>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">User Profile</h1>

      <Card className="p-6">
        <div className="flex items-start gap-6">
          <Avatar className="w-20 h-20">
            <AvatarImage src={currentUser.avatar} />
            <AvatarFallback>
              <User className="w-8 h-8 text-muted-foreground" />
            </AvatarFallback>
          </Avatar>

          <div className="flex-1">
            <h2 className="text-xl font-semibold mb-2">{currentUser.username}</h2>

            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Member since</p>
                <p>{currentUser.joinedDate.toLocaleDateString()}</p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Total Points</p>
                  <p className="text-xl font-semibold">{currentUser.totalPoints}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Last 30 Days</p>
                  <p className="text-xl font-semibold">{currentUser.last30DaysPoints}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Last 7 Days</p>
                  <p className="text-xl font-semibold">{currentUser.last7DaysPoints}</p>
                </div>
              </div>

              {currentUser.position > 0 && (
                <div>
                  <p className="text-sm text-muted-foreground">Leaderboard Position</p>
                  <p className="text-xl font-semibold">#{currentUser.position}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-border">
          <Button variant="destructive" onClick={handleLogout} className="flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            Đăng xuất
          </Button>
        </div>
      </Card>
    </div>
  )
}

export default UserProfile

