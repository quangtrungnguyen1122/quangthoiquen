"use client"

import type React from "react"
import { createContext, useContext, useEffect } from "react"
import type { HabitContextType } from "./types"
import { useHabitContextValue } from "./habit-provider/useHabitContextValue"

// Create the context with a default value
export const HabitContext = createContext<HabitContextType>({
  habits: [],
  prices: [],
  identities: [],
  currentUser: null,
  leaderboardUsers: [],
  isLoading: true,
  refreshData: async () => {},
  completeHabit: async () => {},
  getHabitsByPriceId: () => [],
  getPricesByIdentityId: () => [],
  getPricesByHabitId: () => [],
  getIdentityById: () => undefined,
  getIdentitiesByPriceId: () => [],
  addHabit: async () => null,
  updateHabit: async () => {},
  deleteHabit: async () => false, // Added deleteHabit method
  addPrice: async () => null,
  updatePrice: async () => false,
  deletePrice: async () => false,
  addIdentity: async () => null,
  updateIdentity: async () => false,
  deleteIdentity: async () => false,
  linkPriceToIdentity: async () => false,
  linkHabitToPrice: async () => false,
  linkPriceToHabit: async () => false,
  unlinkHabitFromPrice: async () => false,
  removeHabitFromPrice: async () => false,
  removePriceFromIdentity: async () => false,
})

// Add convenient hooks for accessing the context
export const useHabitContext = () => {
  const context = useContext(HabitContext)
  if (context === undefined) {
    throw new Error("useHabitContext must be used within a HabitProvider")
  }
  return context
}

// Alias for useHabitContext for more concise naming
export const useHabit = useHabitContext

/**
 * Provider component that makes habit context available to the app
 */
export const HabitProvider = ({ children }: { children: React.ReactNode }) => {
  // Get the context value from our custom hook
  const contextValue = useHabitContextValue()

  // Fetch data on mount
  useEffect(() => {
    contextValue.refreshData()
  }, [])

  return <HabitContext.Provider value={contextValue}>{children}</HabitContext.Provider>
}

