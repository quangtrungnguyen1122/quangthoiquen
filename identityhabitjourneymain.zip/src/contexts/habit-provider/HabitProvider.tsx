"use client"

import type React from "react"
import { useEffect } from "react"
import { HabitContext } from "../HabitContext"
import { useHabitContextValue } from "./useHabitContextValue"

/**
 * Provider component that makes habit context available to the app
 */
export const HabitProvider = ({ children }: { children: React.ReactNode }) => {
  // Get the context value from our custom hook
  const contextValue = useHabitContextValue()

  // Fetch data on mount
  useEffect(() => {
    contextValue.refreshData()
  }, [])

  return <HabitContext.Provider value={contextValue}>{children}</HabitContext.Provider>
}

