import { useToast } from "@/hooks/use-toast"
import {
  fetchUserData,
  fetchHabits,
  fetchPrices,
  fetchIdentities,
  fetchLeaderboard,
  fetchHabitPrices,
  fetchIdentityPrices,
  transformHabitsData,
  transformPricesData,
  transformIdentitiesData,
  transformUserData,
  transformLeaderboardData,
} from "@/services"

export const useDataFetching = () => {
  const { toast: showToast } = useToast()

  // Fetch all data entities separately for modularity
  const fetchAllData = async (userId: string) => {
    try {
      // Fetch habits data first to check if we need to reset
      const habitsData = await fetchHabits(userId)

      // Fetch all other data
      const userData = await fetchUserData(userId)
      const pricesData = await fetchPrices(userId)
      const identitiesData = await fetchIdentities(userId)
      const leaderboardData = await fetchLeaderboard()

      // Fetch relationship data with no caching
      const habitPricesData = await fetchHabitPrices()
      const identityPricesData = await fetchIdentityPrices()

      console.log("Fetched fresh relationship data:", {
        habitPrices: habitPricesData?.length || 0,
        identityPrices: identityPricesData?.length || 0,
      })

      return {
        habitsData,
        userData,
        pricesData,
        identitiesData,
        leaderboardData,
        habitPricesData,
        identityPricesData,
      }
    } catch (error) {
      console.error("Error fetching data:", error)
      showToast({
        title: "Error",
        description: "Failed to fetch data",
        variant: "destructive",
      })
      throw error
    }
  }

  // Transform all fetched data into the format needed by the app
  const transformAllData = (fetchedData: any) => {
    const { habitsData, userData, pricesData, identitiesData, leaderboardData } = fetchedData

    const transformedHabits = transformHabitsData(habitsData)
    const transformedPrices = transformPricesData(pricesData)
    const transformedIdentities = transformIdentitiesData(identitiesData)
    const transformedUser = userData ? transformUserData(userData) : null
    const transformedLeaderboard = transformLeaderboardData(leaderboardData)

    return {
      transformedHabits,
      transformedPrices,
      transformedIdentities,
      transformedUser,
      transformedLeaderboard,
    }
  }

  return {
    fetchAllData,
    transformAllData,
  }
}

