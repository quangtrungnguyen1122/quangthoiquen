import { calculateCompletionRate } from "@/utils/habitUtils"
import type { Habit, Price, Identity } from "@/contexts/types"

export const useDataProcessor = () => {
  // Process relationships between habits, prices and identities
  const processRelationships = (
    transformedHabits: Habit[],
    transformedPrices: Price[],
    transformedIdentities: Identity[],
    habitPricesData: any[] | null,
    identityPricesData: any[] | null,
  ): void => {
    // Clear all relationships before rebuilding them
    transformedHabits.forEach((h) => {
      h.priceIds = []
    })
    transformedPrices.forEach((p) => {
      p.habitIds = []
      p.identityIds = []
    })
    transformedIdentities.forEach((i) => {
      i.priceIds = []
    })

    // Rebuild all relationships from fresh data
    if (habitPricesData) {
      habitPricesData.forEach((hp: any) => {
        const habit = transformedHabits.find((h) => h.id === hp.habit_id)
        const price = transformedPrices.find((p) => p.id === hp.price_id)

        if (habit && !habit.priceIds.includes(hp.price_id)) {
          habit.priceIds.push(hp.price_id)
        }

        if (price && !price.habitIds.includes(hp.habit_id)) {
          price.habitIds.push(hp.habit_id)
        }
      })
    }

    if (identityPricesData) {
      identityPricesData.forEach((ip: any) => {
        const identity = transformedIdentities.find((i) => i.id === ip.identity_id)
        const price = transformedPrices.find((p) => p.id === ip.price_id)

        if (identity && !identity.priceIds.includes(ip.price_id)) {
          identity.priceIds.push(ip.price_id)
        }

        if (price && !price.identityIds.includes(ip.identity_id)) {
          price.identityIds.push(ip.identity_id)
        }
      })
    }
  }

  // Update progress for each identity based on habits completion
  const updateIdentityProgress = (
    transformedIdentities: Identity[],
    transformedPrices: Price[],
    transformedHabits: Habit[],
  ): void => {
    transformedIdentities.forEach((identity) => {
      const identityPrices = transformedPrices.filter((p) => identity.priceIds.includes(p.id))
      let totalHabits = 0
      let completedHabits = 0

      identityPrices.forEach((price) => {
        const priceHabits = transformedHabits.filter((h) => price.habitIds.includes(h.id))
        totalHabits += priceHabits.length
        completedHabits += priceHabits.filter((h) => h.completed).length
      })

      // Calculate completion rate as a percentage
      identity.progress = calculateCompletionRate(completedHabits, totalHabits)
    })
  }

  return {
    processRelationships,
    updateIdentityProgress,
  }
}

