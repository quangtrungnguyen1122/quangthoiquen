import { supabase } from "@/integrations/supabase/client"
import { fetchIdentities } from "@/services"
import { transformIdentitiesData } from "@/services"
import { useToast } from "@/hooks/use-toast"
import { formatDateInVietnam, getTodayInVietnam } from "./useTimezoneUtils"

export const useHabitReset = () => {
  const { toast: showToast } = useToast()

  // Helper function to check if habits need to be reset
  const shouldResetHabits = (habitsData: any[]): boolean => {
    // If no habits, no need to reset
    if (!habitsData || habitsData.length === 0) return false

    // Check if there are any completed habits
    const hasCompletedHabits = habitsData.some((habit) => habit.completed)
    if (!hasCompletedHabits) return false

    // Get today's date in Vietnam timezone
    const todayInVietnam = getTodayInVietnam()

    // If there's at least one completed habit, check if we're in a new day
    for (const habit of habitsData) {
      if (habit.completed) {
        // If the last completion date is not today, we should reset
        const lastCompletionDate = habit.created_at ? formatDateInVietnam(new Date(habit.created_at)) : null

        if (!lastCompletionDate || lastCompletionDate !== todayInVietnam) {
          return true
        }
      }
    }

    return false
  }

  // Helper function to reset completed habits and maintain identity streaks
  const resetCompletedHabits = async (userId: string): Promise<boolean> => {
    try {
      console.log("Resetting completed habits for new day in Vietnam timezone")

      // First, fetch identities to check their streaks before reset
      const identitiesData = await fetchIdentities(userId)
      const transformed = transformIdentitiesData(identitiesData)

      // Reset all completed habits to false for the new day
      const { error } = await supabase
        .from("habits")
        .update({ completed: false })
        .eq("user_id", userId)
        .eq("completed", true)

      if (error) {
        console.error("Error resetting habits:", error)
        throw error
      }

      showToast({
        title: "Habits Reset",
        description: "Your habits have been reset for a new day.",
      })

      return true
    } catch (error) {
      console.error("Failed to reset habits:", error)
      return false
    }
  }

  return {
    shouldResetHabits,
    resetCompletedHabits,
  }
}

