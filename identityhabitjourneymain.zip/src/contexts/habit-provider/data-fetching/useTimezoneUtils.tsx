import { formatInTimeZone } from "date-fns-tz"

// Vietnam timezone
export const VIETNAM_TIMEZONE = "Asia/Ho_Chi_Minh" // UTC+7

// Get current date in Vietnam timezone in YYYY-MM-DD format
export const getTodayInVietnam = (): string => {
  return formatInTimeZone(new Date(), VIETNAM_TIMEZONE, "yyyy-MM-dd")
}

// Format a date in Vietnam timezone
export const formatDateInVietnam = (date: Date | string): string => {
  const dateObj = typeof date === "string" ? new Date(date) : date
  return formatInTimeZone(dateObj, VIETNAM_TIMEZONE, "yyyy-MM-dd")
}

