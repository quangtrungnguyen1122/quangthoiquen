import type { HabitContextType } from "../types"
import { useHabitState } from "./useHabitState"
import { useHabitOperations } from "./useHabitOperations"
import { useHabitDataFetching } from "./useHabitDataFetching"
import { useRelationOperations } from "./useRelationOperations"
import { usePriceOperations } from "./usePriceOperations"
import { useIdentityOperations } from "./useIdentityOperations"

/**
 * Custom hook that creates and returns the context value for HabitContext
 */
export const useHabitContextValue = (): HabitContextType => {
  // Get state from useHabitState
  const {
    habits,
    prices,
    identities,
    currentUser,
    leaderboardUsers,
    isLoading,
    setHabits,
    setPrices,
    setIdentities,
    setCurrentUser,
    setLeaderboardUsers,
    setIsLoading,
  } = useHabitState()

  // Get data fetching operations
  const { refreshData } = useHabitDataFetching(
    setHabits,
    setPrices,
    setIdentities,
    setCurrentUser,
    setLeaderboardUsers,
    setIsLoading,
  )

  // Get habit operations
  const { completeHabit, addHabit, updateHabit, deleteHabit } = useHabitOperations(
    habits,
    setHabits,
    currentUser,
    setCurrentUser,
  )

  // Get relation operations
  const {
    getHabitsByPriceId,
    getPricesByIdentityId,
    getPricesByHabitId,
    getIdentityById,
    getIdentitiesByPriceId,
    linkPriceToIdentity,
    linkHabitToPrice,
    linkPriceToHabit,
    unlinkHabitFromPrice,
    removeHabitFromPrice,
    removePriceFromIdentity,
  } = useRelationOperations(habits, prices, identities, setIdentities, setPrices, setHabits, refreshData)

  // Get price operations
  const { addPrice, updatePrice, deletePrice } = usePriceOperations(prices, setPrices)

  // Get identity operations
  const { addIdentity, updateIdentity, deleteIdentity } = useIdentityOperations(identities, setIdentities)

  // Create context value with all required properties
  return {
    habits,
    prices,
    identities,
    currentUser,
    leaderboardUsers,
    isLoading,
    refreshData,
    completeHabit,
    addHabit,
    updateHabit,
    deleteHabit,
    getHabitsByPriceId,
    getPricesByIdentityId,
    getPricesByHabitId,
    getIdentityById,
    getIdentitiesByPriceId,
    linkPriceToIdentity,
    linkHabitToPrice,
    linkPriceToHabit,
    unlinkHabitFromPrice,
    removeHabitFromPrice,
    removePriceFromIdentity,
    addPrice,
    updatePrice,
    deletePrice,
    addIdentity,
    updateIdentity,
    deleteIdentity,
  }
}

