import { useNavigate } from "react-router-dom"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/integrations/supabase/client"
import { useHabitReset } from "./data-fetching/useHabitReset"
import { useDataFetching } from "./data-fetching/useDataFetching"
import { useDataProcessor } from "./data-fetching/useDataProcessor"

export const useHabitDataFetching = (
  setHabits: any,
  setPrices: any,
  setIdentities: any,
  setCurrentUser: any,
  setLeaderboardUsers: any,
  setIsLoading: any,
) => {
  const { toast: showToast } = useToast()
  const { shouldResetHabits, resetCompletedHabits } = useHabitReset()
  const { fetchAllData, transformAllData } = useDataFetching()
  const { processRelationships, updateIdentityProgress } = useDataProcessor()

  const navigate = useNavigate()

  // Update the refreshData function to handle authentication better
  const refreshData = async () => {
    console.log("Starting complete data refresh...")
    try {
      setIsLoading(true)

      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData.session) {
        // If no session and we have navigate function, redirect to auth
        if (navigate) {
          navigate("/auth")
        }
        setIsLoading(false)
        return
      }

      try {
        // Get the user ID from the session
        const userId = sessionData.session.user.id

        if (!userId) {
          console.warn("No user ID available, skipping data fetch")
          setIsLoading(false)
          return
        }

        // Fetch all data with cache busting to ensure fresh data
        const fetchedData = await fetchAllData(userId)

        // Check if we need to reset habits for a new day based on Vietnam timezone
        if (shouldResetHabits(fetchedData.habitsData)) {
          await resetCompletedHabits(userId)
          // Re-fetch habits after reset
          const refreshedHabits = await fetchAllData(userId)
          fetchedData.habitsData.length = 0 // Clear the array
          fetchedData.habitsData.push(...refreshedHabits.habitsData) // Add refreshed habits
        }

        // Transform all data
        const { transformedHabits, transformedPrices, transformedIdentities, transformedUser, transformedLeaderboard } =
          transformAllData(fetchedData)

        // Process relationships between entities
        processRelationships(
          transformedHabits,
          transformedPrices,
          transformedIdentities,
          fetchedData.habitPricesData,
          fetchedData.identityPricesData,
        )

        // Update progress for each identity
        updateIdentityProgress(transformedIdentities, transformedPrices, transformedHabits)

        // Set state with completely fresh data
        setHabits(transformedHabits)
        setPrices(transformedPrices)
        setIdentities(transformedIdentities)

        if (transformedUser) {
          setCurrentUser(transformedUser)
        }

        setLeaderboardUsers(transformedLeaderboard)
        console.log("Data refresh complete with completely rebuilt relationships")
      } catch (error) {
        console.error("Error fetching data:", error)
        showToast({
          title: "Lỗi",
          description: "Không thể tải dữ liệu",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error refreshing data:", error)
      showToast({
        title: "Lỗi",
        description: "Không thể làm mới dữ liệu",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return { refreshData }
}

