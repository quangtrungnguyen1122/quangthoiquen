import { toast } from "sonner"
import { useNavigate } from "react-router-dom"
import { supabase } from "@/integrations/supabase/client"
import type { Habit } from "../types"
import { completeHabitApi, addHabitApi, updateHabitApi, deleteHabitApi } from "@/services"

export const useHabitOperations = (habits: Habit[], setHabits: any, currentUser: any, setCurrentUser: any) => {
  const navigate = useNavigate()

  const completeHabit = async (habitId: string) => {
    try {
      setHabits((prevHabits: Habit[]) =>
        prevHabits.map((habit) => (habit.id === habitId ? { ...habit, completed: true } : habit)),
      )

      const habit = habits.find((h) => h.id === habitId)
      if (!habit || !currentUser) {
        return
      }

      const newPoints = (currentUser.totalPoints || 0) + (habit.points || 0)

      await completeHabitApi(habitId, currentUser.id, newPoints)

      setCurrentUser((prev: any) => {
        if (!prev) return prev
        return {
          ...prev,
          totalPoints: newPoints,
        }
      })

      toast.success("Habit completed!", {
        description: `Great job! You've earned ${habit?.points || 0} points.`,
      })
    } catch (error) {
      console.error("Error in completeHabit:", error)

      // Revert the optimistic update
      setHabits((prevHabits: Habit[]) =>
        prevHabits.map((habit) => (habit.id === habitId ? { ...habit, completed: false } : habit)),
      )

      toast.error("Failed to complete habit")
    }
  }

  const addHabit = async (habit: Omit<Habit, "id">): Promise<string | null> => {
    try {
      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData.session) {
        navigate("/auth")
        return null
      }

      const userId = sessionData.session.user.id

      const newHabitData = await addHabitApi(habit, userId)

      const newHabit: Habit = {
        id: newHabitData.id,
        name: newHabitData.name,
        description: newHabitData.description,
        difficulty: newHabitData.difficulty as "easy" | "medium" | "hard",
        completed: newHabitData.completed || false,
        points: newHabitData.points || 0,
        priceIds: [],
        completionFrequency: newHabitData.completion_frequency as "daily" | "weekly" | "specific-days",
        icon: newHabitData.icon,
      }

      setHabits((prev: Habit[]) => [...prev, newHabit])

      toast.success("Habit added successfully!")
      return newHabit.id
    } catch (error) {
      console.error("Error in addHabit:", error)
      toast.error("Failed to add habit")
      return null
    }
  }

  const updateHabit = async (id: string, habitUpdate: Partial<Omit<Habit, "id">>): Promise<void> => {
    try {
      await updateHabitApi(id, habitUpdate)

      setHabits((prev: Habit[]) => prev.map((habit) => (habit.id === id ? { ...habit, ...habitUpdate } : habit)))

      toast.success("Habit updated successfully!")
    } catch (error) {
      console.error("Error in updateHabit:", error)
      toast.error("Failed to update habit")
    }
  }

  const deleteHabit = async (habitId: string): Promise<boolean> => {
    try {
      await deleteHabitApi(habitId)

      // Update the local state
      setHabits((prev: Habit[]) => prev.filter((habit) => habit.id !== habitId))

      toast.success("Habit deleted successfully!")
      return true
    } catch (error) {
      console.error("Error deleting habit:", error)
      toast.error("Failed to delete habit")
      return false
    }
  }

  return {
    completeHabit,
    addHabit,
    updateHabit,
    deleteHabit,
  }
}

