"use client"

import { useState } from "react"
import type { Habit, Price, Identity, User } from "../types"

export const useHabitState = () => {
  const [habits, setHabits] = useState<Habit[]>([])
  const [prices, setPrices] = useState<Price[]>([])
  const [identities, setIdentities] = useState<Identity[]>([])
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [leaderboardUsers, setLeaderboardUsers] = useState<User[]>([])
  const [isLoading, setIsLoading] = useState(true)

  return {
    // State
    habits,
    prices,
    identities,
    currentUser,
    leaderboardUsers,
    isLoading,

    // State setters
    setHabits,
    setPrices,
    setIdentities,
    setCurrentUser,
    setLeaderboardUsers,
    setIsLoading,
  }
}

