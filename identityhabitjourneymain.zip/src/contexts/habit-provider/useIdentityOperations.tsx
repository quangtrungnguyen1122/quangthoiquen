import { toast } from "sonner"
import { useNavigate } from "react-router-dom"
import { supabase } from "@/integrations/supabase/client"
import type { Identity } from "../types"
import { addIdentityApi, updateIdentityApi, deleteIdentityApi } from "@/services"

export const useIdentityOperations = (identities: Identity[], setIdentities: any) => {
  const navigate = useNavigate()

  const addIdentity = async (identity: Omit<Identity, "id">): Promise<string | null> => {
    try {
      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData.session) {
        navigate("/auth")
        return null
      }

      const userId = sessionData.session.user.id

      const newIdentityData = await addIdentityApi(identity, userId)

      const newIdentity: Identity = {
        id: newIdentityData.id,
        name: newIdentityData.name,
        description: newIdentityData.description,
        priceIds: [],
        streak: newIdentityData.streak || 0,
        highestStreak: newIdentityData.highest_streak || 0,
        progress: newIdentityData.progress || 0,
        avatar: newIdentityData.avatar,
      }

      setIdentities((prev: Identity[]) => [...prev, newIdentity])

      toast.success("Identity added successfully!")
      return newIdentity.id
    } catch (error) {
      console.error("Error in addIdentity:", error)
      toast.error("Failed to add identity")
      return null
    }
  }

  const updateIdentity = async (id: string, identityUpdate: Partial<Omit<Identity, "id">>): Promise<boolean> => {
    try {
      await updateIdentityApi(id, identityUpdate)

      setIdentities((prev: Identity[]) =>
        prev.map((identity) => (identity.id === id ? { ...identity, ...identityUpdate } : identity)),
      )

      toast.success("Identity updated successfully!")
      return true
    } catch (error) {
      console.error("Error in updateIdentity:", error)
      toast.error("Failed to update identity")
      return false
    }
  }

  const deleteIdentity = async (id: string): Promise<boolean> => {
    try {
      await deleteIdentityApi(id)

      setIdentities((prev: Identity[]) => prev.filter((identity) => identity.id !== id))

      toast.success("Identity deleted successfully!")
      return true
    } catch (error) {
      console.error("Error in deleteIdentity:", error)
      toast.error("Failed to delete identity")
      return false
    }
  }

  return {
    addIdentity,
    updateIdentity,
    deleteIdentity,
  }
}

