import type React from "react"

import { toast } from "sonner"
import type { Habit, Price, Identity } from "../types"
import { linkPriceToIdentityApi, linkHabitToPriceApi } from "@/services"

export const useLinkOperations = (
  setIdentities: React.Dispatch<React.SetStateAction<Identity[]>>,
  setPrices: React.Dispatch<React.SetStateAction<Price[]>>,
  setHabits: React.Dispatch<React.SetStateAction<Habit[]>>,
) => {
  // Linking operations
  const linkPriceToIdentity = async (identityId: string, priceId: string): Promise<boolean> => {
    try {
      await linkPriceToIdentityApi(identityId, priceId)

      setIdentities((prev: Identity[]) =>
        prev.map((i) => (i.id === identityId ? { ...i, priceIds: [...i.priceIds, priceId] } : i)),
      )

      setPrices((prev: Price[]) =>
        prev.map((p) => (p.id === priceId ? { ...p, identityIds: [...p.identityIds, identityId] } : p)),
      )

      toast.success("Price linked to identity successfully!")
      return true
    } catch (error) {
      console.error("Error in linkPriceToIdentity:", error)
      toast.error("Failed to link price to identity")
      return false
    }
  }

  const linkHabitToPrice = async (priceId: string, habitId: string): Promise<boolean> => {
    try {
      await linkHabitToPriceApi(priceId, habitId)

      setPrices((prev: Price[]) =>
        prev.map((p) => (p.id === priceId ? { ...p, habitIds: [...p.habitIds, habitId] } : p)),
      )

      setHabits((prev: Habit[]) =>
        prev.map((h) => (h.id === habitId ? { ...h, priceIds: [...h.priceIds, priceId] } : h)),
      )

      toast.success("Habit linked to price successfully!")
      return true
    } catch (error) {
      console.error("Error in linkHabitToPrice:", error)
      toast.error("Failed to link habit to price")
      return false
    }
  }

  return {
    linkPriceToIdentity,
    linkHabitToPrice,
  }
}

