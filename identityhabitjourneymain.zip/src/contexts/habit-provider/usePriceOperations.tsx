import { toast } from "sonner"
import { useNavigate } from "react-router-dom"
import { supabase } from "@/integrations/supabase/client"
import type { Price } from "../types"
import { addPriceApi, updatePriceApi, deletePriceApi } from "@/services"

export const usePriceOperations = (prices: Price[], setPrices: any) => {
  const navigate = useNavigate()

  const addPrice = async (price: Omit<Price, "id">): Promise<string | null> => {
    try {
      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData.session) {
        navigate("/auth")
        return null
      }

      const userId = sessionData.session.user.id

      const newPriceData = await addPriceApi(price, userId)

      const newPrice: Price = {
        id: newPriceData.id,
        name: newPriceData.name,
        description: newPriceData.description,
        habitIds: [],
        identityIds: [],
        completionPercentage: newPriceData.completion_percentage || 0,
        icon: newPriceData.icon,
      }

      setPrices((prev: Price[]) => [...prev, newPrice])

      toast.success("Price added successfully!")
      return newPrice.id
    } catch (error) {
      console.error("Error in addPrice:", error)
      toast.error("Failed to add price")
      return null
    }
  }

  const updatePrice = async (id: string, priceUpdate: Partial<Omit<Price, "id">>): Promise<boolean> => {
    try {
      await updatePriceApi(id, priceUpdate)

      setPrices((prev: Price[]) => prev.map((price) => (price.id === id ? { ...price, ...priceUpdate } : price)))

      toast.success("Price updated successfully!")
      return true
    } catch (error) {
      console.error("Error in updatePrice:", error)
      toast.error("Failed to update price")
      return false
    }
  }

  const deletePrice = async (id: string): Promise<boolean> => {
    try {
      await deletePriceApi(id)

      setPrices((prev: Price[]) => prev.filter((price) => price.id !== id))

      toast.success("Price deleted successfully!")
      return true
    } catch (error) {
      console.error("Error in deletePrice:", error)
      toast.error("Failed to delete price")
      return false
    }
  }

  return {
    addPrice,
    updatePrice,
    deletePrice,
  }
}

