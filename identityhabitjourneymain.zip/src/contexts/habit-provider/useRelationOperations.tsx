import type React from "react"

import type { Habit, Price, Identity } from "../types"
import { useRelationQueries } from "./useRelationQueries"
import { useLinkOperations } from "./useLinkOperations"
import { useUnlinkOperations } from "./useUnlinkOperations"

export const useRelationOperations = (
  habits: Habit[],
  prices: Price[],
  identities: Identity[],
  setIdentities: React.Dispatch<React.SetStateAction<Identity[]>>,
  setPrices: React.Dispatch<React.SetStateAction<Price[]>>,
  setHabits: React.Dispatch<React.SetStateAction<Habit[]>>,
  refreshData?: () => Promise<void>,
) => {
  // Get query functions
  const { getHabitsByPriceId, getPricesByIdentityId, getPricesByHabitId, getIdentityById, getIdentitiesByPriceId } =
    useRelationQueries(habits, prices, identities)

  // Get linking operations
  const { linkPriceToIdentity, linkHabitToPrice } = useLinkOperations(setIdentities, setPrices, setHabits)

  // Get unlinking/removing operations
  const { removeHabitFromPrice, removePriceFromIdentity } = useUnlinkOperations(setPrices, setHabits, refreshData)

  // Maintain API compatibility with the old names
  const unlinkHabitFromPrice = removeHabitFromPrice
  const linkPriceToHabit = linkHabitToPrice

  return {
    // Query functions
    getHabitsByPriceId,
    getPricesByIdentityId,
    getPricesByHabitId,
    getIdentityById,
    getIdentitiesByPriceId,

    // Linking operations
    linkPriceToIdentity,
    linkHabitToPrice,
    linkPriceToHabit,

    // New removal operations
    removeHabitFromPrice,
    removePriceFromIdentity,

    // Legacy unlinking operation (alias for removeHabitFromPrice)
    unlinkHabitFromPrice,
  }
}

