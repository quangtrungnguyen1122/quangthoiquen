import type { Habit, Price, Identity } from "../types"

export const useRelationQueries = (habits: Habit[], prices: Price[], identities: Identity[]) => {
  const getHabitsByPriceId = (priceId: string): Habit[] => {
    const price = prices.find((p) => p.id === priceId)
    if (!price) return []

    return habits.filter((habit) => price.habitIds.includes(habit.id) || habit.priceIds.includes(priceId))
  }

  const getPricesByIdentityId = (identityId: string): Price[] => {
    const identity = identities.find((i) => i.id === identityId)
    if (!identity) return []

    return prices.filter((price) => identity.priceIds.includes(price.id) || price.identityIds.includes(identityId))
  }

  const getPricesByHabitId = (habitId: string): Price[] => {
    const habit = habits.find((h) => h.id === habitId)
    if (!habit) return []

    return prices.filter((price) => habit.priceIds.includes(price.id) || price.habitIds.includes(habitId))
  }

  const getIdentityById = (identityId: string): Identity | undefined => {
    return identities.find((identity) => identity.id === identityId)
  }

  const getIdentitiesByPriceId = (priceId: string): Identity[] => {
    const price = prices.find((p) => p.id === priceId)
    if (!price) return []

    return identities.filter(
      (identity) => price.identityIds.includes(identity.id) || identity.priceIds.includes(priceId),
    )
  }

  return {
    getHabitsByPriceId,
    getPricesByIdentityId,
    getPricesByHabitId,
    getIdentityById,
    getIdentitiesByPriceId,
  }
}

