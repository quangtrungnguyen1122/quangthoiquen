import type React from "react"
import type { Habit, Price } from "../types"
import { removeHabitFromPriceApi, removePriceFromIdentityApi } from "@/services"

export const useUnlinkOperations = (
  setPrices: React.Dispatch<React.SetStateAction<Price[]>>,
  setHabits: React.Dispatch<React.SetStateAction<Habit[]>>,
  refreshData?: () => Promise<void>,
) => {
  // Renamed function to match the new approach
  const removeHabitFromPrice = async (priceId: string, habitId: string): Promise<boolean> => {
    try {
      console.log("Starting habit removal operation:", { priceId, habitId })

      // Call the API to remove the relationship
      const success = await removeHabitFromPriceApi(priceId, habitId)

      if (!success) {
        console.error("API call to remove habit failed")
        return false
      }

      console.log("API call successful, updating local state")

      // Update the local state
      setHabits((prevHabits) => {
        return prevHabits.map((habit) => {
          if (habit.id === habitId) {
            return {
              ...habit,
              priceIds: habit.priceIds.filter((id) => id !== priceId),
            }
          }
          return habit
        })
      })

      setPrices((prevPrices) => {
        return prevPrices.map((price) => {
          if (price.id === priceId) {
            return {
              ...price,
              habitIds: price.habitIds.filter((id) => id !== habitId),
            }
          }
          return price
        })
      })

      // Force a data refresh to ensure consistency
      if (refreshData) {
        console.log("Triggering data refresh after removing habit from price")
        await refreshData()
      }

      return true
    } catch (error) {
      console.error("Exception in removeHabitFromPrice:", error)

      // Try to refresh data to get a consistent state
      if (refreshData) {
        try {
          await refreshData()
        } catch (refreshError) {
          console.error("Error refreshing data after removal error:", refreshError)
        }
      }

      return false
    }
  }

  const removePriceFromIdentity = async (identityId: string, priceId: string): Promise<boolean> => {
    try {
      console.log("Starting price removal operation:", { identityId, priceId })

      // Call the API to remove the relationship
      const success = await removePriceFromIdentityApi(identityId, priceId)

      if (!success) {
        console.error("API call to remove price failed")
        return false
      }

      // Force a data refresh to ensure consistency
      if (refreshData) {
        console.log("Triggering data refresh after removing price from identity")
        await refreshData()
      }

      return true
    } catch (error) {
      console.error("Exception in removePriceFromIdentity:", error)

      // Try to refresh data to get a consistent state
      if (refreshData) {
        try {
          await refreshData()
        } catch (refreshError) {
          console.error("Error refreshing data after removal error:", refreshError)
        }
      }

      return false
    }
  }

  return {
    removeHabitFromPrice,
    removePriceFromIdentity,
  }
}

