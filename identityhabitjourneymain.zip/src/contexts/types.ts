// Types for the Habit context

export interface Habit {
  id: string
  name: string
  description: string
  difficulty: "easy" | "medium" | "hard"
  completed: boolean
  points: number
  priceIds: string[]
  completionFrequency: "daily" | "weekly" | "specific-days"
  icon?: string
}

export interface Price {
  id: string
  name: string
  description: string
  habitIds: string[]
  identityIds: string[]
  completionPercentage: number
  icon?: string
}

export interface Identity {
  id: string
  name: string
  description: string
  priceIds: string[]
  streak: number
  highestStreak: number
  progress: number
  avatar?: string
}

export interface User {
  id: string
  username: string
  avatar?: string
  joinedDate: Date
  totalPoints: number
  last30DaysPoints: number
  last7DaysPoints: number
  streaks: Record<string, number>
  position: number
}

export interface LeaderboardUser {
  id: string
  username: string
  avatar?: string
  joinedDate: Date // Adding this property that was missing
  totalPoints: number
  last30DaysPoints: number
  last7DaysPoints: number
  streaks: Record<string, number>
  position: number
}

export interface HabitContextType {
  habits: Habit[]
  prices: Price[]
  identities: Identity[]
  currentUser: User | null
  leaderboardUsers: LeaderboardUser[]
  isLoading: boolean

  refreshData: () => Promise<void>

  completeHabit: (habitId: string) => Promise<void>
  addHabit: (habit: Omit<Habit, "id">) => Promise<string | null> // Changed return type from Habit to string | null
  updateHabit: (id: string, habitUpdate: Partial<Omit<Habit, "id">>) => Promise<void>
  deleteHabit: (id: string) => Promise<boolean> // Added deleteHabit method

  getHabitsByPriceId: (priceId: string) => Habit[]
  getPricesByIdentityId: (identityId: string) => Price[]
  getPricesByHabitId: (habitId: string) => Price[]
  getIdentityById: (identityId: string) => Identity | undefined
  getIdentitiesByPriceId: (priceId: string) => Identity[]

  // Linking operations
  linkPriceToIdentity: (identityId: string, priceId: string) => Promise<boolean>
  linkHabitToPrice: (priceId: string, habitId: string) => Promise<boolean>
  linkPriceToHabit: (priceId: string, habitId: string) => Promise<boolean>

  // Original unlinking operation (now an alias)
  unlinkHabitFromPrice: (priceId: string, habitId: string) => Promise<boolean>

  // New removal operations
  removeHabitFromPrice: (priceId: string, habitId: string) => Promise<boolean>
  removePriceFromIdentity: (identityId: string, priceId: string) => Promise<boolean>

  addPrice: (price: Omit<Price, "id">) => Promise<string | null> // Changed return type from Price to string | null
  updatePrice: (id: string, priceUpdate: Partial<Omit<Price, "id">>) => Promise<boolean>
  deletePrice: (id: string) => Promise<boolean>

  addIdentity: (identity: Omit<Identity, "id">) => Promise<string | null> // Changed return type from Identity to string | null
  updateIdentity: (id: string, identityUpdate: Partial<Omit<Identity, "id">>) => Promise<boolean>
  deleteIdentity: (id: string) => Promise<boolean>
}

