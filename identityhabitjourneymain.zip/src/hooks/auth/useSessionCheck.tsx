"use client"

import { useState, useEffect } from "react"
import { useNavigate, useLocation } from "react-router-dom"
import { supabase } from "@/integrations/supabase/client"

export const useSessionCheck = () => {
  const [isCheckingSession, setIsCheckingSession] = useState(true)
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    const checkSession = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession()
        if (session) {
          // If we're on the auth page and already logged in, redirect to home
          if (location.pathname === "/auth") {
            navigate("/")
          }
        }
      } catch (error) {
        console.error("Error checking session:", error)
      } finally {
        setIsCheckingSession(false)
      }
    }

    checkSession()

    // Set up auth state listener
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session && location.pathname === "/auth") {
        navigate("/")
      }
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [navigate, location.pathname])

  return { isCheckingSession }
}

