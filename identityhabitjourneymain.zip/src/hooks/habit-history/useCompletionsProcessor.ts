"use client"

import { useMemo } from "react"
import type { Habit } from "@/contexts/types"
import type { HabitCompletion, HabitCompletionRecord } from "@/components/habit-history/types"

export const useCompletionsProcessor = (
  habits: Habit[],
  daysInMonth: Date[],
  completionRecords: HabitCompletionRecord[],
) => {
  // Only process completions if we have both habits and completion records
  // Use a more efficient approach to create habit completions
  const habitCompletions = useMemo(() => {
    if (!habits.length || !daysInMonth.length) {
      return []
    }

    const completions: HabitCompletion[] = []

    // Create a map for faster lookup of completion records
    const completionMap = new Map<string, HabitCompletionRecord>()
    completionRecords.forEach((record) => {
      const key = `${record.habit_id}-${record.completed_date}`
      completionMap.set(key, record)
    })

    habits.forEach((habit) => {
      daysInMonth.forEach((day) => {
        const formattedDate = format(day, "yyyy-MM-dd")
        const key = `${habit.id}-${formattedDate}`
        const record = completionMap.get(key)

        completions.push({
          habit,
          date: day,
          completed: record ? record.completed : false,
          id: record?.id,
        })
      })
    })

    return completions
  }, [habits, daysInMonth, completionRecords])

  // Group completions by habit more efficiently
  const completionsByHabit = useMemo(() => {
    if (!habitCompletions.length) {
      return []
    }

    // Create a map to group completions by habit ID
    const habitMap = new Map<string, HabitCompletion[]>()

    habitCompletions.forEach((completion) => {
      const habitId = completion.habit.id
      if (!habitMap.has(habitId)) {
        habitMap.set(habitId, [])
      }
      habitMap.get(habitId)!.push(completion)
    })

    // Convert map to array of objects
    return Array.from(habitMap.entries()).map(([habitId, completions]) => {
      return {
        habit: completions[0].habit,
        completions: completions.sort((a, b) => a.date.getTime() - b.date.getTime()),
      }
    })
  }, [habitCompletions])

  return {
    habitCompletions,
    completionsByHabit,
  }
}

// Helper function to format date
function format(date: Date, formatStr: string): string {
  return date.toISOString().split("T")[0] // Simple YYYY-MM-DD format
}

