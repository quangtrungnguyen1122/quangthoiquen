"use client"

import { useState, useMemo, useCallback } from "react"
import { startOfMonth, endOfMonth, format, isSameMonth } from "date-fns"

export const useDateNavigation = () => {
  const [currentMonth, setCurrentMonth] = useState(new Date())

  // Memoize the days in month calculation to prevent unnecessary re-renders
  const daysInMonth = useMemo(() => {
    const monthStart = startOfMonth(currentMonth)
    const monthEnd = endOfMonth(currentMonth)
    const result = []
    let currentDate = new Date(monthStart)

    while (currentDate <= monthEnd) {
      result.push(new Date(currentDate))
      currentDate = new Date(currentDate)
      currentDate.setDate(currentDate.getDate() + 1)
    }

    return result
  }, [currentMonth])

  // Memoize the current month check to prevent unnecessary re-renders
  const isCurrentMonth = useMemo(() => {
    const now = new Date()
    return isSameMonth(now, currentMonth)
  }, [currentMonth])

  // Use callbacks for navigation functions to maintain stable references
  const goToPreviousMonth = useCallback(() => {
    setCurrentMonth((prevMonth) => {
      const newMonth = new Date(prevMonth)
      newMonth.setMonth(newMonth.getMonth() - 1)
      return newMonth
    })
  }, [])

  const goToNextMonth = useCallback(() => {
    setCurrentMonth((prevMonth) => {
      const newMonth = new Date(prevMonth)
      newMonth.setMonth(newMonth.getMonth() + 1)
      return newMonth
    })
  }, [])

  const getMonthDateRange = useCallback(() => {
    return {
      startDate: format(startOfMonth(currentMonth), "yyyy-MM-dd"),
      endDate: format(endOfMonth(currentMonth), "yyyy-MM-dd"),
    }
  }, [currentMonth])

  return {
    currentMonth,
    daysInMonth,
    isCurrentMonth,
    goToPreviousMonth,
    goToNextMonth,
    getMonthDateRange,
  }
}

