"use client"

import { useState, useEffect, useCallback, useMemo } from "react"
import { format, isToday, isPast } from "date-fns"
import { toast } from "sonner"
import { useHabit } from "@/contexts/HabitContext"
import { supabase } from "@/integrations/supabase/client"
import type { Habit } from "@/contexts/types"
import type { HabitCompletionRecord } from "@/components/habit-history/types"
import { fetchHabitCompletionRecords, toggleHabitCompletionStatus } from "@/services/habit/habitHistoryService"
import { useDateNavigation } from "./useDateNavigation"
import { useCompletionsProcessor } from "./useCompletionsProcessor"

export const useHabitHistory = () => {
  const { habits } = useHabit()
  const [isUpdating, setIsUpdating] = useState(false)
  const [completionRecords, setCompletionRecords] = useState<HabitCompletionRecord[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isFetching, setIsFetching] = useState(false)
  const [fetchTrigger, setFetchTrigger] = useState(0) // Add a trigger for controlled refetching

  const { currentMonth, daysInMonth, isCurrentMonth, goToPreviousMonth, goToNextMonth, getMonthDateRange } =
    useDateNavigation()

  // Memoize the completion records to prevent unnecessary re-renders
  const memoizedCompletionRecords = useMemo(() => completionRecords, [completionRecords])

  // Memoize the habits to prevent unnecessary re-renders
  const memoizedHabits = useMemo(() => habits, [habits])

  // Use the memoized values for processing
  const { completionsByHabit } = useCompletionsProcessor(memoizedHabits, daysInMonth, memoizedCompletionRecords)

  const fetchCompletionRecords = useCallback(async () => {
    if (isFetching) return

    try {
      setIsFetching(true)
      // Only show loading state on initial load, not on subsequent fetches
      if (completionRecords.length === 0) {
        setIsLoading(true)
      }

      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData.session) {
        setIsLoading(false)
        setIsFetching(false)
        return
      }

      const { startDate, endDate } = getMonthDateRange()
      console.log("Fetching completion records for range:", startDate, "to", endDate)

      const data = await fetchHabitCompletionRecords(sessionData.session.user.id, startDate, endDate)

      setCompletionRecords(data || [])
    } catch (error) {
      console.error("Error fetching completion records:", error)
      toast.error("Failed to load habit completion history")
    } finally {
      setIsLoading(false)
      setIsFetching(false)
    }
  }, [getMonthDateRange, isFetching, completionRecords.length])

  // Use effect with proper dependencies to prevent unnecessary fetches
  useEffect(() => {
    fetchCompletionRecords()
  }, [fetchCompletionRecords, fetchTrigger, currentMonth])

  const handleCompletionToggle = async (habit: Habit, date: Date, currentlyCompleted: boolean) => {
    if (isUpdating) return

    if (!isToday(date) && !isPast(date)) {
      toast.error("Cannot mark future dates as complete")
      return
    }

    try {
      setIsUpdating(true)

      const { data: sessionData } = await supabase.auth.getSession()
      if (!sessionData.session) {
        toast.error("You must be logged in to track habit completions")
        return
      }

      const userId = sessionData.session.user.id
      const formattedDate = format(date, "yyyy-MM-dd")

      const existingRecord = completionRecords.find(
        (r) => r.habit_id === habit.id && r.completed_date === formattedDate,
      )

      const identityId = existingRecord?.identity_id

      const completionId = await toggleHabitCompletionStatus(habit.id, userId, date, currentlyCompleted, identityId)

      if (completionId) {
        // Update local state optimistically
        if (existingRecord) {
          setCompletionRecords((prev) =>
            prev.map((record) =>
              record.id === existingRecord.id ? { ...record, completed: !currentlyCompleted } : record,
            ),
          )
        } else {
          setCompletionRecords((prev) => [
            ...prev,
            {
              id: completionId,
              habit_id: habit.id,
              user_id: userId,
              completed_date: formattedDate,
              completed: !currentlyCompleted,
              created_at: new Date().toISOString(),
              identity_id: identityId,
            },
          ])
        }
      }

      if (currentlyCompleted) {
        toast.info(`Marked "${habit.name}" as incomplete for ${format(date, "MMM dd, yyyy")}`)
      } else {
        toast.success(`Completed "${habit.name}" for ${format(date, "MMM dd, yyyy")}`)
      }

      // Trigger a refetch after toggling to ensure data consistency
      setFetchTrigger((prev) => prev + 1)
    } catch (error) {
      console.error("Error updating habit completion:", error)
      toast.error("Failed to update habit completion status")
    } finally {
      setIsUpdating(false)
    }
  }

  return {
    currentMonth,
    daysInMonth,
    completionsByHabit,
    isCurrentMonth,
    isUpdating,
    isLoading,
    goToPreviousMonth,
    goToNextMonth,
    handleCompletionToggle,
  }
}

