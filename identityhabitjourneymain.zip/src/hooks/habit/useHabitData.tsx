"use client"

import { useParams } from "react-router-dom"
import { useHabit } from "@/contexts/HabitContext"
import type { Price } from "@/contexts/types"

export const useHabitData = () => {
  const { habitId } = useParams<{ habitId: string }>()
  const { habits, getPricesByHabitId } = useHabit()

  // Find the habit by ID
  const habit = habits.find((h) => h.id === habitId)

  // Get all prices related to this habit
  const relatedPrices: Price[] = habit ? getPricesByHabitId(habit.id) : []

  return {
    habit,
    relatedPrices,
  }
}

