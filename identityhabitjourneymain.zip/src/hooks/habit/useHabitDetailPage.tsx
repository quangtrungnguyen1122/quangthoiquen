"use client"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useHabit } from "@/contexts/HabitContext"
import { useHabitData } from "./useHabitData"
import { toast } from "sonner"
import HabitNotFound from "@/components/habit/HabitNotFound"

export interface HabitDetailDialogState {
  isUnlinking: boolean
}

export const useHabitDetailPage = () => {
  const navigate = useNavigate()
  const { removeHabitFromPrice } = useHabit()
  const { habit, relatedPrices } = useHabitData()

  const [dialogState, setDialogState] = useState<HabitDetailDialogState>({
    isUnlinking: false,
  })

  const renderNotFound = () => {
    return <HabitNotFound />
  }

  const onUnlinkPrice = async (priceId: string, habitId: string) => {
    if (!priceId || !habitId) {
      toast.error("Missing price or habit ID")
      return
    }

    setDialogState((prev) => ({ ...prev, isUnlinking: true }))

    try {
      // Use the new method instead
      const success = await removeHabitFromPrice(priceId, habitId)

      if (success) {
        toast.success("Price removed from habit successfully")
      } else {
        throw new Error("Failed to remove price from habit")
      }
    } catch (error) {
      console.error("Error removing price from habit:", error)
      toast.error("Failed to remove price from habit")
    } finally {
      setDialogState((prev) => ({ ...prev, isUnlinking: false }))
    }
  }

  return {
    habit,
    relatedPrices,
    dialogState,
    onUnlinkPrice,
    renderNotFound,
  }
}

