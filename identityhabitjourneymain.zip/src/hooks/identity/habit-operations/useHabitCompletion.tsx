import { useHabit } from "@/contexts/HabitContext"
import { calculateCompletionRate } from "@/utils/habitUtils"
import {
  calculateStreakValues,
  displayStreakNotification,
  recordHabitCompletionInHistory,
} from "@/services/habit/habitStreakService"

export const useHabitCompletion = () => {
  const { completeHabit, habits, prices, identities, updateIdentity, currentUser } = useHabit()

  const onCompleteHabit = async (habitId: string) => {
    await completeHabit(habitId)

    // After completing the habit, update the progress of related identities
    const habit = habits.find((h) => h.id === habitId)
    if (!habit) return

    // Find prices related to this habit
    const relatedPrices = prices.filter((p) => p.habitIds.includes(habitId))

    // For each related price, find the identities and update their progress
    const updatedIdentityIds = new Set<string>()

    for (const price of relatedPrices) {
      const relatedIdentities = identities.filter((i) => i.priceIds.includes(price.id))

      for (const identity of relatedIdentities) {
        if (updatedIdentityIds.has(identity.id)) continue

        // Calculate new progress
        const newProgress = calculateIdentityProgress(identity, prices, habits)

        // Update streak values
        const { streak: newStreak, highestStreak: newHighestStreak } = calculateStreakValues(identity, true)

        // Update the identity with new progress and streak values
        await updateIdentity(identity.id, {
          progress: newProgress,
          streak: newStreak,
          highestStreak: newHighestStreak,
        })

        updatedIdentityIds.add(identity.id)

        // Show toast notification about streak update
        displayStreakNotification(identity.name, newStreak)

        // Record habit completion in history for long-term tracking
        // Now passing the identity ID to associate the completion with this identity
        if (currentUser) {
          await recordHabitCompletionInHistory(habitId, currentUser.id, identity.id)
        }
      }
    }

    // If the habit isn't linked to any identity yet, still record the completion
    // but without an associated identity
    if (updatedIdentityIds.size === 0 && currentUser) {
      await recordHabitCompletionInHistory(habitId, currentUser.id)
    }
  }

  return { onCompleteHabit }
}

// Helper function to calculate identity progress
const calculateIdentityProgress = (identity: any, prices: any[], habits: any[]): number => {
  // Get all prices for this identity
  const identityPrices = prices.filter((p) => identity.priceIds.includes(p.id))

  // Calculate total and completed habits for this identity
  let totalHabits = 0
  let completedHabits = 0

  identityPrices.forEach((p) => {
    const priceHabits = habits.filter((h) => p.habitIds.includes(h.id))
    totalHabits += priceHabits.length
    completedHabits += priceHabits.filter((h) => h.completed).length
  })

  // Calculate new progress using the utility function
  return calculateCompletionRate(completedHabits, totalHabits)
}

