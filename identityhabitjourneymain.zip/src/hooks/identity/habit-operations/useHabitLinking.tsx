import { toast } from "sonner"
import { useHabit } from "@/contexts/HabitContext"

export const useHabitLinking = (setDialogState: any) => {
  const { linkPriceToHabit, addHabit } = useHabit()

  const onAddHabit = async (selectedPriceId: string, selectedHabitId: string) => {
    if (!selectedHabitId || !selectedPriceId) {
      toast.error("Please select both a habit and a price")
      return
    }

    setDialogState((prevState) => ({
      ...prevState,
      isLinking: true,
    }))

    try {
      const success = await linkPriceToHabit(selectedPriceId, selectedHabitId)
      if (success) {
        setDialogState((prevState) => ({
          ...prevState,
          isAddHabitDialogOpen: false,
        }))
        toast.success("Habit linked to price successfully")
      }
    } catch (error) {
      console.error("Error linking habit to price:", error)
      toast.error("Failed to link habit to price")
    } finally {
      setDialogState((prevState) => ({
        ...prevState,
        isLinking: false,
        selectedHabitId: "",
        selectedPriceId: "",
      }))
    }
  }

  const onCreateAndAddHabit = async (
    selectedPriceId: string,
    name: string,
    description: string,
    difficulty: "easy" | "medium" | "hard",
  ) => {
    if (!selectedPriceId) {
      toast.error("Please select a price first")
      return
    }

    if (!name || !description) {
      toast.error("Please provide both a name and description for the habit")
      return
    }

    setDialogState((prevState) => ({
      ...prevState,
      isLinking: true,
    }))

    try {
      // Calculate points based on difficulty
      const points = difficulty === "easy" ? 5 : difficulty === "medium" ? 10 : 15 // hard

      // Create new habit
      const habitId = await addHabit({
        name,
        description,
        difficulty,
        points,
        completed: false,
        priceIds: [selectedPriceId],
        completionFrequency: "daily",
      })

      if (!habitId) {
        throw new Error("Failed to create habit")
      }

      // Link habit to price
      const success = await linkPriceToHabit(selectedPriceId, habitId)

      if (success) {
        setDialogState((prevState) => ({
          ...prevState,
          isAddHabitDialogOpen: false,
        }))
        toast.success("Habit created and linked to price successfully")
      } else {
        throw new Error("Failed to link habit to price")
      }
    } catch (error) {
      console.error("Error creating and linking habit:", error)
      toast.error("Failed to create and link habit")
    } finally {
      setDialogState((prevState) => ({
        ...prevState,
        isLinking: false,
        selectedPriceId: "",
      }))
    }
  }

  return {
    onAddHabit,
    onCreateAndAddHabit,
  }
}

