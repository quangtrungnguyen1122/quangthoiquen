import { toast } from "sonner"
import { useHabit } from "@/contexts/HabitContext"

export const useHabitUnlinking = (setDialogState: any) => {
  const { removeHabitFromPrice, refreshData } = useHabit()

  const onUnlinkHabit = async (priceId: string, habitId: string) => {
    console.log("Starting habit unlinking process:", { priceId, habitId })

    // Set unlinking state to true
    setDialogState((prevState) => ({
      ...prevState,
      isUnlinking: true,
    }))

    try {
      // Call the new method instead of unlinkHabitFromPrice
      const success = await removeHabitFromPrice(priceId, habitId)

      if (success) {
        toast.success("Habit removed from price successfully")
        console.log("Habit successfully removed, refreshing data")

        // Force a data refresh
        if (refreshData) {
          await refreshData()
        }
      } else {
        toast.error("Failed to remove habit from price")
        console.error("Removing returned false")
      }
    } catch (error) {
      console.error("Error in onUnlinkHabit:", error)
      toast.error("Failed to remove habit from price")
    } finally {
      // Always reset unlinking state
      setDialogState((prevState) => ({
        ...prevState,
        isUnlinking: false,
      }))
    }
  }

  return { onUnlinkHabit }
}

