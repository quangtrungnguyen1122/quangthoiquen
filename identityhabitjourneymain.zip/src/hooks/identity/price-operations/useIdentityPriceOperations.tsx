import { toast } from "sonner"
import { useHabit } from "@/contexts/HabitContext"
import type { Identity } from "@/contexts/types"

export const useIdentityPriceOperations = (identity: Identity | undefined, setDialogState: any) => {
  const { linkPriceToIdentity, addPrice } = useHabit()

  const onAddPrice = async (selectedPriceId: string) => {
    if (!selectedPriceId || !identity) {
      toast.error("Please select a price")
      return
    }

    setDialogState((prevState) => ({
      ...prevState,
      isLinking: true,
    }))

    try {
      const success = await linkPriceToIdentity(identity.id, selectedPriceId)
      if (success) {
        setDialogState((prevState) => ({
          ...prevState,
          isAddPriceDialogOpen: false,
        }))
        toast.success("Price added to identity successfully")
      }
    } catch (error) {
      console.error("Error linking price to identity:", error)
      toast.error("Failed to add price to identity")
    } finally {
      setDialogState((prevState) => ({
        ...prevState,
        isLinking: false,
        selectedPriceId: "",
      }))
    }
  }

  const onCreateAndAddPrice = async (name: string, description: string) => {
    if (!identity) {
      toast.error("Identity not found")
      return
    }

    if (!name || !description) {
      toast.error("Please provide both a name and description for the price")
      return
    }

    setDialogState((prevState) => ({
      ...prevState,
      isLinking: true,
    }))

    try {
      // First create the new price
      const priceId = await addPrice({
        name,
        description,
        habitIds: [],
        identityIds: [],
        completionPercentage: 0,
      })

      if (!priceId) {
        throw new Error("Failed to create price")
      }

      // Then link it to the identity
      const success = await linkPriceToIdentity(identity.id, priceId)

      if (success) {
        setDialogState((prevState) => ({
          ...prevState,
          isAddPriceDialogOpen: false,
        }))
        toast.success("Price created and added to identity successfully")
      } else {
        throw new Error("Failed to link price to identity")
      }
    } catch (error) {
      console.error("Error creating and linking price:", error)
      toast.error("Failed to create and add price")
    } finally {
      setDialogState((prevState) => ({
        ...prevState,
        isLinking: false,
      }))
    }
  }

  return {
    onAddPrice,
    onCreateAndAddPrice,
  }
}

