import { toast } from "sonner"
import { useHabit } from "@/contexts/HabitContext"

export const usePriceUnlinking = (setDialogState: any) => {
  const { removePriceFromIdentity, refreshData } = useHabit()

  const onRemovePrice = async (identityId: string, priceId: string) => {
    console.log("Starting price unlinking process:", { identityId, priceId })

    // Set unlinking state to true
    setDialogState((prevState) => ({
      ...prevState,
      isUnlinking: true,
    }))

    try {
      // Call the removePriceFromIdentity method
      const success = await removePriceFromIdentity(identityId, priceId)

      if (success) {
        toast.success("Price removed from identity successfully")
        console.log("Price successfully removed, refreshing data")

        // Force a data refresh
        if (refreshData) {
          await refreshData()
        }
      } else {
        toast.error("Failed to remove price from identity")
        console.error("Removing returned false")
      }
    } catch (error) {
      console.error("Error in onRemovePrice:", error)
      toast.error("Failed to remove price from identity")
    } finally {
      // Always reset unlinking state
      setDialogState((prevState) => ({
        ...prevState,
        isUnlinking: false,
      }))
    }
  }

  return { onRemovePrice }
}

