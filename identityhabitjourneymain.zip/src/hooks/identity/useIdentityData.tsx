"use client"

import { useState } from "react"
import { useParams } from "react-router-dom"
import { useHabit } from "@/contexts/HabitContext"
import type { Price } from "@/contexts/types"

export const useIdentityData = () => {
  const { id } = useParams<{ id: string }>()
  const { identities, habits, prices, getPricesByIdentityId, getHabitsByPriceId } = useHabit()

  const identity = identities.find((identity) => identity.id === id)

  // State to manage related prices (for reordering)
  const [relatedPrices, setRelatedPrices] = useState<Price[]>([])

  // Get related prices from context
  const contextRelatedPrices = identity ? getPricesByIdentityId(identity.id) : []

  // Update local state if context prices change
  if (
    identity &&
    JSON.stringify(relatedPrices) !== JSON.stringify(contextRelatedPrices) &&
    contextRelatedPrices.length > 0
  ) {
    setRelatedPrices(contextRelatedPrices)
  }

  return {
    identity,
    relatedPrices: relatedPrices.length > 0 ? relatedPrices : contextRelatedPrices,
    getHabitsByPriceId,
    setRelatedPrices,
  }
}

