import { useHabit } from "@/contexts/HabitContext"
import { useIdentityData } from "./useIdentityData"
import { useIdentityDialogState } from "./useIdentityDialogState"
import { useIdentityPriceOperations } from "./price-operations"
import { useIdentityHabitOperations } from "./useIdentityHabitOperations"
import IdentityNotFound from "@/components/identity/IdentityNotFound"
import { toast } from "sonner"
import type { Price, Habit } from "@/contexts/types"

export type { IdentityDetailDialogState } from "./useIdentityDialogState"

export interface IdentityDetailHandlers {
  renderNotFound: () => JSX.Element
  getHabitsByPriceId: (priceId: string) => any[]
  onCompleteHabit: (habitId: string) => void
  onOpenAddPriceDialog: () => void
  onOpenAddHabitDialog: (priceId: string) => void
  onUnlinkHabit: (priceId: string, habitId: string) => Promise<void>
  onRemovePrice: (priceId: string) => Promise<void>
  onAddPrice: () => Promise<void>
  onAddHabit: () => Promise<void>
  onCreateAndAddPrice: (name: string, description: string) => Promise<void>
  onCreateAndAddHabit: (name: string, description: string, difficulty: "easy" | "medium" | "hard") => Promise<void>
  setAddPriceDialogOpen: (open: boolean) => void
  setAddHabitDialogOpen: (open: boolean) => void
  onSelectPriceId: (priceId: string) => void
  onSelectHabitId: (habitId: string) => void
  onEditPrice: (price: Price) => void
  onEditHabit: (habit: Habit) => void
}

export const useIdentityDetailPage = () => {
  // Get identity data
  const { identity, relatedPrices, getHabitsByPriceId } = useIdentityData()

  // Get context access
  const { updatePrice, updateIdentity } = useHabit()

  // Get dialog state and handling
  const {
    dialogState,
    setDialogState,
    setAddPriceDialogOpen,
    setAddHabitDialogOpen,
    onOpenAddPriceDialog,
    onOpenAddHabitDialog,
    onSelectPriceId,
    onSelectHabitId,
  } = useIdentityDialogState(identity, relatedPrices)

  // Get price operations
  const { onAddPrice: addPriceOperation, onCreateAndAddPrice: createAndAddPriceOperation } = useIdentityPriceOperations(
    identity,
    setDialogState,
  )

  // Get habit operations
  const {
    onCompleteHabit,
    onUnlinkHabit,
    onAddHabit: addHabitOperation,
    onCreateAndAddHabit: createAndAddHabitOperation,
    onRemovePrice: removePrice,
  } = useIdentityHabitOperations(setDialogState)

  const renderNotFound = () => {
    return <IdentityNotFound />
  }

  const onAddPrice = async () => {
    await addPriceOperation(dialogState.selectedPriceId)
  }

  const onAddHabit = async () => {
    await addHabitOperation(dialogState.selectedPriceId, dialogState.selectedHabitId)
  }

  const onCreateAndAddPrice = async (name: string, description: string) => {
    await createAndAddPriceOperation(name, description)
  }

  const onCreateAndAddHabit = async (name: string, description: string, difficulty: "easy" | "medium" | "hard") => {
    await createAndAddHabitOperation(dialogState.selectedPriceId, name, description, difficulty)
  }

  const onRemovePrice = async (priceId: string) => {
    if (identity) {
      await removePrice(identity.id, priceId)
    }
  }

  const onEditPrice = (price: Price) => {
    toast.info(`Editing price: ${price.name}`)
  }

  const onEditHabit = (habit: Habit) => {
    toast.info(`Editing habit: ${habit.name}`)
  }

  const handlers: IdentityDetailHandlers = {
    renderNotFound,
    getHabitsByPriceId,
    onCompleteHabit,
    onOpenAddPriceDialog,
    onOpenAddHabitDialog,
    onUnlinkHabit,
    onRemovePrice,
    onAddPrice,
    onAddHabit,
    onCreateAndAddPrice,
    onCreateAndAddHabit,
    setAddPriceDialogOpen,
    setAddHabitDialogOpen,
    onSelectPriceId,
    onSelectHabitId,
    onEditPrice,
    onEditHabit,
  }

  return {
    identity,
    relatedPrices,
    dialogState,
    handlers,
  }
}

