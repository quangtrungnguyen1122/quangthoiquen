"use client"

import { useState } from "react"
import { useHabit } from "@/contexts/HabitContext"
import type { Price, Habit } from "@/contexts/types"

export interface IdentityDetailDialogState {
  isAddPriceDialogOpen: boolean
  isAddHabitDialogOpen: boolean
  selectedPriceId: string
  selectedHabitId: string
  isLinking: boolean
  isUnlinking: boolean
  availablePrices: Price[]
  availableHabits: Habit[]
}

export const useIdentityDialogState = (identity: any, relatedPrices: Price[]) => {
  const { prices, habits } = useHabit()

  const [dialogState, setDialogState] = useState<IdentityDetailDialogState>({
    isAddPriceDialogOpen: false,
    isAddHabitDialogOpen: false,
    selectedPriceId: "",
    selectedHabitId: "",
    isLinking: false,
    isUnlinking: false,
    availablePrices: [],
    availableHabits: [],
  })

  if (identity) {
    const availablePrices = prices.filter((price) => !identity.priceIds.includes(price.id))

    const availableHabits = habits.filter((habit) => {
      return !relatedPrices.some((price) => price.habitIds.includes(habit.id))
    })

    if (
      dialogState.availablePrices.length !== availablePrices.length ||
      dialogState.availableHabits.length !== availableHabits.length
    ) {
      setDialogState((prevState) => ({
        ...prevState,
        availablePrices,
        availableHabits,
      }))
    }
  }

  const setAddPriceDialogOpen = (open: boolean) => {
    setDialogState((prevState) => ({
      ...prevState,
      isAddPriceDialogOpen: open,
      selectedPriceId: open ? prevState.selectedPriceId : "",
    }))
  }

  const setAddHabitDialogOpen = (open: boolean) => {
    setDialogState((prevState) => ({
      ...prevState,
      isAddHabitDialogOpen: open,
      selectedHabitId: open ? prevState.selectedHabitId : "",
      selectedPriceId: open ? prevState.selectedPriceId : "",
    }))
  }

  const onOpenAddPriceDialog = () => {
    setAddPriceDialogOpen(true)
  }

  const onOpenAddHabitDialog = (priceId: string) => {
    setDialogState((prevState) => ({
      ...prevState,
      selectedPriceId: priceId,
      isAddHabitDialogOpen: true,
    }))
  }

  const onSelectPriceId = (priceId: string) => {
    setDialogState((prevState) => ({
      ...prevState,
      selectedPriceId: priceId,
    }))
  }

  const onSelectHabitId = (habitId: string) => {
    setDialogState((prevState) => ({
      ...prevState,
      selectedHabitId: habitId,
    }))
  }

  return {
    dialogState,
    setDialogState,
    setAddPriceDialogOpen,
    setAddHabitDialogOpen,
    onOpenAddPriceDialog,
    onOpenAddHabitDialog,
    onSelectPriceId,
    onSelectHabitId,
  }
}

