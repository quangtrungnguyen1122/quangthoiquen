import { useHabitCompletion, useHabitLinking, useHabitUnlinking } from "./habit-operations"
import { usePriceUnlinking } from "./price-operations"

export const useIdentityHabitOperations = (setDialogState: any) => {
  // Get habit completion function
  const { onCompleteHabit } = useHabitCompletion()

  // Get habit linking functions
  const { onAddHabit, onCreateAndAddHabit } = useHabitLinking(setDialogState)

  // Get habit unlinking function
  const { onUnlinkHabit } = useHabitUnlinking(setDialogState)

  // Get price unlinking function
  const { onRemovePrice } = usePriceUnlinking(setDialogState)

  return {
    onCompleteHabit,
    onUnlinkHabit,
    onAddHabit,
    onCreateAndAddHabit,
    onRemovePrice,
  }
}

