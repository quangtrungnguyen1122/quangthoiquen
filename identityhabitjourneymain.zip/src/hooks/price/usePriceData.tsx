"use client"

import { useState, useEffect } from "react"
import { useParams, useNavigate } from "react-router-dom"
import { useHabit } from "@/contexts/HabitContext"
import { toast } from "sonner"
import { supabase } from "@/integrations/supabase/client"

export const usePriceData = () => {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const { prices, habits, getHabitsByPriceId, getIdentitiesByPriceId } = useHabit()

  const [isLoading, setIsLoading] = useState(false)

  // Find the specific price
  const price = prices.find((price) => price.id === id)

  // Get related habits and identities
  const relatedHabits = price ? getHabitsByPriceId(price.id) : []
  const relatedIdentities = price ? getIdentitiesByPriceId(price.id) : []

  // Get available habits for linking (those not already linked to this price)
  const availableHabits = price ? habits.filter((habit) => !price.habitIds.includes(habit.id)) : []

  // Check if user has access to this price
  useEffect(() => {
    const checkAccess = async () => {
      setIsLoading(true)
      try {
        const {
          data: { user },
        } = await supabase.auth.getUser()
        if (!user) {
          navigate("/")
          toast.error("You need to be logged in to view this page")
          return
        }

        if (!price) {
          const { data, error } = await supabase.from("prices").select("*").eq("id", id).single()

          if (error || !data) {
            toast.error("Price not found or access denied")
            navigate("/")
          }
        }
      } catch (error) {
        console.error("Error checking access:", error)
        toast.error("An error occurred while loading the price")
        navigate("/")
      } finally {
        setIsLoading(false)
      }
    }

    checkAccess()
  }, [id, navigate, price])

  const renderNotFound = () => (
    <div className="text-center">
      <h1 className="text-2xl font-bold mb-4">Price not found</h1>
      <a href="/" className="text-primary hover:underline">
        Back to Dashboard
      </a>
    </div>
  )

  return {
    id,
    price,
    relatedHabits,
    relatedIdentities,
    availableHabits,
    isLoading,
    renderNotFound,
  }
}

