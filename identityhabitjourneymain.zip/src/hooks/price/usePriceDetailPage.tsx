import { usePriceData } from "./usePriceData"
import { usePriceDialogState } from "./usePriceDialogState"
import { usePriceHabitOperations } from "./usePriceHabitOperations"
import type { PriceDetailDialogState } from "./usePriceDialogState"
import type { PriceDetailHandlers } from "./usePriceHabitOperations"

export type { PriceDetailDialogState, PriceDetailHandlers }

export const usePriceDetailPage = () => {
  // Get price data
  const { id, price, relatedHabits, relatedIdentities, availableHabits, isLoading, renderNotFound } = usePriceData()

  // Get dialog state and actions
  const dialogStateHook = usePriceDialogState(availableHabits)
  const { dialogState, ...dialogStateActions } = dialogStateHook

  // Get habit operations
  const handlers = usePriceHabitOperations(price, dialogState, dialogStateActions, renderNotFound)

  return {
    id,
    price,
    relatedHabits,
    relatedIdentities,
    availableHabits,
    isLoading,
    dialogState,
    handlers,
  }
}

