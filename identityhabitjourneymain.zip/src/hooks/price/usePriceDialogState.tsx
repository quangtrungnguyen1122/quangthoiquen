"use client"

import { useState } from "react"

export interface PriceDetailDialogState {
  isAddHabitDialogOpen: boolean
  isCreatingHabit: boolean
  activeTab: string
  newHabitName: string
  newHabitDescription: string
  newHabitDifficulty: "easy" | "medium" | "hard"
  newHabitIcon: string
  selectedHabitId: string
}

export const usePriceDialogState = (availableHabits: any[] = []) => {
  const [isAddHabitDialogOpen, setIsAddHabitDialogOpen] = useState(false)
  const [isCreatingHabit, setIsCreatingHabit] = useState(false)
  const [activeTab, setActiveTab] = useState<string>(availableHabits.length > 0 ? "existing" : "new")

  // States for new habit form
  const [newHabitName, setNewHabitName] = useState("")
  const [newHabitDescription, setNewHabitDescription] = useState("")
  const [newHabitDifficulty, setNewHabitDifficulty] = useState<"easy" | "medium" | "hard">("medium")
  const [newHabitIcon, setNewHabitIcon] = useState("")

  // States for linking existing habit
  const [selectedHabitId, setSelectedHabitId] = useState("")

  const resetHabitForm = () => {
    setNewHabitName("")
    setNewHabitDescription("")
    setNewHabitDifficulty("medium")
    setNewHabitIcon("")
    setSelectedHabitId("")
    setActiveTab(availableHabits.length > 0 ? "existing" : "new")
  }

  const openAddHabitDialog = () => {
    resetHabitForm()
    setActiveTab(availableHabits.length > 0 ? "existing" : "new")
    setIsAddHabitDialogOpen(true)
  }

  const dialogState: PriceDetailDialogState = {
    isAddHabitDialogOpen,
    isCreatingHabit,
    activeTab,
    newHabitName,
    newHabitDescription,
    newHabitDifficulty,
    newHabitIcon,
    selectedHabitId,
  }

  return {
    dialogState,
    setIsAddHabitDialogOpen,
    setIsCreatingHabit,
    setActiveTab,
    setNewHabitName,
    setNewHabitDescription,
    setNewHabitDifficulty,
    setNewHabitIcon,
    setSelectedHabitId,
    resetHabitForm,
    openAddHabitDialog,
  }
}

