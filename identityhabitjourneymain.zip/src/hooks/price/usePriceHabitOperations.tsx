import { useHabit } from "@/contexts/HabitContext"
import { toast } from "sonner"
import type { Price } from "@/contexts/types"

export interface PriceDetailHandlers {
  completeHabit: (habitId: string) => void
  openAddHabitDialog: () => void
  handleCreateHabit: () => Promise<void>
  handleLinkExistingHabit: () => Promise<void>
  handleSubmit: () => void
  setIsAddHabitDialogOpen: (isOpen: boolean) => void
  setActiveTab: (tab: string) => void
  setNewHabitName: (name: string) => void
  setNewHabitDescription: (description: string) => void
  setNewHabitDifficulty: (difficulty: "easy" | "medium" | "hard") => void
  setNewHabitIcon: (icon: string) => void
  setSelectedHabitId: (id: string) => void
  renderNotFound: () => JSX.Element
}

export const usePriceHabitOperations = (
  price: Price | undefined,
  dialogState: any,
  dialogStateActions: any,
  renderNotFound: () => JSX.Element,
) => {
  const { completeHabit: completeHabitContext, addHabit, linkPriceToHabit } = useHabit()

  const { activeTab, newHabitName, newHabitDescription, newHabitDifficulty, newHabitIcon, selectedHabitId } =
    dialogState

  const {
    setIsAddHabitDialogOpen,
    setIsCreatingHabit,
    resetHabitForm,
    setActiveTab,
    setNewHabitName,
    setNewHabitDescription,
    setNewHabitDifficulty,
    setNewHabitIcon,
    setSelectedHabitId,
    openAddHabitDialog,
  } = dialogStateActions

  const completeHabit = (habitId: string) => {
    completeHabitContext(habitId)
    toast.success("Habit completed!")
  }

  const handleCreateHabit = async () => {
    if (!newHabitName.trim() || !newHabitDescription.trim()) {
      toast.error("Please provide both a name and description")
      return
    }

    if (!price) {
      toast.error("Price not found")
      return
    }

    setIsCreatingHabit(true)
    try {
      // Calculate points based on difficulty
      const points = newHabitDifficulty === "easy" ? 5 : newHabitDifficulty === "medium" ? 10 : 15 // hard

      // Create new habit
      const habitId = await addHabit({
        name: newHabitName,
        description: newHabitDescription,
        difficulty: newHabitDifficulty,
        points,
        completed: false,
        priceIds: [price.id],
        completionFrequency: "daily",
        icon: newHabitIcon || undefined,
      })

      if (habitId) {
        // Link habit to price
        await linkPriceToHabit(price.id, habitId)

        setIsAddHabitDialogOpen(false)
        resetHabitForm()
        toast.success("Habit created and linked to price successfully")
      } else {
        throw new Error("Failed to create habit")
      }
    } catch (error) {
      console.error("Error creating habit:", error)
      toast.error("Failed to create habit. Please try again.")
    } finally {
      setIsCreatingHabit(false)
    }
  }

  const handleLinkExistingHabit = async () => {
    if (!selectedHabitId || !price) {
      toast.error("Please select a habit")
      return
    }

    setIsCreatingHabit(true)
    try {
      const success = await linkPriceToHabit(price.id, selectedHabitId)

      if (success) {
        setIsAddHabitDialogOpen(false)
        setSelectedHabitId("")
        toast.success("Habit linked to price successfully")
      } else {
        throw new Error("Failed to link habit to price")
      }
    } catch (error) {
      console.error("Error linking habit:", error)
      toast.error("Failed to link habit. Please try again.")
    } finally {
      setIsCreatingHabit(false)
    }
  }

  const handleSubmit = () => {
    if (activeTab === "existing") {
      handleLinkExistingHabit()
    } else {
      handleCreateHabit()
    }
  }

  const handlers: PriceDetailHandlers = {
    completeHabit,
    openAddHabitDialog,
    handleCreateHabit,
    handleLinkExistingHabit,
    handleSubmit,
    setIsAddHabitDialogOpen,
    setActiveTab,
    setNewHabitName,
    setNewHabitDescription,
    setNewHabitDifficulty,
    setNewHabitIcon,
    setSelectedHabitId,
    renderNotFound,
  }

  return handlers
}

