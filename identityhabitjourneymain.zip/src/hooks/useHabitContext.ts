"use client"

import type { HabitContextType } from "@/contexts/types"
import { useContext } from "react"
import { HabitContext } from "@/contexts/HabitContext"

/**
 * Custom hook to use the Habit context
 */
export const useHabitContext = (): HabitContextType => {
  const context = useContext(HabitContext)

  if (context === undefined) {
    throw new Error("useHabitContext must be used within a HabitProvider")
  }

  return context
}

// Alias for useHabitContext for more concise naming
export const useHabit = useHabitContext

