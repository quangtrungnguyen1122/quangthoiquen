export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export type Database = {
  public: {
    Tables: {
      habit_completions: {
        Row: {
          completed: boolean
          completed_date: string
          created_at: string
          habit_id: string
          id: string
          identity_id: string | null
          user_id: string
        }
        Insert: {
          completed?: boolean
          completed_date: string
          created_at?: string
          habit_id: string
          id?: string
          identity_id?: string | null
          user_id: string
        }
        Update: {
          completed?: boolean
          completed_date?: string
          created_at?: string
          habit_id?: string
          id?: string
          identity_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "habit_completions_habit_id_fkey"
            columns: ["habit_id"]
            isOneToOne: false
            referencedRelation: "habits"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "habit_completions_identity_id_fkey"
            columns: ["identity_id"]
            isOneToOne: false
            referencedRelation: "identities"
            referencedColumns: ["id"]
          },
        ]
      }
      habit_prices: {
        Row: {
          habit_id: string
          price_id: string
        }
        Insert: {
          habit_id: string
          price_id: string
        }
        Update: {
          habit_id?: string
          price_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "habit_prices_habit_id_fkey"
            columns: ["habit_id"]
            isOneToOne: false
            referencedRelation: "habits"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "habit_prices_price_id_fkey"
            columns: ["price_id"]
            isOneToOne: false
            referencedRelation: "prices"
            referencedColumns: ["id"]
          },
        ]
      }
      habits: {
        Row: {
          completed: boolean | null
          completion_frequency: string | null
          created_at: string | null
          description: string
          difficulty: string | null
          icon: string | null
          id: string
          name: string
          points: number | null
          user_id: string | null
        }
        Insert: {
          completed?: boolean | null
          completion_frequency?: string | null
          created_at?: string | null
          description: string
          difficulty?: string | null
          icon?: string | null
          id?: string
          name: string
          points?: number | null
          user_id?: string | null
        }
        Update: {
          completed?: boolean | null
          completion_frequency?: string | null
          created_at?: string | null
          description?: string
          difficulty?: string | null
          icon?: string | null
          id?: string
          name?: string
          points?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "habits_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      identities: {
        Row: {
          avatar: string | null
          created_at: string | null
          description: string
          highest_streak: number | null
          id: string
          name: string
          progress: number | null
          streak: number | null
          user_id: string | null
        }
        Insert: {
          avatar?: string | null
          created_at?: string | null
          description: string
          highest_streak?: number | null
          id?: string
          name: string
          progress?: number | null
          streak?: number | null
          user_id?: string | null
        }
        Update: {
          avatar?: string | null
          created_at?: string | null
          description?: string
          highest_streak?: number | null
          id?: string
          name?: string
          progress?: number | null
          streak?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "identities_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      identity_prices: {
        Row: {
          identity_id: string
          price_id: string
        }
        Insert: {
          identity_id: string
          price_id: string
        }
        Update: {
          identity_id?: string
          price_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "identity_prices_identity_id_fkey"
            columns: ["identity_id"]
            isOneToOne: false
            referencedRelation: "identities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "identity_prices_price_id_fkey"
            columns: ["price_id"]
            isOneToOne: false
            referencedRelation: "prices"
            referencedColumns: ["id"]
          },
        ]
      }
      identity_streaks: {
        Row: {
          identity_id: string
          streak: number | null
          user_id: string
        }
        Insert: {
          identity_id: string
          streak?: number | null
          user_id: string
        }
        Update: {
          identity_id?: string
          streak?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "identity_streaks_identity_id_fkey"
            columns: ["identity_id"]
            isOneToOne: false
            referencedRelation: "identities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "identity_streaks_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      prices: {
        Row: {
          completion_percentage: number | null
          created_at: string | null
          description: string
          icon: string | null
          id: string
          name: string
          user_id: string | null
        }
        Insert: {
          completion_percentage?: number | null
          created_at?: string | null
          description: string
          icon?: string | null
          id?: string
          name: string
          user_id?: string | null
        }
        Update: {
          completion_percentage?: number | null
          created_at?: string | null
          description?: string
          icon?: string | null
          id?: string
          name?: string
          user_id?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar: string | null
          id: string
          joined_date: string | null
          last_30_days_points: number | null
          last_7_days_points: number | null
          position: number | null
          total_points: number | null
          username: string
        }
        Insert: {
          avatar?: string | null
          id: string
          joined_date?: string | null
          last_30_days_points?: number | null
          last_7_days_points?: number | null
          position?: number | null
          total_points?: number | null
          username: string
        }
        Update: {
          avatar?: string | null
          id?: string
          joined_date?: string | null
          last_30_days_points?: number | null
          last_7_days_points?: number | null
          position?: number | null
          total_points?: number | null
          username?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      remove_habit_price_relationship: {
        Args: {
          p_habit_id: string
          p_price_id: string
        }
        Returns: boolean
      }
      remove_identity_price_relationship: {
        Args: {
          p_identity_id: string
          p_price_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type PublicSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] & PublicSchema["Views"]) | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    ? (PublicSchema["Tables"] & PublicSchema["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends keyof PublicSchema["Tables"] | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends keyof PublicSchema["Tables"] | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends keyof PublicSchema["Enums"] | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
    ? PublicSchema["Enums"][PublicEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"] | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
    ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

