import { createRoot } from "react-dom/client"
import App from "./App.tsx"
import "./index.css"

// Add error boundary for debugging
try {
  const rootElement = document.getElementById("root")
  if (!rootElement) {
    console.error("Root element not found!")
    throw new Error("Root element not found")
  }

  createRoot(rootElement).render(<App />)
} catch (error) {
  console.error("Error rendering application:", error)
  // Display error to user
  const rootElement = document.getElementById("root")
  if (rootElement) {
    rootElement.innerHTML = `
      <div style="padding: 20px; text-align: center;">
        <h2>Application Error</h2>
        <p>Sorry, there was a problem loading the application. Please try refreshing the page.</p>
        <pre style="background: #f5f5f5; padding: 10px; text-align: left; overflow: auto;">${error instanceof Error ? error.message : String(error)}</pre>
      </div>
    `
  }
}

