"use client"

import { useState, useEffect } from "react"
import { Link, useNavigate, useLocation } from "react-router-dom"
import { ArrowLeft, Loader2 } from "lucide-react"
import GlassCard from "@/components/ui-custom/GlassCard"
import PageTransition from "@/components/layout/PageTransition"
import AuthForm from "@/components/auth/AuthForm"
import AuthHeader from "@/components/auth/AuthHeader"
import { useSessionCheck } from "@/hooks/auth/useSessionCheck"
import { supabase } from "@/integrations/supabase/client"

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true)
  const { isCheckingSession } = useSessionCheck()
  const navigate = useNavigate()
  const location = useLocation()

  // Check if user is already logged in
  useEffect(() => {
    const checkSession = async () => {
      const { data } = await supabase.auth.getSession()
      if (data.session) {
        // Redirect to the page they were trying to access, or to the dashboard
        const from = location.state?.from?.pathname || "/"
        navigate(from, { replace: true })
      }
    }

    checkSession()
  }, [navigate, location])

  const toggleAuthMode = () => setIsLogin(!isLogin)

  if (isCheckingSession) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Đang kiểm tra phiên đăng nhập...</span>
      </div>
    )
  }

  return (
    <PageTransition>
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <Link
          to="/"
          className="absolute top-8 left-8 inline-flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors duration-200"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Quay lại trang chủ</span>
        </Link>

        <GlassCard className="max-w-md w-full p-8">
          <AuthHeader isLogin={isLogin} />
          <AuthForm isLogin={isLogin} onToggleMode={toggleAuthMode} />
        </GlassCard>
      </div>
    </PageTransition>
  )
}

export default Auth

