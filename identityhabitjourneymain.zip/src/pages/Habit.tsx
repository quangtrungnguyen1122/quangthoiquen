"use client"
import { useNavigate } from "react-router-dom"
import { useHabit } from "@/contexts/HabitContext"
import PageTransition from "@/components/layout/PageTransition"
import Navbar from "@/components/layout/Navbar"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Target, Check, ArrowLeft } from "lucide-react"
import { cn } from "@/lib/utils"

const Habit = () => {
  const navigate = useNavigate()
  const { habits, completeHabit, isLoading } = useHabit()

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <PageTransition>
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center gap-2 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/")} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold">My Habits</h1>
        </div>

        <div className="space-y-4 mb-6">
          {habits.length > 0 ? (
            habits.map((habit) => (
              <Card key={habit.id} className="group hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => !habit.completed && completeHabit(habit.id)}
                      disabled={habit.completed}
                      className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
                        habit.completed ? "bg-primary/20" : "bg-muted cursor-pointer hover:bg-primary/10",
                      )}
                    >
                      {habit.completed ? (
                        <Check className="w-5 h-5 text-primary" />
                      ) : (
                        <Target className="w-5 h-5 text-muted-foreground" />
                      )}
                    </button>
                    <div>
                      <div className="font-medium">{habit.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {habit.difficulty} · {habit.points} points
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate(`/habit/${habit.id}`)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-10">
              <p className="text-muted-foreground mb-4">You haven't created any habits yet.</p>
              <Button onClick={() => navigate("/")}>Return to Dashboard</Button>
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  )
}

export default Habit

