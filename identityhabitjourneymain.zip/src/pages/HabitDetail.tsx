import Navbar from "@/components/layout/Navbar"
import PageTransition from "@/components/layout/PageTransition"
import { useHabitDetailPage } from "@/hooks/habit/useHabitDetailPage"
import HabitContent from "@/components/habit/HabitContent"

const HabitDetail = () => {
  const { habit, relatedPrices, dialogState, onUnlinkPrice, renderNotFound } = useHabitDetailPage()

  // If habit not found, show the not found component
  if (!habit) {
    return renderNotFound()
  }

  return (
    <>
      <Navbar />

      <PageTransition>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-20">
          <HabitContent
            habit={habit}
            relatedPrices={relatedPrices}
            dialogState={dialogState}
            onUnlinkPrice={onUnlinkPrice}
          />
        </div>
      </PageTransition>
    </>
  )
}

export default HabitDetail

