import { memo } from "react"
import { Layout } from "@/components/layout"
import { useHabit } from "@/contexts/HabitContext"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "lucide-react"
import { MonthNavigation } from "@/components/habit-history/MonthNavigation"
import { HabitHistoryTable } from "@/components/habit-history/HabitHistoryTable"
import { useHabitHistory } from "@/hooks/habit-history/useHabitHistory"

// Use memo to prevent unnecessary re-renders of the entire page
const HabitHistory = memo(() => {
  const { habits } = useHabit()
  const {
    currentMonth,
    daysInMonth,
    completionsByHabit,
    isCurrentMonth,
    isLoading,
    goToPreviousMonth,
    goToNextMonth,
    handleCompletionToggle,
  } = useHabitHistory()

  return (
    <Layout>
      <div className="container mx-auto py-8">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="text-2xl font-bold flex items-center gap-2">
                <Calendar className="h-6 w-6" />
                Habit History
              </CardTitle>

              <MonthNavigation
                currentMonth={currentMonth}
                isCurrentMonth={isCurrentMonth}
                onPreviousMonth={goToPreviousMonth}
                onNextMonth={goToNextMonth}
              />
            </div>
          </CardHeader>
          <CardContent>
            <HabitHistoryTable
              habits={habits}
              daysInMonth={daysInMonth}
              completionsByHabit={completionsByHabit}
              onToggleCompletion={handleCompletionToggle}
              isLoading={isLoading}
            />
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
})

HabitHistory.displayName = "HabitHistory"

export default HabitHistory

