"use client"

import { useState } from "react"
import { useHabitContext } from "@/contexts/HabitContext"
import type { Habit, Identity } from "@/contexts/types"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Layout } from "@/components/layout"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"
import { HabitCard, HabitForm, DeleteHabitDialog } from "@/components/habit"
import type { HabitFormValues } from "@/components/habit/HabitForm"

const HabitsPage = () => {
  const { habits, prices, identities, addHabit, updateHabit, deleteHabit, getPricesByHabitId, getIdentitiesByPriceId } =
    useHabitContext()
  const [openAddDialog, setOpenAddDialog] = useState(false)
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null)
  const [currentTab, setCurrentTab] = useState<"all" | "used" | "unused">("all")
  const [habitToDelete, setHabitToDelete] = useState<Habit | null>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const filteredHabits = habits.filter((habit) => {
    const linkedPrices = getPricesByHabitId(habit.id)
    const isUsed = linkedPrices.length > 0
    if (currentTab === "all") return true
    if (currentTab === "used") return isUsed
    return !isUsed // unused
  })

  const getLinkedPrices = (habitId: string) => {
    return getPricesByHabitId(habitId)
  }

  const getLinkedIdentities = (habitId: string) => {
    const linkedPrices = getPricesByHabitId(habitId)

    const uniqueIdentityIds = new Set<string>()

    linkedPrices.forEach((price) => {
      const priceIdentities = getIdentitiesByPriceId(price.id)
      priceIdentities.forEach((identity) => {
        uniqueIdentityIds.add(identity.id)
      })
    })

    return Array.from(uniqueIdentityIds)
      .map((id) => identities.find((identity) => identity.id === id))
      .filter((identity): identity is Identity => identity !== undefined)
  }

  const onSubmit = async (values: HabitFormValues) => {
    setIsSubmitting(true)
    try {
      if (editingHabit) {
        await updateHabit(editingHabit.id, values)
        toast.success("Habit updated successfully")
      } else {
        const completedHabitData = {
          name: values.name,
          description: values.description,
          difficulty: values.difficulty,
          completionFrequency: values.completionFrequency,
          points: values.points,
          completed: false,
          priceIds: [],
        } as Omit<Habit, "id">

        const newHabitId = await addHabit(completedHabitData)
        if (newHabitId) {
          toast.success("Habit added successfully")
        }
      }
      setOpenAddDialog(false)
      setEditingHabit(null)
    } catch (error) {
      console.error("Error saving habit:", error)
      toast.error("Failed to save habit")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleEdit = (habit: Habit) => {
    setEditingHabit(habit)
    setOpenAddDialog(true)
  }

  const handleDelete = (habit: Habit) => {
    setHabitToDelete(habit)
    setIsDeleteDialogOpen(true)
  }

  const confirmDelete = async () => {
    if (!habitToDelete) return

    setIsDeleting(true)
    try {
      const success = await deleteHabit(habitToDelete.id)
      if (success) {
        toast.success("Habit deleted successfully")
      } else {
        toast.error("Failed to delete habit")
      }
    } catch (error) {
      console.error("Error deleting habit:", error)
      toast.error("Failed to delete habit")
    } finally {
      setIsDeleting(false)
      setIsDeleteDialogOpen(false)
      setHabitToDelete(null)
    }
  }

  const isHabitInUse = (habit: Habit) => {
    return habit.priceIds.length > 0
  }

  return (
    <Layout>
      <div className="container py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Habits</h1>
          <Button onClick={() => setOpenAddDialog(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add Habit
          </Button>
        </div>

        <Tabs value={currentTab} onValueChange={(value) => setCurrentTab(value as any)}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Habits</TabsTrigger>
            <TabsTrigger value="used">Used in Prices</TabsTrigger>
            <TabsTrigger value="unused">Unused</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredHabits.map((habit) => (
                <HabitCard
                  key={habit.id}
                  habit={habit}
                  linkedPrices={getLinkedPrices(habit.id)}
                  linkedIdentities={getLinkedIdentities(habit.id)}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="used" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredHabits.map((habit) => (
                <HabitCard
                  key={habit.id}
                  habit={habit}
                  linkedPrices={getLinkedPrices(habit.id)}
                  linkedIdentities={getLinkedIdentities(habit.id)}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="unused" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredHabits.map((habit) => (
                <HabitCard
                  key={habit.id}
                  habit={habit}
                  linkedPrices={getLinkedPrices(habit.id)}
                  linkedIdentities={getLinkedIdentities(habit.id)}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <HabitForm
          open={openAddDialog}
          onOpenChange={setOpenAddDialog}
          onSubmit={onSubmit}
          editingHabit={editingHabit}
          isSubmitting={isSubmitting}
        />

        <DeleteHabitDialog
          open={isDeleteDialogOpen}
          onOpenChange={setIsDeleteDialogOpen}
          habitToDelete={habitToDelete}
          onConfirm={confirmDelete}
          isDeleting={isDeleting}
          isHabitInUse={isHabitInUse}
        />
      </div>
    </Layout>
  )
}

export default HabitsPage

