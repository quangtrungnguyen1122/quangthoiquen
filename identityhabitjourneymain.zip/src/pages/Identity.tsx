"use client"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useHabit } from "@/contexts/HabitContext"
import type { Identity } from "@/contexts/types"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Layout } from "@/components/layout"
import { Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"
import { IdentityCard } from "@/components/identity/list/IdentityCard"
import { IdentityFormDialog } from "@/components/identity/list/IdentityFormDialog"
import { DeleteIdentityDialog } from "@/components/identity/list/DeleteIdentityDialog"

const IdentityPage = () => {
  const navigate = useNavigate()
  const { identities, addIdentity, updateIdentity, deleteIdentity, getPricesByIdentityId } = useHabit()
  const [openAddDialog, setOpenAddDialog] = useState(false)
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false)
  const [editingIdentity, setEditingIdentity] = useState<Identity | null>(null)
  const [identityToDelete, setIdentityToDelete] = useState<Identity | null>(null)
  const [currentTab, setCurrentTab] = useState<"all" | "used" | "unused">("all")

  const filteredIdentities = identities.filter((identity) => {
    const isUsed = identity.priceIds.length > 0
    if (currentTab === "all") return true
    if (currentTab === "used") return isUsed
    return !isUsed // unused
  })

  const isIdentityInUse = (identity: Identity) => {
    return identity.priceIds.length > 0
  }

  const getLinkedPrices = (identityId: string) => {
    return getPricesByIdentityId(identityId)
  }

  const onSubmit = async (values: any) => {
    try {
      if (editingIdentity) {
        const updated = await updateIdentity(editingIdentity.id, {
          name: values.name,
          description: values.description,
          avatar: values.avatar || undefined,
        })

        if (updated) {
          toast.success("Identity updated successfully")
        }
      } else {
        const completeIdentityData = {
          name: values.name,
          description: values.description,
          avatar: values.avatar || undefined,
          streak: 0,
          highestStreak: 0,
          progress: 0,
          priceIds: [],
        }

        const newIdentityId = await addIdentity(completeIdentityData)
        if (newIdentityId) {
          toast.success("Identity added successfully")
        }
      }
      setOpenAddDialog(false)
      setEditingIdentity(null)
    } catch (error) {
      console.error("Error saving identity:", error)
      toast.error("Failed to save identity")
    }
  }

  const handleEdit = (identity: Identity) => {
    setEditingIdentity(identity)
    setOpenAddDialog(true)
  }

  const handleDeleteClick = (identity: Identity) => {
    setIdentityToDelete(identity)
    setOpenDeleteDialog(true)
  }

  const handleDeleteConfirm = async () => {
    if (identityToDelete) {
      try {
        const deleted = await deleteIdentity(identityToDelete.id)
        if (deleted) {
          toast.success("Identity deleted successfully")
        }
      } catch (error) {
        console.error("Error deleting identity:", error)
        toast.error("Failed to delete identity")
      }
    }
    setOpenDeleteDialog(false)
    setIdentityToDelete(null)
  }

  const handleViewDetails = (identityId: string) => {
    navigate(`/identity/${identityId}`)
  }

  return (
    <Layout>
      <div className="container py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Identities</h1>
          <Button onClick={() => setOpenAddDialog(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add Identity
          </Button>
        </div>

        <Tabs value={currentTab} onValueChange={(value) => setCurrentTab(value as any)}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Identities</TabsTrigger>
            <TabsTrigger value="used">With Prices</TabsTrigger>
            <TabsTrigger value="unused">No Prices</TabsTrigger>
          </TabsList>

          {["all", "used", "unused"].map((tab) => (
            <TabsContent key={tab} value={tab} className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredIdentities.map((identity) => (
                  <IdentityCard
                    key={identity.id}
                    identity={identity}
                    linkedPrices={getLinkedPrices(identity.id)}
                    onEdit={handleEdit}
                    onDelete={handleDeleteClick}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <IdentityFormDialog
          open={openAddDialog}
          onOpenChange={setOpenAddDialog}
          onSubmit={onSubmit}
          editingIdentity={editingIdentity}
        />

        <DeleteIdentityDialog
          open={openDeleteDialog}
          onOpenChange={setOpenDeleteDialog}
          identityToDelete={identityToDelete}
          onConfirm={handleDeleteConfirm}
          isIdentityInUse={isIdentityInUse}
        />
      </div>
    </Layout>
  )
}

export default IdentityPage

