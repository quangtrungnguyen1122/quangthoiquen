import Navbar from "@/components/layout/Navbar"
import PageTransition from "@/components/layout/PageTransition"
import { useIdentityDetailPage } from "@/hooks/identity/useIdentityDetailPage"
import IdentityContent from "@/components/identity/IdentityContent"

const IdentityDetail = () => {
  const { identity, relatedPrices, dialogState, handlers } = useIdentityDetailPage()

  // If identity not found, show the not found component
  if (!identity) {
    return handlers.renderNotFound()
  }

  return (
    <>
      <Navbar />

      <PageTransition>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-20">
          <IdentityContent
            identity={identity}
            relatedPrices={relatedPrices}
            dialogState={dialogState}
            handlers={handlers}
          />
        </div>
      </PageTransition>
    </>
  )
}

export default IdentityDetail

