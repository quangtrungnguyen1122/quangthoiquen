"use client"
import { motion } from "framer-motion"
import { Calendar, Target, Plus } from "lucide-react"
import { Link } from "react-router-dom"
import { cn } from "@/lib/utils"
import Navbar from "@/components/layout/Navbar"
import PageTransition from "@/components/layout/PageTransition"
import { IdentityCard } from "@/components/dashboard/identity-card"
import { useHabitContext } from "@/contexts/HabitContext"
import { formatDate } from "@/utils/habitUtils"

const Index = () => {
  const { identities, currentUser } = useHabitContext()

  return (
    <>
      <Navbar />

      <PageTransition>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-20">
          <div className="my-8">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="text-left"
            >
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                <Calendar className="w-4 h-4" />
                <span>{formatDate(new Date())}</span>
              </div>
              <h1 className="text-3xl font-bold tracking-tight">
                Welcome back, {currentUser?.username?.split(" ")[0] || "User"}
              </h1>
              <p className="text-muted-foreground mt-2 max-w-2xl">
                Continue building your identity through consistent habits. You've earned{" "}
                {currentUser?.last7DaysPoints || 0} points this week.
              </p>
            </motion.div>
          </div>

          <div className="mb-10">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                <span>Your Identities</span>
              </h2>
              <Link
                to="/identity"
                className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200 flex items-center gap-1"
              >
                <span>View all</span>
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {identities.map((identity, index) => (
                <IdentityCard
                  key={identity.id}
                  id={identity.id}
                  name={identity.name}
                  description={identity.description}
                  progress={identity.progress}
                  streak={identity.streak}
                  highestStreak={identity.highestStreak}
                  image={identity.avatar}
                  delay={index}
                />
              ))}

              <Link to="/identity/new">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: identities.length * 0.1 }}
                  className={cn(
                    "min-h-[240px] flex flex-col items-center justify-center",
                    "rounded-2xl border-2 border-dashed border-border p-6",
                    "hover:border-muted-foreground/50 transition-colors duration-200 cursor-pointer",
                  )}
                >
                  <div className="w-12 h-12 rounded-full flex items-center justify-center bg-muted">
                    <Plus className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <p className="mt-4 font-medium">Create New Identity</p>
                  <p className="text-sm text-muted-foreground text-center mt-2">Define who you want to become</p>
                </motion.div>
              </Link>
            </div>
          </div>
        </div>
      </PageTransition>
    </>
  )
}

export default Index

