"use client"

import { useState, useMemo } from "react"
import { useHabit } from "@/contexts/HabitContext"
import PageTransition from "@/components/layout/PageTransition"
import Navbar from "@/components/layout/Navbar"
import { Trophy } from "lucide-react"
import { LeaderboardTabs } from "@/components/leaderboard/LeaderboardTabs"
import { UserRankCard } from "@/components/leaderboard/UserRankCard"
import { SearchInput } from "@/components/leaderboard/SearchInput"
import { getRankedUsers, getCurrentUserRank } from "@/components/leaderboard/leaderboardUtils"

const Leaderboard = () => {
  const [activeTab, setActiveTab] = useState("7-days")
  const [searchQuery, setSearchQuery] = useState("")
  const { leaderboardUsers, currentUser, identities } = useHabit()

  // Calculate ranks based on active tab and sort by streak first, then points
  const rankedUsers = getRankedUsers(leaderboardUsers, identities, activeTab, currentUser?.id)

  // Filter users based on search query
  const filteredUsers = useMemo(() => {
    if (!searchQuery.trim()) return rankedUsers

    return rankedUsers.filter((user) => user.username.toLowerCase().includes(searchQuery.toLowerCase()))
  }, [rankedUsers, searchQuery])

  // Get the current user's rank
  const currentUserRank = getCurrentUserRank(rankedUsers, currentUser?.id)

  return (
    <PageTransition>
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <h1 className="text-3xl font-bold flex items-center gap-2 mb-8">
          <Trophy className="h-8 w-8 text-primary" />
          Leaderboard
        </h1>

        {currentUserRank && (
          <UserRankCard
            user={currentUserRank}
            timeframe={activeTab as "all-time" | "30-days" | "7-days"}
            identities={identities}
          />
        )}

        <SearchInput searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

        <LeaderboardTabs
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          rankedUsers={filteredUsers}
          identities={identities}
        />
      </div>
    </PageTransition>
  )
}

export default Leaderboard

