"use client"

import type React from "react"
import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useHabit } from "@/contexts/HabitContext"
import PageTransition from "@/components/layout/PageTransition"
import Navbar from "@/components/layout/Navbar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Loader2 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"

const NewIdentity = () => {
  const navigate = useNavigate()
  const { addIdentity } = useHabit()

  const [isCreating, setIsCreating] = useState(false)
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [avatar, setAvatar] = useState("")

  const handleCreateIdentity = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || !description) return

    setIsCreating(true)

    try {
      const newIdentityId = await addIdentity({
        name,
        description,
        avatar: avatar || undefined,
        streak: 0,
        highestStreak: 0,
        progress: 0,
        priceIds: [],
      })

      if (newIdentityId) {
        // Navigate to the new identity detail page
        navigate(`/identity/${newIdentityId}`)
      }
    } catch (error) {
      console.error("Error creating identity:", error)
    } finally {
      setIsCreating(false)
    }
  }

  return (
    <PageTransition>
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="flex items-center gap-2 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/identity")} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold">Create New Identity</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>New Identity Details</CardTitle>
            <CardDescription>
              Define who you want to become. Your identity will guide your habits and rewards.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateIdentity} className="space-y-6">
              <div className="grid gap-2">
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="E.g. Fitness Enthusiast, Book Lover..."
                  required
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe this identity and what it means to you..."
                  rows={4}
                  required
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="avatar">Avatar URL (optional)</Label>
                <Input
                  id="avatar"
                  value={avatar}
                  onChange={(e) => setAvatar(e.target.value)}
                  placeholder="Enter an image URL for this identity"
                />
                {avatar && (
                  <div className="mt-2 flex justify-center">
                    <img
                      src={avatar}
                      alt="Avatar preview"
                      className="w-20 h-20 rounded-full object-cover border-2 border-border"
                      onError={(e) => {
                        e.currentTarget.src = "/placeholder.svg"
                      }}
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => navigate("/identity")} disabled={isCreating}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isCreating || !name || !description}>
                  {isCreating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating Identity...
                    </>
                  ) : (
                    "Create Identity"
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </PageTransition>
  )
}

export default NewIdentity

