import { Link } from "react-router-dom"
import { Loader2 } from "lucide-react"
import Navbar from "@/components/layout/Navbar"
import PageTransition from "@/components/layout/PageTransition"
import PriceContent from "@/components/price/PriceContent"
import { usePriceDetailPage } from "@/hooks/price/usePriceDetailPage"

const PriceDetail = () => {
  const { price, relatedHabits, relatedIdentities, availableHabits, isLoading, dialogState, handlers } =
    usePriceDetailPage()

  // If loading
  if (isLoading) {
    return (
      <>
        <Navbar />
        <PageTransition>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 flex justify-center items-center">
            <Loader2 className="w-10 h-10 text-primary animate-spin" />
          </div>
        </PageTransition>
      </>
    )
  }

  // If price not found
  if (!price) {
    return (
      <>
        <Navbar />
        <PageTransition>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
            <div className="text-center">
              <h1 className="text-2xl font-bold mb-4">Price not found</h1>
              <Link to="/" className="text-primary hover:underline">
                Back to Dashboard
              </Link>
            </div>
          </div>
        </PageTransition>
      </>
    )
  }

  return (
    <>
      <Navbar />

      <PageTransition>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-20">
          <PriceContent
            price={price}
            relatedHabits={relatedHabits}
            relatedIdentities={relatedIdentities}
            availableHabits={availableHabits}
            dialogState={dialogState}
            handlers={handlers}
          />
        </div>
      </PageTransition>
    </>
  )
}

export default PriceDetail

