"use client"
import { useNavigate } from "react-router-dom"
import { useHabit } from "@/contexts/HabitContext"
import PageTransition from "@/components/layout/PageTransition"
import Navbar from "@/components/layout/Navbar"
import ProgressRing from "@/components/dashboard/ProgressRing"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

const Prices = () => {
  const navigate = useNavigate()
  const { prices, isLoading } = useHabit()

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    )
  }

  return (
    <PageTransition>
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center gap-2 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/")} className="mr-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold">My Prices</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {prices.length > 0 ? (
            prices.map((price) => (
              <Card
                key={price.id}
                className="group cursor-pointer hover:shadow-md transition-shadow duration-200"
                onClick={() => navigate(`/price/${price.id}`)}
              >
                <CardContent className="p-6 flex items-center gap-4">
                  <div className="flex-shrink-0">
                    <ProgressRing progress={price.completionPercentage || 0} size={50} strokeWidth={4} />
                  </div>
                  <div className="flex-1">
                    <h2 className="font-semibold text-lg group-hover:text-primary transition-colors">{price.name}</h2>
                    <p className="text-sm text-muted-foreground line-clamp-1">{price.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-2 text-center py-10">
              <p className="text-muted-foreground mb-4">You haven't created any prices yet.</p>
              <Button onClick={() => navigate("/")}>Return to Dashboard</Button>
            </div>
          )}
        </div>
      </div>
    </PageTransition>
  )
}

export default Prices

