"use client"

import type React from "react"
import { useState } from "react"
import { useHabitContext } from "@/contexts/HabitContext"
import type { Price } from "@/contexts/types"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Layout } from "@/components/layout"
import { Check, Plus, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { toast } from "sonner"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

// Form schema for adding/editing prices
const priceFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
})

type PriceFormValues = z.infer<typeof priceFormSchema>

const PricesPage = () => {
  const { prices, addPrice, updatePrice, deletePrice, getIdentitiesByPriceId, getHabitsByPriceId } = useHabitContext()
  const [openAddDialog, setOpenAddDialog] = useState(false)
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false)
  const [editingPrice, setEditingPrice] = useState<Price | null>(null)
  const [priceToDelete, setPriceToDelete] = useState<Price | null>(null)
  const [currentTab, setCurrentTab] = useState<"all" | "used" | "unused">("all")

  // Form setup
  const form = useForm<PriceFormValues>({
    resolver: zodResolver(priceFormSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  })

  // Filter prices based on selected tab
  const filteredPrices = prices.filter((price) => {
    const isUsed = price.identityIds.length > 0
    if (currentTab === "all") return true
    if (currentTab === "used") return isUsed
    return !isUsed // unused
  })

  // Check if a price is being used in any identity
  const isPriceInUse = (price: Price) => {
    return price.identityIds.length > 0
  }

  // Get linked identities for a price
  const getLinkedIdentities = (priceId: string) => {
    return getIdentitiesByPriceId(priceId)
  }

  // Get linked habits for a price
  const getLinkedHabits = (priceId: string) => {
    return getHabitsByPriceId(priceId)
  }

  // Handle add/edit form submission
  const onSubmit = async (values: PriceFormValues) => {
    try {
      if (editingPrice) {
        // Update existing price
        const updated = await updatePrice(editingPrice.id, values)
        if (updated) {
          toast.success("Price updated successfully")
        }
      } else {
        // Add new price - Fix: Adding the missing properties
        const completePriceData = {
          name: values.name,
          description: values.description,
          habitIds: [],
          identityIds: [],
          completionPercentage: 0,
        }

        const newPriceId = await addPrice(completePriceData)
        if (newPriceId) {
          toast.success("Price added successfully")
        }
      }
      setOpenAddDialog(false)
      setEditingPrice(null)
      form.reset()
    } catch (error) {
      console.error("Error saving price:", error)
      toast.error("Failed to save price")
    }
  }

  // Open dialog for editing
  const handleEdit = (price: Price) => {
    setEditingPrice(price)
    form.reset({
      name: price.name,
      description: price.description,
    })
    setOpenAddDialog(true)
  }

  // Handle delete confirmation
  const handleDeleteClick = (price: Price) => {
    setPriceToDelete(price)
    setOpenDeleteDialog(true)
  }

  // Handle delete confirmation
  const handleDeleteConfirm = async () => {
    if (priceToDelete) {
      try {
        const deleted = await deletePrice(priceToDelete.id)
        if (deleted) {
          toast.success("Price deleted successfully")
        }
      } catch (error) {
        console.error("Error deleting price:", error)
        toast.error("Failed to delete price")
      }
    }
    setOpenDeleteDialog(false)
    setPriceToDelete(null)
  }

  // Close dialog and reset form
  const handleCloseDialog = () => {
    setOpenAddDialog(false)
    setEditingPrice(null)
    form.reset()
  }

  return (
    <Layout>
      <div className="container py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Prices</h1>
          <Button onClick={() => setOpenAddDialog(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add Price
          </Button>
        </div>

        <Tabs value={currentTab} onValueChange={(value) => setCurrentTab(value as any)}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Prices</TabsTrigger>
            <TabsTrigger value="used">Used in Identities</TabsTrigger>
            <TabsTrigger value="unused">Unused</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredPrices.map((price) => (
                <PriceCard
                  key={price.id}
                  price={price}
                  linkedIdentities={getLinkedIdentities(price.id)}
                  linkedHabits={getLinkedHabits(price.id)}
                  onEdit={handleEdit}
                  onDelete={handleDeleteClick}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="used" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredPrices.map((price) => (
                <PriceCard
                  key={price.id}
                  price={price}
                  linkedIdentities={getLinkedIdentities(price.id)}
                  linkedHabits={getLinkedHabits(price.id)}
                  onEdit={handleEdit}
                  onDelete={handleDeleteClick}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="unused" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredPrices.map((price) => (
                <PriceCard
                  key={price.id}
                  price={price}
                  linkedIdentities={getLinkedIdentities(price.id)}
                  linkedHabits={getLinkedHabits(price.id)}
                  onEdit={handleEdit}
                  onDelete={handleDeleteClick}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Add/Edit Price Dialog */}
        <Dialog open={openAddDialog} onOpenChange={setOpenAddDialog}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>{editingPrice ? "Edit Price" : "Add New Price"}</DialogTitle>
              <DialogDescription>
                {editingPrice ? "Update the price details below." : "Create a new price by filling out the form below."}
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Price name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Describe the price" {...field} className="resize-none" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button variant="outline" type="button" onClick={handleCloseDialog}>
                    Cancel
                  </Button>
                  <Button type="submit">{editingPrice ? "Save Changes" : "Add Price"}</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={openDeleteDialog} onOpenChange={setOpenDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete the price
                {priceToDelete ? ` "${priceToDelete.name}"` : ""}
                {priceToDelete && isPriceInUse(priceToDelete) ? " and remove it from all associated identities." : "."}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive text-destructive-foreground">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </Layout>
  )
}

// Price card component
interface PriceCardProps {
  price: Price
  linkedIdentities: any[]
  linkedHabits: any[]
  onEdit: (price: Price) => void
  onDelete: (price: Price) => void
}

const PriceCard: React.FC<PriceCardProps> = ({ price, linkedIdentities, linkedHabits, onEdit, onDelete }) => {
  const isUsed = linkedIdentities.length > 0

  return (
    <Card className={`overflow-hidden transition-all ${isUsed ? "border-primary/20" : ""}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{price.name}</CardTitle>
            <CardDescription className="text-sm line-clamp-1">{price.description}</CardDescription>
          </div>
          {isUsed && (
            <Badge variant="outline" className="border-primary text-primary">
              <Check className="h-3 w-3 mr-1" /> In Use
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        {isUsed && linkedIdentities.length > 0 && (
          <div className="mb-3">
            <p className="text-xs text-muted-foreground mb-1">Used in identities:</p>
            <div className="flex flex-wrap gap-1">
              {linkedIdentities.slice(0, 3).map((identity) => (
                <Badge key={identity.id} variant="outline" className="text-xs">
                  {identity.name}
                </Badge>
              ))}
              {linkedIdentities.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{linkedIdentities.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}

        {linkedHabits.length > 0 && (
          <div>
            <p className="text-xs text-muted-foreground mb-1">Habits:</p>
            <div className="flex flex-wrap gap-1">
              {linkedHabits.slice(0, 3).map((habit) => (
                <Badge key={habit.id} variant="secondary" className="text-xs">
                  {habit.name}
                </Badge>
              ))}
              {linkedHabits.length > 3 && (
                <Badge variant="secondary" className="text-xs">
                  +{linkedHabits.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="pt-2">
        <Button variant="ghost" size="sm" className="mr-2" onClick={() => onEdit(price)}>
          <Edit className="h-4 w-4 mr-1" />
          Edit
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="text-destructive hover:text-destructive/90 hover:bg-destructive/10"
          onClick={() => onDelete(price)}
        >
          <Trash2 className="h-4 w-4 mr-1" />
          Delete
        </Button>
      </CardFooter>
    </Card>
  )
}

export default PricesPage

