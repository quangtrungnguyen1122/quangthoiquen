import { Layout } from "@/components/layout"
import UserProfile from "@/components/user/UserProfile"

const User = () => {
  return (
    <Layout>
      <div className="container py-8">
        <UserProfile />
      </div>
    </Layout>
  )
}

export default User

