import { supabase } from "@/integrations/supabase/client"
import { format } from "date-fns"
import { toast } from "sonner"

// Track a habit completion
export const completeHabitApi = async (habitId: string, userId: string, points: number) => {
  try {
    // Update habit completion status
    const { error } = await supabase
      .from("habits")
      .update({
        completed: true,
        created_at: new Date().toISOString(), // Set the current time as completion time
      })
      .eq("id", habitId)

    if (error) {
      console.error("Error completing habit:", error)
      throw error
    }

    // Add a record to habit_completions table for today
    const todayFormatted = format(new Date(), "yyyy-MM-dd")

    // Check if there's already a completion record for this habit today
    const { data: existingCompletion, error: checkError } = await supabase
      .from("habit_completions")
      .select("*")
      .eq("habit_id", habitId)
      .eq("completed_date", todayFormatted)
      .single()

    if (checkError && checkError.code !== "PGRST116") {
      // PGRST116 means no rows returned
      console.error("Error checking habit completion:", checkError)
    }

    // If there's no existing completion, create one
    if (!existingCompletion) {
      const { error: insertError } = await supabase.from("habit_completions").insert({
        habit_id: habitId,
        user_id: userId,
        completed_date: todayFormatted,
        completed: true,
      })

      if (insertError) {
        console.error("Error recording habit completion:", insertError)
      }
    }

    // Update user points
    const { error: updateError } = await supabase.from("profiles").update({ total_points: points }).eq("id", userId)

    if (updateError) {
      console.error("Error updating points:", updateError)
      throw updateError
    }

    return true
  } catch (error) {
    console.error("Error in completeHabitApi:", error)
    toast.error("Failed to complete habit")
    throw error
  }
}

// Get latest completion date for a habit
export const getLatestCompletionDate = async (habitId: string): Promise<string | null> => {
  try {
    const { data, error } = await supabase
      .from("habit_completions")
      .select("completed_date")
      .eq("habit_id", habitId)
      .eq("completed", true)
      .order("completed_date", { ascending: false })
      .limit(1)
      .single()

    if (error && error.code !== "PGRST116") {
      console.error("Error fetching latest completion date:", error)
      return null
    }

    return data?.completed_date || null
  } catch (error) {
    console.error("Error in getLatestCompletionDate:", error)
    return null
  }
}

