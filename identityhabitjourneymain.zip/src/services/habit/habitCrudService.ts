import { supabase } from "@/integrations/supabase/client"
import type { Habit } from "@/contexts/types"

// Fetch habits service
export const fetchHabits = async (userId: string) => {
  const { data: habitsData, error: habitsError } = await supabase.from("habits").select("*").eq("user_id", userId)

  if (habitsError) {
    console.error("Error fetching habits:", habitsError)
    throw habitsError
  }

  return habitsData
}

export const addHabitApi = async (habit: Omit<Habit, "id">, userId: string) => {
  const habitData = {
    name: habit.name,
    description: habit.description,
    difficulty: habit.difficulty,
    completed: habit.completed || false,
    points: habit.points || 0,
    completion_frequency: habit.completionFrequency,
    icon: habit.icon,
    user_id: userId,
  }

  const { data, error } = await supabase.from("habits").insert([habitData]).select()

  if (error) {
    console.error("Error adding habit:", error)
    throw error
  }

  if (!data || !data[0]) {
    throw new Error("No data returned")
  }

  return data[0]
}

export const updateHabitApi = async (id: string, habitUpdate: Partial<Omit<Habit, "id">>) => {
  const updateData: any = {}

  if (habitUpdate.name !== undefined) updateData.name = habitUpdate.name
  if (habitUpdate.description !== undefined) updateData.description = habitUpdate.description
  if (habitUpdate.difficulty !== undefined) updateData.difficulty = habitUpdate.difficulty
  if (habitUpdate.completed !== undefined) updateData.completed = habitUpdate.completed
  if (habitUpdate.points !== undefined) updateData.points = habitUpdate.points
  if (habitUpdate.completionFrequency !== undefined) updateData.completion_frequency = habitUpdate.completionFrequency
  if (habitUpdate.icon !== undefined) updateData.icon = habitUpdate.icon

  const { error } = await supabase.from("habits").update(updateData).eq("id", id)

  if (error) {
    console.error("Error updating habit:", error)
    throw error
  }
}

export const deleteHabitApi = async (habitId: string) => {
  try {
    // First, remove any habit-price relationships
    const { error: relationError } = await supabase.from("habit_prices").delete().eq("habit_id", habitId)

    if (relationError) {
      console.error("Error removing habit-price relationships:", relationError)
      throw relationError
    }

    // Then delete the habit itself
    const { error } = await supabase.from("habits").delete().eq("id", habitId)

    if (error) {
      console.error("Error deleting habit:", error)
      throw error
    }

    return true
  } catch (error) {
    console.error("Exception in deleteHabitApi:", error)
    throw error
  }
}

