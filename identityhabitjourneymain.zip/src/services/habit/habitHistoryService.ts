import { supabase } from "@/integrations/supabase/client"
import { format } from "date-fns"
import type { HabitCompletionRecord } from "@/components/habit-history/types"
import { toast } from "sonner"

// Fetch habit completion history with caching to prevent duplicate requests
let lastFetchParams: string | null = null
let cachedRecords: HabitCompletionRecord[] | null = null
let fetchPromise: Promise<HabitCompletionRecord[]> | null = null

// Fetch habit completion records with better caching and deduplication
export const fetchHabitCompletionRecords = async (
  userId: string,
  startDate: string,
  endDate: string,
): Promise<HabitCompletionRecord[]> => {
  try {
    // Create a cache key based on the request parameters
    const cacheKey = `${userId}-${startDate}-${endDate}`

    // If we have a cached result for this exact query, return it
    if (lastFetchParams === cacheKey && cachedRecords) {
      console.log("Returning cached completion records")
      return cachedRecords
    }

    // If there's already a fetch in progress for the same parameters, return that promise
    if (lastFetchParams === cacheKey && fetchPromise) {
      console.log("Returning in-progress fetch promise")
      return fetchPromise
    }

    console.log("Fetching completions from", startDate, "to", endDate)

    // Create a new fetch promise
    fetchPromise = (async () => {
      const { data, error } = await supabase
        .from("habit_completions")
        .select("*")
        .eq("user_id", userId)
        .gte("completed_date", startDate)
        .lte("completed_date", endDate)

      if (error) {
        console.error("Error fetching habit completions:", error)
        throw error
      }

      console.log("Fetched completion records:", data?.length || 0)

      // Update the cache
      lastFetchParams = cacheKey
      cachedRecords = data || []

      return data || []
    })()

    // Wait for the fetch to complete and return the result
    const result = await fetchPromise
    fetchPromise = null
    return result
  } catch (error) {
    console.error("Error in fetchHabitCompletionRecords:", error)
    toast.error("Failed to load habit completion history")
    throw error
  }
}

// Toggle a habit completion status with optimistic updates
export const toggleHabitCompletionStatus = async (
  habitId: string,
  userId: string,
  date: Date,
  currentlyCompleted: boolean,
  identityId?: string,
): Promise<string> => {
  try {
    const formattedDate = format(date, "yyyy-MM-dd")

    // Check if there's an existing record
    const { data, error: checkError } = await supabase
      .from("habit_completions")
      .select("*")
      .eq("habit_id", habitId)
      .eq("completed_date", formattedDate)
      .maybeSingle()

    if (checkError) {
      console.error("Error checking habit completion:", checkError)
      throw checkError
    }

    // Invalidate cache when updating data
    lastFetchParams = null
    cachedRecords = null
    fetchPromise = null

    if (data) {
      // Update existing record
      const updateObj: any = { completed: !currentlyCompleted }

      // Only update identity_id if provided and it's not already set
      if (identityId && !data.identity_id) {
        updateObj.identity_id = identityId
      }

      const { error } = await supabase.from("habit_completions").update(updateObj).eq("id", data.id)

      if (error) {
        console.error("Error updating habit completion:", error)
        throw error
      }

      return data.id
    } else {
      // Create new record
      const newRecord: any = {
        habit_id: habitId,
        user_id: userId,
        completed_date: formattedDate,
        completed: !currentlyCompleted,
      }

      // Add identity_id if provided
      if (identityId) {
        newRecord.identity_id = identityId
      }

      const { data: newData, error } = await supabase.from("habit_completions").insert(newRecord).select().single()

      if (error) {
        console.error("Error creating habit completion:", error)
        throw error
      }

      return newData.id
    }
  } catch (error) {
    console.error("Error in toggleHabitCompletionStatus:", error)
    throw error
  }
}

// Fetch completions by identity
export const fetchCompletionsByIdentity = async (
  userId: string,
  identityId: string,
  startDate: string,
  endDate: string,
): Promise<HabitCompletionRecord[]> => {
  try {
    const { data, error } = await supabase
      .from("habit_completions")
      .select("*")
      .eq("user_id", userId)
      .eq("identity_id", identityId)
      .gte("completed_date", startDate)
      .lte("completed_date", endDate)

    if (error) {
      console.error("Error fetching completions by identity:", error)
      throw error
    }

    return data || []
  } catch (error) {
    console.error("Error in fetchCompletionsByIdentity:", error)
    throw error
  }
}

