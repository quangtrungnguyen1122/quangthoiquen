import type { Identity } from "@/contexts/types"
import { toast } from "sonner"
import { getToday } from "@/services/timeService"
import { toggleHabitCompletionStatus } from "./habitHistoryService"

// Calculate and update streak values for a specific identity
export const calculateStreakValues = (
  identity: Identity,
  habitCompleted: boolean,
): {
  streak: number
  highestStreak: number
} => {
  if (!habitCompleted) {
    return {
      streak: 0,
      highestStreak: identity.highestStreak || 0,
    }
  }

  const newStreak = identity.streak + 1
  const newHighestStreak = Math.max(identity.highestStreak || 0, newStreak)

  return {
    streak: newStreak,
    highestStreak: newHighestStreak,
  }
}

// Show streak notification to the user
export const displayStreakNotification = (identityName: string, streak: number): void => {
  if (streak > 1) {
    toast.success(`${identityName} streak: ${streak} days! 🔥`)
  } else if (streak === 1) {
    toast.success(`Started streak for ${identityName}! 🔥`)
  }
}

// Check if streak should be reset (if habit was not completed yesterday)
export const shouldResetStreak = (lastCompletionDate: string | null): boolean => {
  if (!lastCompletionDate) return true

  const today = getToday()
  const lastDate = new Date(lastCompletionDate)
  const todayDate = new Date(today)

  // Calculate difference in days
  const timeDiff = todayDate.getTime() - lastDate.getTime()
  const daysDiff = Math.floor(timeDiff / (1000 * 3600 * 24))

  // Reset streak if last completion was more than 1 day ago
  return daysDiff > 1
}

// Get highest streak among all identities
export const getHighestStreak = (identities: Identity[]): number => {
  if (!identities || identities.length === 0) return 0
  return Math.max(...identities.map((identity) => identity.streak || 0))
}

// Record habit completion in history when completing a habit
export const recordHabitCompletionInHistory = async (
  habitId: string,
  userId: string,
  identityId?: string, // Add optional identityId parameter
): Promise<void> => {
  try {
    const date = new Date()
    await toggleHabitCompletionStatus(habitId, userId, date, false, identityId)
  } catch (error) {
    console.error("Error recording habit completion in history:", error)
  }
}

