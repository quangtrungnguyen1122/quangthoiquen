import { supabase } from "@/integrations/supabase/client"
import type { Identity } from "@/contexts/types"

// Fetch identities service
export const fetchIdentities = async (userId: string) => {
  const { data: identitiesData, error: identitiesError } = await supabase
    .from("identities")
    .select("*")
    .eq("user_id", userId)

  if (identitiesError) {
    console.error("Error fetching identities:", identitiesError)
    throw identitiesError
  }

  return identitiesData
}

// Identity operations
export const addIdentityApi = async (identity: Omit<Identity, "id">, userId: string) => {
  const identityData = {
    name: identity.name,
    description: identity.description,
    streak: identity.streak || 0,
    highest_streak: identity.highestStreak || 0,
    progress: identity.progress || 0,
    avatar: identity.avatar,
    user_id: userId,
  }

  const { data, error } = await supabase.from("identities").insert([identityData]).select()

  if (error) {
    console.error("Error adding identity:", error)
    throw error
  }

  if (!data || !data[0]) {
    throw new Error("No data returned")
  }

  return data[0]
}

export const updateIdentityApi = async (id: string, identityUpdate: Partial<Omit<Identity, "id">>) => {
  const updateData: any = {}

  if (identityUpdate.name !== undefined) updateData.name = identityUpdate.name
  if (identityUpdate.description !== undefined) updateData.description = identityUpdate.description
  if (identityUpdate.streak !== undefined) updateData.streak = identityUpdate.streak
  if (identityUpdate.highestStreak !== undefined) updateData.highest_streak = identityUpdate.highestStreak
  if (identityUpdate.progress !== undefined) updateData.progress = identityUpdate.progress
  if (identityUpdate.avatar !== undefined) updateData.avatar = identityUpdate.avatar

  const { error } = await supabase.from("identities").update(updateData).eq("id", id)

  if (error) {
    console.error("Error updating identity:", error)
    throw error
  }
}

export const deleteIdentityApi = async (id: string) => {
  const { error } = await supabase.from("identities").delete().eq("id", id)

  if (error) {
    console.error("Error deleting identity:", error)
    throw error
  }
}

