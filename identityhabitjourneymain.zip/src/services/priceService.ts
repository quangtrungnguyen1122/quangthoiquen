import { supabase } from "@/integrations/supabase/client"
import type { Price } from "@/contexts/types"

// Fetch prices service
export const fetchPrices = async (userId: string) => {
  const { data: pricesData, error: pricesError } = await supabase.from("prices").select("*").eq("user_id", userId)

  if (pricesError) {
    console.error("Error fetching prices:", pricesError)
    throw pricesError
  }

  return pricesData
}

// Price operations
export const addPriceApi = async (price: Omit<Price, "id">, userId: string) => {
  const priceData = {
    name: price.name,
    description: price.description,
    completion_percentage: price.completionPercentage || 0,
    icon: price.icon,
    user_id: userId,
  }

  const { data, error } = await supabase.from("prices").insert([priceData]).select()

  if (error) {
    console.error("Error adding price:", error)
    throw error
  }

  if (!data || !data[0]) {
    throw new Error("No data returned")
  }

  return data[0]
}

export const updatePriceApi = async (id: string, priceUpdate: Partial<Omit<Price, "id">>) => {
  const updateData: any = {}

  if (priceUpdate.name !== undefined) updateData.name = priceUpdate.name
  if (priceUpdate.description !== undefined) updateData.description = priceUpdate.description
  if (priceUpdate.completionPercentage !== undefined)
    updateData.completion_percentage = priceUpdate.completionPercentage
  if (priceUpdate.icon !== undefined) updateData.icon = priceUpdate.icon

  const { error } = await supabase.from("prices").update(updateData).eq("id", id)

  if (error) {
    console.error("Error updating price:", error)
    throw error
  }
}

export const deletePriceApi = async (id: string) => {
  const { error } = await supabase.from("prices").delete().eq("id", id)

  if (error) {
    console.error("Error deleting price:", error)
    throw error
  }
}

