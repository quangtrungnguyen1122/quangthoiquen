import { supabase } from "@/integrations/supabase/client"

// Fetch relationship data
export const fetchHabitPrices = async () => {
  const { data: habitPricesData, error: habitPricesError } = await supabase.from("habit_prices").select("*")

  if (habitPricesError) {
    console.error("Error fetching habit_prices:", habitPricesError)
    throw habitPricesError
  }

  return habitPricesData
}

export const fetchIdentityPrices = async () => {
  const { data: identityPricesData, error: identityPricesError } = await supabase.from("identity_prices").select("*")

  if (identityPricesError) {
    console.error("Error fetching identity_prices:", identityPricesError)
    throw identityPricesError
  }

  return identityPricesData
}

