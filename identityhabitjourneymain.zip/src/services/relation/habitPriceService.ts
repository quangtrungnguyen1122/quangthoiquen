import { supabase } from "@/integrations/supabase/client"

// Linking operations for habits and prices
export const linkHabitToPriceApi = async (priceId: string, habitId: string) => {
  const { error } = await supabase.from("habit_prices").insert([{ habit_id: habitId, price_id: priceId }])

  if (error) {
    console.error("Error linking habit to price:", error)
    throw error
  }

  return true
}

// Fixed the type error by using direct deletion instead of RPC calls
export const removeHabitFromPriceApi = async (priceId: string, habitId: string) => {
  console.log("Using new removal approach for habit-price relationship:", { priceId, habitId })

  try {
    // Try calling the stored procedure first if it exists
    try {
      const { data, error } = await supabase.rpc("remove_habit_price_relationship", {
        p_price_id: priceId,
        p_habit_id: habitId,
      })

      if (!error && data === true) {
        console.log("Successfully removed using stored procedure")
        return true
      }

      // If stored procedure fails or doesn't exist, continue with direct deletion
      console.log("Stored procedure not available or failed, using direct deletion...")
    } catch (rpcError) {
      console.log("RPC not available:", rpcError)
      // Continue with direct deletion
    }

    // Direct deletion approach
    console.log("Using direct deletion approach...")
    const { error: deleteError } = await supabase
      .from("habit_prices")
      .delete()
      .eq("price_id", priceId)
      .eq("habit_id", habitId)

    if (deleteError) {
      console.error("Deletion failed:", deleteError)

      // Try alternative approach with match
      console.log("Trying alternative deletion with match...")
      const { error: matchDeleteError } = await supabase.from("habit_prices").delete().match({
        price_id: priceId,
        habit_id: habitId,
      })

      if (matchDeleteError) {
        console.error("Match deletion also failed:", matchDeleteError)
        return false
      }
    }

    // Verify the relationship no longer exists
    const { data: checkData } = await supabase
      .from("habit_prices")
      .select("*")
      .eq("price_id", priceId)
      .eq("habit_id", habitId)

    if (checkData && checkData.length > 0) {
      console.log("Relationship still exists after removal attempts.")
      return false
    }

    console.log("Successfully removed habit-price relationship")
    return true
  } catch (e) {
    console.error("Exception in removeHabitFromPriceApi:", e)
    return false
  }
}

// Keep the original function for now but mark it as deprecated
export const unlinkHabitFromPriceApi = async (priceId: string, habitId: string) => {
  console.log("DEPRECATED - Using removeHabitFromPriceApi instead")
  return removeHabitFromPriceApi(priceId, habitId)
}

