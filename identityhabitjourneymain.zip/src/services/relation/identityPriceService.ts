import { supabase } from "@/integrations/supabase/client"

// Linking operations for identities and prices
export const linkPriceToIdentityApi = async (identityId: string, priceId: string) => {
  const { error } = await supabase.from("identity_prices").insert([{ identity_id: identityId, price_id: priceId }])

  if (error) {
    console.error("Error linking price to identity:", error)
    throw error
  }

  return true
}

export const removePriceFromIdentityApi = async (identityId: string, priceId: string) => {
  console.log("Using new removal approach for identity-price relationship:", { identityId, priceId })

  try {
    // Try calling the stored procedure first if it exists
    try {
      const { data, error } = await supabase.rpc("remove_identity_price_relationship", {
        p_identity_id: identityId,
        p_price_id: priceId,
      })

      if (!error && data === true) {
        console.log("Successfully removed using stored procedure")
        return true
      }

      // If stored procedure fails or doesn't exist, continue with direct deletion
      console.log("Stored procedure not available or failed, using direct deletion...")
    } catch (rpcError) {
      console.log("RPC not available:", rpcError)
      // Continue with direct deletion
    }

    // Use direct deletion instead of RPC
    console.log("Using direct deletion approach...")
    const { error: deleteError } = await supabase
      .from("identity_prices")
      .delete()
      .eq("identity_id", identityId)
      .eq("price_id", priceId)

    if (deleteError) {
      console.error("Deletion failed:", deleteError)

      // Try alternative approach with match
      console.log("Trying alternative deletion with match...")
      const { error: matchDeleteError } = await supabase.from("identity_prices").delete().match({
        identity_id: identityId,
        price_id: priceId,
      })

      if (matchDeleteError) {
        console.error("Match deletion also failed:", matchDeleteError)
        return false
      }
    }

    // Verify the relationship no longer exists
    const { data: checkData } = await supabase
      .from("identity_prices")
      .select("*")
      .eq("identity_id", identityId)
      .eq("price_id", priceId)

    if (checkData && checkData.length > 0) {
      console.log("Relationship still exists after removal attempts.")
      return false
    }

    console.log("Successfully removed identity-price relationship")
    return true
  } catch (e) {
    console.error("Exception in removePriceFromIdentityApi:", e)
    return false
  }
}

// Keep the original function for now but mark it as deprecated
export const unlinkPriceFromIdentityApi = async (identityId: string, priceId: string) => {
  console.log("DEPRECATED - Using removePriceFromIdentityApi instead")
  return removePriceFromIdentityApi(identityId, priceId)
}

