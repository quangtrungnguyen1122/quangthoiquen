import type { Identity } from "@/contexts/types"
import { toast } from "sonner"

// Update streak and highest streak values
export const updateStreakValues = (
  identity: Identity,
): {
  streak: number
  highestStreak: number
} => {
  const newStreak = identity.streak + 1
  const newHighestStreak = Math.max(identity.highestStreak, newStreak)

  return {
    streak: newStreak,
    highestStreak: newHighestStreak,
  }
}

// Show streak toast notification
export const showStreakNotification = (identityName: string, streak: number): void => {
  if (streak > 1) {
    toast.success(`${identityName} streak: ${streak} days! 🔥`)
  }
}

// Get the highest streak among all identities for a user
export const getHighestIdentityStreak = (identities: Identity[]): number => {
  if (!identities || identities.length === 0) return 0

  // Find the identity with the highest streak
  return Math.max(...identities.map((identity) => identity.streak || 0))
}

// Get the highest historical streak among all identities for a user
export const getHighestIdentityHistoricalStreak = (identities: Identity[]): number => {
  if (!identities || identities.length === 0) return 0

  // Find the identity with the highest historical streak
  return Math.max(...identities.map((identity) => identity.highestStreak || 0))
}

