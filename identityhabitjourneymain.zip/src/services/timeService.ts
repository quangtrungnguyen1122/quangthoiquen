import { getTodayInVietnam } from "@/contexts/habit-provider/data-fetching/useTimezoneUtils"

// Check if a streak should be updated (same day completion)
export const shouldUpdateStreak = (lastCompletionDate: string | null): boolean => {
  if (!lastCompletionDate) return true

  const today = getTodayInVietnam()
  return lastCompletionDate !== today
}

// Get today's date in Vietnam timezone
export const getToday = (): string => {
  return getTodayInVietnam()
}

