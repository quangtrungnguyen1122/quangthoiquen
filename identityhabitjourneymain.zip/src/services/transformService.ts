import type { Habit, Price, Identity, User } from "@/contexts/types"

// Data transformation services
export const transformHabitsData = (habitsData: any[]): Habit[] => {
  return (habitsData || []).map((habit: any) => ({
    id: habit.id,
    name: habit.name,
    description: habit.description,
    difficulty: habit.difficulty as "easy" | "medium" | "hard",
    completed: habit.completed || false,
    points: habit.points || 0,
    priceIds: [],
    completionFrequency: habit.completion_frequency as "daily" | "weekly" | "specific-days",
    icon: habit.icon,
  }))
}

export const transformPricesData = (pricesData: any[]): Price[] => {
  return (pricesData || []).map((price: any) => ({
    id: price.id,
    name: price.name,
    description: price.description,
    habitIds: [],
    identityIds: [],
    completionPercentage: price.completion_percentage || 0,
    icon: price.icon,
  }))
}

export const transformIdentitiesData = (identitiesData: any[]): Identity[] => {
  return (identitiesData || []).map((identity: any) => ({
    id: identity.id,
    name: identity.name,
    description: identity.description,
    priceIds: [],
    streak: identity.streak || 0,
    highestStreak: identity.highest_streak || 0,
    progress: identity.progress || 0,
    avatar: identity.avatar,
  }))
}

export const transformUserData = (userData: any): User => {
  return {
    id: userData.id,
    username: userData.username || "User",
    avatar: userData.avatar,
    joinedDate: new Date(userData.joined_date || Date.now()),
    totalPoints: userData.total_points || 0,
    last30DaysPoints: userData.last_30_days_points || 0,
    last7DaysPoints: userData.last_7_days_points || 0,
    streaks: {},
    position: userData.position || 0,
  }
}

export const transformLeaderboardData = (leaderboardData: any[]): User[] => {
  return (leaderboardData || []).map((user: any) => ({
    id: user.id,
    username: user.username || "User",
    avatar: user.avatar,
    joinedDate: new Date(user.joined_date || Date.now()),
    totalPoints: user.total_points || 0,
    last30DaysPoints: user.last_30_days_points || 0,
    last7DaysPoints: user.last_7_days_points || 0,
    streaks: {},
    position: user.position || 0,
  }))
}

