import { supabase } from "@/integrations/supabase/client"

// Fetch user data services
export const fetchUserData = async (userId: string) => {
  const { data: userData, error: userError } = await supabase.from("profiles").select("*").eq("id", userId).single()

  if (userError) {
    console.error("Error fetching user:", userError)
    throw userError
  }

  return userData
}

export const fetchLeaderboard = async () => {
  const { data: leaderboardData, error: leaderboardError } = await supabase.from("profiles").select("*").limit(10)

  if (leaderboardError) {
    console.error("Error fetching leaderboard:", leaderboardError)
    throw leaderboardError
  }

  return leaderboardData
}

