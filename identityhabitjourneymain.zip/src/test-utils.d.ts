import "@testing-library/jest-dom"

declare global {
  namespace Vi {
    interface Assertion {
      toBeInTheDocument(): void
      toBeVisible(): void
      toHaveAttribute(attr: string, value?: string): void
      toHaveClass(className: string): void
      toHaveTextContent(text: string): void
      toContainElement(element: HTMLElement): void
      toBeDisabled(): void
      toBeEnabled(): void
      toBeRequired(): void
      toBeInvalid(): void
      toBeValid(): void
      toBeEmptyDOMElement(): void
      toHaveFocus(): void
      toBeChecked(): void
    }
  }
}

