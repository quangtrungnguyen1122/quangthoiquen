// Function to format a date
export const formatDate = (date: Date): string => {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  }).format(date)
}

// Function to get difficulty color
export const getDifficultyColor = (difficulty: "easy" | "medium" | "hard"): string => {
  switch (difficulty) {
    case "easy":
      return "text-green-500"
    case "medium":
      return "text-amber-500"
    case "hard":
      return "text-red-500"
    default:
      return "text-muted-foreground"
  }
}

// Function to get difficulty points
export const getDifficultyPoints = (difficulty: "easy" | "medium" | "hard"): number => {
  switch (difficulty) {
    case "easy":
      return 5
    case "medium":
      return 15
    case "hard":
      return 25
    default:
      return 0
  }
}

// Function to get streak emoji
export const getStreakEmoji = (streak: number): string => {
  if (streak >= 30) return "🔥"
  if (streak >= 14) return "🔥"
  if (streak >= 7) return "🔥"
  if (streak > 0) return "🔥"
  return ""
}

// Function to calculate streak bonus
export const calculateStreakBonus = (streak: number): number => {
  if (streak >= 30) return 2 // 2x multiplier
  if (streak >= 14) return 1.5 // 1.5x multiplier
  if (streak >= 7) return 1.25 // 1.25x multiplier
  return 1 // No bonus
}

// Function to get progress color class
export const getProgressColorClass = (progress: number): string => {
  if (progress >= 80) return "stroke-green-500"
  if (progress >= 50) return "stroke-blue-500"
  if (progress >= 25) return "stroke-amber-500"
  return "stroke-primary"
}

// Function to calculate completion rate
export const calculateCompletionRate = (completed: number, total: number): number => {
  if (total === 0) return 0
  return Math.round((completed / total) * 100)
}

// Function to truncate text with ellipsis
export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text
  return text.substring(0, maxLength) + "..."
}

